"use client"
import { Settings, Zap, ChevronDown, Bot, TrendingUp, TrendingDown } from "lucide-react"

export const INDICES = [
  { value: "R_10", label: "Volatility 10 Index" },
  { value: "R_25", label: "Volatility 25 Index" },
  { value: "R_50", label: "Volatility 50 Index" },
  { value: "R_75", label: "Volatility 75 Index" },
  { value: "R_100", label: "Volatility 100 Index" },
  { value: "1HZ10V", label: "Volatility 10 (1s)" },
  { value: "1HZ25V", label: "Volatility 25 (1s)" },
  { value: "1HZ50V", label: "Volatility 50 (1s)" },
  { value: "1HZ75V", label: "Volatility 75 (1s)" },
  { value: "1HZ100V", label: "Volatility 100 (1s)" },
  { value: "RDBULL", label: "Bull Market Index" },
  { value: "RDBEAR", label: "Bear Market Index" },
]

export const TRADE_TYPES = [
  { value: "CALL_PUT", label: "Rise / Fall" },
  { value: "DIGITEVEN_ODD", label: "Even / Odd" },
  { value: "DIGITMATCH_DIFF", label: "Matches / Differs" },
  { value: "DIGITOVER_UNDER", label: "Over / Under" },
  { value: "ONETOUCH_NOTOUCH", label: "Touch / No Touch" },
]

export interface TradeConfig {
  symbol: string
  tradeType: string
  stake: number
  martingale: boolean
  takeProfit: string
  stopLoss: string
  stakeBoost: number
  autoTrading: boolean
  fastAutoTrade: boolean
  bestSignalOnly: boolean
}

interface Props {
  config: TradeConfig
  onChange: (c: Partial<TradeConfig>) => void
  onBuy: () => void
  onSell: () => void
  onClearHistory: () => void
  isConnected: boolean
  isBuying: boolean
  isSelling: boolean
  onMultipliedBuy?: (multiplier: number) => void
  onMultipliedSell?: (multiplier: number) => void
}

// Context-aware labels for buy/sell based on trade type
function getTradeButtonLabels(tradeType: string): { buy: string; sell: string; buySub: string; sellSub: string } {
  switch (tradeType) {
    case "DIGITEVEN_ODD":
      return { buy: "EVEN", sell: "ODD", buySub: "Digit: 0,2,4,6,8", sellSub: "Digit: 1,3,5,7,9" }
    case "DIGITMATCH_DIFF":
      return { buy: "DIFFER", sell: "MATCH", buySub: "Last digit differs", sellSub: "Last digit matches" }
    case "DIGITOVER_UNDER":
      return { buy: "OVER 5", sell: "UNDER 5", buySub: "Digit: 6,7,8,9", sellSub: "Digit: 0,1,2,3,4" }
    case "ONETOUCH_NOTOUCH":
      return { buy: "TOUCH", sell: "NO TOUCH", buySub: "Price touches barrier", sellSub: "Price stays away" }
    default: // CALL_PUT
      return { buy: "RISE", sell: "FALL", buySub: "Price goes up", sellSub: "Price goes down" }
  }
}

export default function TradeSettings({
  config, onChange, onBuy, onSell, onClearHistory, isConnected, isBuying, isSelling,
  onMultipliedBuy, onMultipliedSell,
}: Props) {
  const labels = getTradeButtonLabels(config.tradeType)
  const boostOptions = [
    { label: "x1", value: 1 },
    { label: "x2", value: 2 },
    { label: "x3", value: 3 },
    { label: "x5", value: 5 },
  ]

  const SelectArrow = () => (
    <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none" />
  )

  return (
    <div className="trade-card">
      {/* Header */}
      <div className="flex items-center gap-2 mb-4">
        <Settings size={16} className="text-blue-400" />
        <span className="text-sm font-semibold text-slate-200">Trade Settings</span>
      </div>

      {/* Row 1: Index + Type */}
      <div className="grid grid-cols-2 gap-3 mb-3">
        <div>
          <label className="block text-xs text-slate-500 mb-1.5">Select Index</label>
          <div className="relative">
            <select
              value={config.symbol}
              onChange={e => onChange({ symbol: e.target.value })}
              className="w-full bg-[#0a0e1a] border border-[#1e2a3a] rounded-xl px-3 py-2.5 text-sm text-slate-300 appearance-none outline-none focus:border-blue-500/60 cursor-pointer pr-8"
            >
              {INDICES.map(i => (
                <option key={i.value} value={i.value}>{i.label}</option>
              ))}
            </select>
            <SelectArrow />
          </div>
        </div>
        <div>
          <label className="block text-xs text-slate-500 mb-1.5">Trade Type</label>
          <div className="relative">
            <select
              value={config.tradeType}
              onChange={e => onChange({ tradeType: e.target.value })}
              className="w-full bg-[#0a0e1a] border border-[#1e2a3a] rounded-xl px-3 py-2.5 text-sm text-slate-300 appearance-none outline-none focus:border-blue-500/60 cursor-pointer pr-8"
            >
              {TRADE_TYPES.map(t => (
                <option key={t.value} value={t.value}>{t.label}</option>
              ))}
            </select>
            <SelectArrow />
          </div>
        </div>
      </div>

      {/* Stake */}
      <div className="mb-3">
        <label className="block text-xs text-slate-500 mb-1.5">Stake Amount</label>
        <input
          type="number"
          min={0.35}
          step={0.01}
          value={config.stake}
          onChange={e => onChange({ stake: parseFloat(e.target.value) || 0.35 })}
          className="w-full bg-[#0a0e1a] border border-[#1e2a3a] rounded-xl px-3 py-2.5 text-sm text-slate-300 outline-none focus:border-blue-500/60 mb-1.5"
        />
        {/* Quick-stake presets */}
        <div className="flex items-center gap-1">
          {[0.35, 1, 2, 5, 10].map(amt => (
            <button
              key={amt}
              onClick={() => onChange({ stake: amt })}
              className={`flex-1 py-1 text-[10px] font-bold rounded-lg border transition-colors ${
                config.stake === amt
                  ? "bg-blue-900/40 border-blue-700/60 text-blue-300"
                  : "bg-[#0a0e1a] border-[#1e2a3a] text-slate-600 hover:text-slate-400 hover:border-slate-600"
              }`}
            >
              ${amt}
            </button>
          ))}
        </div>
      </div>

      {/* ── BUY / SELL Buttons (context-aware labels) ── */}
      <div className="grid grid-cols-2 gap-3 mb-3">
        <button
          onClick={onBuy}
          disabled={!isConnected || isBuying}
          className="group relative w-full py-4 rounded-xl font-bold flex flex-col items-center justify-center gap-0.5 transition-all duration-150 active:scale-[0.97] disabled:opacity-40 disabled:cursor-not-allowed border border-emerald-700/50 bg-emerald-950/60 hover:bg-emerald-900/70 hover:border-emerald-600/70 shadow-lg shadow-emerald-950/30"
          style={{ touchAction: "manipulation" }}
        >
          {isBuying ? (
            <span className="w-5 h-5 border-2 border-emerald-400/30 border-t-emerald-400 rounded-full animate-spin" />
          ) : (
            <>
              <TrendingUp size={18} className="text-emerald-400 mb-0.5" />
              <span className="text-base font-black text-emerald-300 tracking-wide leading-none">{labels.buy}</span>
              <span className="text-[9px] text-emerald-600 font-medium tracking-wide mt-0.5">{labels.buySub}</span>
            </>
          )}
        </button>
        <button
          onClick={onSell}
          disabled={!isConnected || isSelling}
          className="group relative w-full py-4 rounded-xl font-bold flex flex-col items-center justify-center gap-0.5 transition-all duration-150 active:scale-[0.97] disabled:opacity-40 disabled:cursor-not-allowed border border-red-700/50 bg-red-950/60 hover:bg-red-900/70 hover:border-red-600/70 shadow-lg shadow-red-950/30"
          style={{ touchAction: "manipulation" }}
        >
          {isSelling ? (
            <span className="w-5 h-5 border-2 border-red-400/30 border-t-red-400 rounded-full animate-spin" />
          ) : (
            <>
              <TrendingDown size={18} className="text-red-400 mb-0.5" />
              <span className="text-base font-black text-red-300 tracking-wide leading-none">{labels.sell}</span>
              <span className="text-[9px] text-red-600 font-medium tracking-wide mt-0.5">{labels.sellSub}</span>
            </>
          )}
        </button>
      </div>

      {/* ── AUTO TRADE BOT — prominent single toggle ── */}
      <div
        onClick={() => isConnected && onChange({ autoTrading: !config.autoTrading })}
        className={`relative w-full flex items-center justify-between px-4 py-4 rounded-2xl border-2 cursor-pointer transition-all duration-200 mb-3 select-none ${
          config.autoTrading
            ? "bg-gradient-to-r from-blue-950/80 to-indigo-950/80 border-blue-500/70 shadow-lg shadow-blue-950/40"
            : isConnected
              ? "bg-[#0d1117] border-[#1e2a3a] hover:border-blue-800/50 hover:bg-[#0f1520]"
              : "bg-[#0d1117] border-[#1e2a3a] opacity-40 cursor-not-allowed"
        }`}
        role="button"
        aria-label="Toggle Auto Trading Bot"
      >
        {/* Pulsing glow when active */}
        {config.autoTrading && (
          <div className="absolute inset-0 rounded-2xl bg-blue-500/5 animate-pulse pointer-events-none" />
        )}

        <div className="flex items-center gap-3 relative">
          <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 transition-all ${
            config.autoTrading ? "bg-blue-500/20 border border-blue-500/40" : "bg-[#0d1117] border border-[#1e2a3a]"
          }`}>
            <Bot size={18} style={{ color: config.autoTrading ? "#60a5fa" : "#475569" }} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className={`text-sm font-bold ${config.autoTrading ? "text-blue-300" : "text-slate-300"}`}>
                Auto Trade Bot
              </span>
              {config.autoTrading && (
                <span className="text-[8px] font-bold px-1.5 py-0.5 rounded-full bg-blue-500/20 text-blue-400 border border-blue-500/30 uppercase tracking-wide animate-pulse">
                  Running
                </span>
              )}
            </div>
            <div className="text-[10px] mt-0.5">
              {config.autoTrading
                ? <span className="text-blue-500">Watching signals — fires {labels.buy}/{labels.sell} automatically</span>
                : <span className="text-slate-600">Tap to let the bot trade for you on every valid signal</span>
              }
            </div>
          </div>
        </div>

        {/* Toggle pill */}
        <div className={`relative w-12 h-6 rounded-full flex-shrink-0 transition-colors duration-200 ${
          config.autoTrading ? "bg-blue-500" : "bg-[#1e2a3a]"
        }`}>
          <div className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow-md transition-all duration-200 ${
            config.autoTrading ? "left-[26px]" : "left-0.5"
          }`} />
        </div>
      </div>

      {/* Best Signal Only */}
      <div
        onClick={() => onChange({ bestSignalOnly: !config.bestSignalOnly })}
        className={`flex items-center justify-between px-3 py-3 rounded-xl mb-3 border cursor-pointer transition-colors ${
          config.bestSignalOnly
            ? "bg-emerald-950/20 border-emerald-800/40"
            : "bg-[#0a0e1a] border-[#1e2a3a] hover:border-slate-600"
        }`}
      >
        <div>
          <div className="flex items-center gap-1.5">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" className="text-emerald-400"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
            <span className="text-xs font-semibold text-slate-300">High-Quality Signals Only</span>
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">
            {config.bestSignalOnly ? "Only fires when confidence is very high (70%+)" : "Fires on any valid signal (62%+)"}
          </div>
        </div>
        <div className={`toggle-switch ${config.bestSignalOnly ? "active" : ""}`} />
      </div>

      {/* Martingale */}
      <div
        onClick={() => onChange({ martingale: !config.martingale })}
        className="flex items-center justify-between px-3 py-3 bg-[#0a0e1a] border border-[#1e2a3a] rounded-xl mb-3 cursor-pointer hover:border-slate-600 transition-colors"
      >
        <div>
          <div className="text-xs font-semibold text-slate-300">Martingale Recovery</div>
          <div className="text-[10px] text-slate-500 mt-0.5">Double stake after a loss, reset on win</div>
        </div>
        <div className={`toggle-switch ${config.martingale ? "active" : ""}`} />
      </div>

      {/* TP / SL */}
      <div className="grid grid-cols-2 gap-3 mb-3">
        <div>
          <label className="block text-xs text-slate-500 mb-1.5">Take Profit ($)</label>
          <input
            type="number"
            min={0}
            step={0.01}
            placeholder="Optional"
            value={config.takeProfit}
            onChange={e => onChange({ takeProfit: e.target.value })}
            className="w-full bg-[#0a0e1a] border border-[#1e2a3a] rounded-xl px-3 py-2.5 text-sm text-slate-300 placeholder-slate-600 outline-none focus:border-blue-500/60"
          />
        </div>
        <div>
          <label className="block text-xs text-slate-500 mb-1.5">Stop Loss ($)</label>
          <input
            type="number"
            min={0}
            step={0.01}
            placeholder="Optional"
            value={config.stopLoss}
            onChange={e => onChange({ stopLoss: e.target.value })}
            className="w-full bg-[#0a0e1a] border border-[#1e2a3a] rounded-xl px-3 py-2.5 text-sm text-slate-300 placeholder-slate-600 outline-none focus:border-blue-500/60"
          />
        </div>
      </div>

      {/* Stake Boost */}
      <div className="mb-3">
        <div className="flex items-center gap-2 mb-2">
          <Zap size={12} className="text-yellow-400" />
          <span className="text-xs text-slate-400 font-medium">Stake boost</span>
        </div>
        <div className="boost-bar">
          {boostOptions.map(opt => (
            <div
              key={opt.value}
              className={`boost-option ${config.stakeBoost === opt.value ? "active" : ""}`}
              onClick={() => onChange({ stakeBoost: opt.value })}
            >
              {opt.label}
            </div>
          ))}
        </div>
      </div>

      {/* x2 / x3 / x5 Quick Multiply */}
      <div className="mb-3">
        <div className="flex items-center gap-2 mb-2">
          <Zap size={12} className="text-amber-400" />
          <span className="text-xs text-slate-400 font-medium">Quick multiplied trade</span>
        </div>
        <div className="grid grid-cols-3 gap-2">
          {[2, 3, 5].map((mult) => {
            const boostedStake = (config.stake * mult).toFixed(2)
            return (
              <div key={mult} className="flex flex-col gap-1">
                <div className="text-center text-[9px] text-slate-600 font-semibold tracking-wide">${boostedStake}</div>
                <button
                  disabled={!isConnected}
                  onClick={() => onMultipliedBuy?.(mult)}
                  className={`w-full py-2 rounded-lg text-xs font-bold border transition-all active:scale-[0.97] ${
                    isConnected
                      ? "bg-emerald-950/40 border-emerald-800/50 text-emerald-400 hover:bg-emerald-900/50"
                      : "bg-[#0a0e1a] border-[#1e2a3a] text-slate-600 cursor-not-allowed"
                  }`}
                >
                  x{mult} {labels.buy}
                </button>
                <button
                  disabled={!isConnected}
                  onClick={() => onMultipliedSell?.(mult)}
                  className={`w-full py-2 rounded-lg text-xs font-bold border transition-all active:scale-[0.97] ${
                    isConnected
                      ? "bg-red-950/40 border-red-800/50 text-red-400 hover:bg-red-900/50"
                      : "bg-[#0a0e1a] border-[#1e2a3a] text-slate-600 cursor-not-allowed"
                  }`}
                >
                  x{mult} {labels.sell}
                </button>
              </div>
            )
          })}
        </div>
      </div>

      {/* Clear History */}
      <button
        onClick={onClearHistory}
        className="w-full py-2.5 rounded-xl text-xs text-slate-500 border border-[#1e2a3a] hover:border-slate-600 hover:text-slate-400 transition-colors"
      >
        Clear Trade History
      </button>
    </div>
  )
}
