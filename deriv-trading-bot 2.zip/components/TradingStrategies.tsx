"use client"
import { useState } from "react"
import { Zap, TrendingUp, BarChart2, Activity, Layers, Circle, Star, ChevronDown, ChevronUp } from "lucide-react"

// Best pairs per strategy — based on Deriv volatility index characteristics:
// R_10 (Vol 10): very low volatility, tight price action → best for digit trades
// R_25 (Vol 25): low-medium volatility → good for digit + range trades
// R_50 (Vol 50): medium volatility, balanced → best all-rounder for Rise/Fall
// R_75 (Vol 75): high volatility, strong trends → good for Rise/Fall trend following
// R_100(Vol 100): very high volatility, extreme moves → good for Touch/No Touch
// 1HZ10V, 1HZ25V etc.: 1-tick variants of each, same characteristics but faster

export const PAIR_COMPATIBILITY: Record<string, {
  symbol: string
  label: string
  rating: 1 | 2 | 3  // 3=best, 2=good, 1=ok
  note: string
}[]> = {
  digitai: [
    { symbol: "R_10",    label: "Vol 10",    rating: 3, note: "Tightest range — most predictable digit patterns" },
    { symbol: "R_25",    label: "Vol 25",    rating: 3, note: "Stable digit distribution, high even/odd reliability" },
    { symbol: "1HZ10V",  label: "Vol 10 (1s)", rating: 3, note: "Same as Vol 10, 1-tick speed" },
    { symbol: "R_50",    label: "Vol 50",    rating: 2, note: "Acceptable — digit distribution still regular" },
    { symbol: "R_75",    label: "Vol 75",    rating: 1, note: "Higher volatility disturbs digit patterns" },
    { symbol: "R_100",   label: "Vol 100",   rating: 1, note: "Avoid — extreme moves break digit statistics" },
  ],
  unibet: [
    { symbol: "R_50",    label: "Vol 50",    rating: 3, note: "Perfect for Rise/Fall — balanced trend formation" },
    { symbol: "R_75",    label: "Vol 75",    rating: 3, note: "Strong momentum, EMA/MACD signals work well" },
    { symbol: "R_100",   label: "Vol 100",   rating: 2, note: "Good trends but risk of whipsaws" },
    { symbol: "R_25",    label: "Vol 25",    rating: 2, note: "Slower trends, needs more confirmation ticks" },
    { symbol: "R_10",    label: "Vol 10",    rating: 1, note: "Too flat for trend strategies" },
  ],
  tradex: [
    { symbol: "R_10",    label: "Vol 10",    rating: 3, note: "Most consistent differ ratio — top choice" },
    { symbol: "R_25",    label: "Vol 25",    rating: 3, note: "Strong differ bias, low noise" },
    { symbol: "1HZ25V",  label: "Vol 25 (1s)", rating: 3, note: "Same reliability at faster pace" },
    { symbol: "R_50",    label: "Vol 50",    rating: 2, note: "Moderate — differ ratio less stable" },
    { symbol: "R_75",    label: "Vol 75",    rating: 1, note: "Volatile prices distort differ ratio" },
  ],
  optimax: [
    { symbol: "R_10",    label: "Vol 10",    rating: 3, note: "Best over/under convergence in tight range" },
    { symbol: "R_25",    label: "Vol 25",    rating: 3, note: "Stable over/under ratio patterns" },
    { symbol: "R_50",    label: "Vol 50",    rating: 2, note: "Good but ratio shifts more frequently" },
    { symbol: "1HZ10V",  label: "Vol 10 (1s)", rating: 3, note: "Fast ticks, same digit stability" },
    { symbol: "R_75",    label: "Vol 75",    rating: 1, note: "Over/under ratio unreliable at high vol" },
  ],
  accumulator: [
    { symbol: "R_10",    label: "Vol 10",    rating: 3, note: "Low tick volatility = accumulator survives longer" },
    { symbol: "R_25",    label: "Vol 25",    rating: 3, note: "Good risk/reward, manageable barrier" },
    { symbol: "R_50",    label: "Vol 50",    rating: 2, note: "Higher payout but more barrier knockouts" },
    { symbol: "R_75",    label: "Vol 75",    rating: 1, note: "Very high knockout risk" },
    { symbol: "R_100",   label: "Vol 100",   rating: 1, note: "Extreme risk — avoid for accumulators" },
  ],
  autors: [
    { symbol: "R_100",   label: "Vol 100",   rating: 3, note: "Extreme moves = Touch contracts hit barriers easily" },
    { symbol: "R_75",    label: "Vol 75",    rating: 3, note: "Strong momentum, touch targets reliably hit" },
    { symbol: "R_50",    label: "Vol 50",    rating: 2, note: "Works in volatile sessions" },
    { symbol: "R_25",    label: "Vol 25",    rating: 1, note: "Too quiet for touch targets" },
    { symbol: "R_10",    label: "Vol 10",    rating: 1, note: "Avoid — price rarely reaches touch barriers" },
  ],
}

export const STRATEGIES = [
  {
    id: "digitai",
    name: "DigitAI",
    tag: "Even/Odd",
    desc: "Statistical even/odd digit reversal analysis",
    icon: <Zap size={15} className="text-yellow-400" />,
    contractTypes: ["DIGITEVEN", "DIGITODD"],
    goodFor: "ranging" as const,
    tradeType: "DIGITEVEN_ODD",
  },
  {
    id: "unibet",
    name: "Unibet",
    tag: "Rise/Fall",
    desc: "17-indicator multi-family trend engine",
    icon: <TrendingUp size={15} className="text-emerald-400" />,
    contractTypes: ["CALL", "PUT"],
    goodFor: "trending" as const,
    tradeType: "CALL_PUT",
  },
  {
    id: "tradex",
    name: "TradeX",
    tag: "Match/Differ",
    desc: "Dual-window differ ratio + streak analysis",
    icon: <BarChart2 size={15} className="text-blue-400" />,
    contractTypes: ["DIGITMATCH", "DIGITDIFF"],
    goodFor: "ranging" as const,
    tradeType: "DIGITMATCH_DIFF",
  },
  {
    id: "optimax",
    name: "OptimaX",
    tag: "Over/Under",
    desc: "Over-5/Under-5 ratio convergence trading",
    icon: <Activity size={15} className="text-purple-400" />,
    contractTypes: ["DIGITOVER", "DIGITUNDER"],
    goodFor: "ranging" as const,
    tradeType: "DIGITOVER_UNDER",
  },
  {
    id: "accumulator",
    name: "Accumulator Bot",
    tag: "Accumulators",
    desc: "Momentum + ATR volatility-based accumulator",
    icon: <Layers size={15} className="text-orange-400" />,
    contractTypes: ["ACCU"],
    goodFor: "all" as const,
    tradeType: "CALL_PUT",
  },
  {
    id: "autors",
    name: "Auto RS",
    tag: "Touch/No Touch",
    desc: "Volatility-timed touch entry strategy",
    icon: <Circle size={15} className="text-pink-400" />,
    contractTypes: ["ONETOUCH", "NOTOUCH"],
    goodFor: "volatile" as const,
    tradeType: "ONETOUCH_NOTOUCH",
  },
]

type Regime = "Ranging" | "Trending" | "Volatile"

interface StrategySignal {
  signal: "BUY" | "SELL" | "WAIT"
  confidence: number
}

interface Props {
  activeStrategy: string | null
  onSelect: (id: string) => void
  regime?: Regime
  strategySignals?: Record<string, StrategySignal>
  currentSymbol?: string
}

function regimeMatch(goodFor: string, regime: Regime): boolean {
  if (goodFor === "all") return true
  if (goodFor === "ranging" && regime === "Ranging") return true
  if (goodFor === "trending" && regime === "Trending") return true
  if (goodFor === "volatile" && regime === "Volatile") return true
  return false
}

function RatingDots({ rating }: { rating: 1 | 2 | 3 }) {
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3].map(i => (
        <div key={i} className={`w-1.5 h-1.5 rounded-full ${
          i <= rating
            ? rating === 3 ? "bg-emerald-400" : rating === 2 ? "bg-yellow-400" : "bg-slate-500"
            : "bg-slate-700"
        }`} />
      ))}
    </div>
  )
}

export default function TradingStrategies({ activeStrategy, onSelect, regime, strategySignals, currentSymbol }: Props) {
  const [expandedPairs, setExpandedPairs] = useState<string | null>(null)

  return (
    <div className="trade-card">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Activity size={15} className="text-blue-400" />
          <span className="text-sm font-semibold text-slate-200">Trading Strategies</span>
        </div>
        {regime && (
          <span className={`text-[10px] px-2 py-0.5 rounded-md font-semibold border ${
            regime === "Trending" ? "text-emerald-400 bg-emerald-900/20 border-emerald-800/30" :
            regime === "Volatile" ? "text-orange-400 bg-orange-900/20 border-orange-800/30" :
            "text-blue-400 bg-blue-900/20 border-blue-800/30"
          }`}>{regime}</span>
        )}
      </div>
      <div className="space-y-2">
        {STRATEGIES.map(s => {
          const isMatch = regime ? regimeMatch(s.goodFor, regime) : false
          const sig = strategySignals?.[s.id]
          const isActive = activeStrategy === s.id
          const pairs = PAIR_COMPATIBILITY[s.id] ?? []
          const bestPairs = pairs.filter(p => p.rating === 3)
          const currentPairRating = pairs.find(p => p.symbol === currentSymbol)
          const showPairs = expandedPairs === s.id

          return (
            <div key={s.id} className={`rounded-xl border transition-all duration-200 overflow-hidden ${
              isActive ? "border-blue-700/60 bg-blue-900/10" : "border-[#1e2a3a] bg-[#0d1117]"
            }`}>
              {/* Main row */}
              <div
                className="flex items-center gap-3 p-3 cursor-pointer"
                onClick={() => onSelect(s.id)}
              >
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 transition-colors ${
                  isActive ? "bg-blue-900/40" : "bg-[#0a0e1a]"
                }`}>
                  {s.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-sm font-semibold text-slate-200">{s.name}</span>
                    <span className="text-[9px] px-1.5 py-0.5 bg-[#1e3a5f] text-blue-300 rounded-md font-medium">
                      {s.tag}
                    </span>
                    {isMatch && (
                      <span className="text-[9px] px-1 py-0.5 bg-emerald-900/30 text-emerald-400 border border-emerald-800/30 rounded font-bold flex items-center gap-0.5">
                        <Star size={7} />
                        Best now
                      </span>
                    )}
                    {/* Current pair rating badge */}
                    {currentPairRating && (
                      <span className={`text-[9px] px-1.5 py-0.5 rounded border font-bold ${
                        currentPairRating.rating === 3
                          ? "text-emerald-400 bg-emerald-950/30 border-emerald-800/30"
                          : currentPairRating.rating === 2
                          ? "text-yellow-400 bg-yellow-950/30 border-yellow-800/30"
                          : "text-slate-500 bg-slate-800/30 border-slate-700/30"
                      }`}>
                        {currentPairRating.rating === 3 ? "Ideal pair" : currentPairRating.rating === 2 ? "OK pair" : "Weak pair"}
                      </span>
                    )}
                  </div>
                  <div className="text-[10px] text-slate-500 mt-0.5 truncate">{s.desc}</div>
                </div>
                {/* Right: signal + radio */}
                <div className="flex items-center gap-2 flex-shrink-0">
                  {sig && sig.signal !== "WAIT" && (
                    <div className={`text-[9px] font-bold px-1.5 py-0.5 rounded border ${
                      sig.signal === "BUY"
                        ? "text-emerald-400 bg-emerald-900/25 border-emerald-800/30"
                        : "text-red-400 bg-red-900/25 border-red-800/30"
                    }`}>
                      {sig.signal} {sig.confidence}%
                    </div>
                  )}
                  {sig && sig.signal === "WAIT" && (
                    <div className="text-[9px] font-bold px-1.5 py-0.5 rounded border text-slate-500 bg-slate-800/40 border-slate-700/30">
                      WAIT
                    </div>
                  )}
                  <div className={`w-4 h-4 rounded-full border-2 flex-shrink-0 transition-all ${
                    isActive ? "border-blue-400 bg-blue-400" : "border-slate-600"
                  }`} />
                </div>
              </div>

              {/* Best pairs quick row */}
              {isActive && (
                <div className="px-3 pb-3">
                  <button
                    onClick={(e) => { e.stopPropagation(); setExpandedPairs(showPairs ? null : s.id) }}
                    className="w-full flex items-center justify-between py-1.5 px-2 rounded-lg bg-[#0a0e1a] border border-[#1e2a3a] hover:border-slate-600 transition-colors"
                  >
                    <div className="flex items-center gap-1.5">
                      <span className="text-[10px] text-slate-400 font-medium">Best pairs:</span>
                      <div className="flex items-center gap-1">
                        {bestPairs.slice(0, 3).map(p => (
                          <span key={p.symbol} className={`text-[9px] px-1.5 py-0.5 rounded font-bold border ${
                            p.symbol === currentSymbol
                              ? "text-emerald-300 bg-emerald-900/40 border-emerald-700/50"
                              : "text-slate-400 bg-slate-800/40 border-slate-700/30"
                          }`}>{p.label}</span>
                        ))}
                      </div>
                    </div>
                    {showPairs
                      ? <ChevronUp size={12} className="text-slate-500" />
                      : <ChevronDown size={12} className="text-slate-500" />}
                  </button>

                  {/* Expanded pair compatibility table */}
                  {showPairs && (
                    <div className="mt-2 space-y-1">
                      {pairs.map(p => (
                        <div key={p.symbol} className={`flex items-center gap-2 px-2 py-1.5 rounded-lg border ${
                          p.symbol === currentSymbol
                            ? "bg-blue-950/20 border-blue-800/30"
                            : "bg-[#0a0e1a] border-[#1e2a3a]"
                        }`}>
                          <div className="flex items-center gap-1.5 w-20 flex-shrink-0">
                            <RatingDots rating={p.rating} />
                            <span className={`text-[10px] font-bold ${
                              p.symbol === currentSymbol ? "text-blue-300" : "text-slate-400"
                            }`}>{p.label}</span>
                          </div>
                          <span className="text-[9px] text-slate-600 flex-1 leading-tight">{p.note}</span>
                          {p.symbol === currentSymbol && (
                            <span className="text-[9px] text-blue-400 font-bold flex-shrink-0">Active</span>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          )
        })}
      </div>

      {/* Legend */}
      <div className="flex items-center gap-3 mt-3 px-1">
        <span className="text-[9px] text-slate-600">Pair rating:</span>
        {([3, 2, 1] as const).map(r => (
          <div key={r} className="flex items-center gap-1">
            <RatingDots rating={r} />
            <span className="text-[9px] text-slate-600">{r === 3 ? "Best" : r === 2 ? "Good" : "OK"}</span>
          </div>
        ))}
      </div>
    </div>
  )
}
