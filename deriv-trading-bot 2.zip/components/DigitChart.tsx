"use client"

import { useMemo, useState, useRef, useEffect, useCallback } from "react"
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell,
  LineChart, Line, CartesianGrid, ReferenceLine,
} from "recharts"

// ─── Types ────────────────────────────────────────────────────────────────────

interface Props {
  digits:      number[]
  ticks:       number[]
  symbol:      string
  isConnected: boolean
  stake?:      number
  onTrade?:    (contractType: string, barrier: string) => void
}

interface AutoTradeLog {
  id:      number
  time:    number
  type:    "EVEN" | "ODD"
  reason:  string
  result?: "win" | "loss" | "pending"
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function getLastDigit(price: number): number {
  const s = price.toFixed(5)
  return parseInt(s[s.length - 1], 10)
}
const isEven  = (d: number) => d % 2 === 0
const isOdd   = (d: number) => d % 2 !== 0
const isOver5 = (d: number) => d > 5
const isUnder5= (d: number) => d <= 5

// ─── Over/Under configs ───────────────────────────────────────────────────────

const OVER_THRESHOLDS = [
  { label: "Over 0",  barrier: "0", desc: "Digit is 1–9 · 90% base rate",  digits:[1,2,3,4,5,6,7,8,9], color:"#34d399" },
  { label: "Over 1",  barrier: "1", desc: "Digit is 2–9 · 80% base rate",  digits:[2,3,4,5,6,7,8,9],   color:"#6ee7b7" },
  { label: "Over 2",  barrier: "2", desc: "Digit is 3–9 · 70% base rate",  digits:[3,4,5,6,7,8,9],      color:"#a3e635" },
  { label: "Over 3",  barrier: "3", desc: "Digit is 4–9 · 60% base rate",  digits:[4,5,6,7,8,9],        color:"#fbbf24" },
]
const UNDER_THRESHOLDS = [
  { label: "Under 9", barrier: "9", desc: "Digit is 0–8 · 90% base rate",  digits:[0,1,2,3,4,5,6,7,8], color:"#60a5fa" },
]

// ─── Signal computation ────────────────────────────────────────────────────────

interface ReversionSignal {
  shouldFire:  boolean
  direction:   "EVEN" | "ODD" | null
  reason:      string
  oddPct50:    number
  evenPct50:   number
  oddPct25:    number
  evenPct25:   number
  oddPct10:    number
  evenPct10:   number
  streak:      number
  streakType:  "EVEN" | "ODD" | null
  strength:    "STRONG" | "MODERATE" | "WEAK"
  score:       number   // 0–100 win confidence
}

function computeSignal(digits: number[]): ReversionSignal {
  const EMPTY: ReversionSignal = {
    shouldFire: false, direction: null,
    reason: digits.length < 25 ? `Collecting ticks… ${digits.length}/25` : "No imbalance detected",
    oddPct50:50, evenPct50:50, oddPct25:50, evenPct25:50, oddPct10:50, evenPct10:50,
    streak:0, streakType:null, strength:"WEAK", score:0,
  }
  if (digits.length < 25) return EMPTY

  const r50  = digits.slice(-50)
  const r25  = digits.slice(-25)
  const r10  = digits.slice(-10)

  const e50  = r50.filter(isEven).length;  const o50 = r50.length - e50
  const e25  = r25.filter(isEven).length;  const o25 = r25.length - e25
  const e10  = r10.filter(isEven).length;  const o10 = r10.length - e10

  const ep50 = (e50 / r50.length) * 100;  const op50 = 100 - ep50
  const ep25 = (e25 / r25.length) * 100;  const op25 = 100 - ep25
  const ep10 = (e10 / r10.length) * 100;  const op10 = 100 - ep10

  // Current streak
  let streak = 0
  let streakType: "EVEN" | "ODD" | null = null
  for (let i = digits.length - 1; i >= 0; i--) {
    const t = isEven(digits[i]) ? "EVEN" : "ODD"
    if (i === digits.length - 1) streakType = t
    if (t === streakType) streak++; else break
  }

  let direction: "EVEN" | "ODD" | null = null
  let strength:  "STRONG" | "MODERATE" | "WEAK" = "WEAK"
  let shouldFire = false
  let reason = "No imbalance detected"
  let score  = 0

  // ── ODD has dominated → bet EVEN ────────────────────────────────────────────
  // Rule: ODD >= 68% in 50-tick AND 63%+ in 25-tick = MODERATE
  //       ODD >= 72% in 50-tick AND 65%+ in 25-tick = STRONG
  //       Streak of 4+ same type = bonus confidence
  if (op50 >= 68 && op25 >= 63) {
    direction = "EVEN"
    // Score: how far ODD is above 68% threshold
    score = Math.min(Math.round(((op50 - 68) / 32) * 60 + ((op25 - 63) / 37) * 40), 100)
    if (op50 >= 72 && op25 >= 65) {
      strength  = "STRONG"
      shouldFire = true
      reason = `ODD dominated ${op50.toFixed(0)}% (50tk) · ${op25.toFixed(0)}% (25tk) · ${op10.toFixed(0)}% (10tk) — EVEN overdue`
    } else {
      strength  = "MODERATE"
      shouldFire = true
      reason = `ODD at ${op50.toFixed(0)}% (50tk) · ${op25.toFixed(0)}% (25tk) — statistically EVEN is due`
    }
  }

  // ── EVEN has dominated → bet ODD ────────────────────────────────────────────
  if (!direction && ep50 >= 68 && ep25 >= 63) {
    direction = "ODD"
    score = Math.min(Math.round(((ep50 - 68) / 32) * 60 + ((ep25 - 63) / 37) * 40), 100)
    if (ep50 >= 72 && ep25 >= 65) {
      strength  = "STRONG"
      shouldFire = true
      reason = `EVEN dominated ${ep50.toFixed(0)}% (50tk) · ${ep25.toFixed(0)}% (25tk) · ${ep10.toFixed(0)}% (10tk) — ODD overdue`
    } else {
      strength  = "MODERATE"
      shouldFire = true
      reason = `EVEN at ${ep50.toFixed(0)}% (50tk) · ${ep25.toFixed(0)}% (25tk) — statistically ODD is due`
    }
  }

  // ── Streak bonus: 4+ consecutive same type ───────────────────────────────────
  if (streak >= 4 && streakType) {
    const opp = streakType === "ODD" ? "EVEN" : "ODD"
    if (!direction) {
      direction  = opp
      strength   = "MODERATE"
      shouldFire = true
      score      = Math.min(streak * 10, 65)
      reason     = `${streak}x ${streakType} streak — ${opp} reversion expected`
    } else if (direction === opp) {
      // Streak confirms existing signal
      score    = Math.min(score + streak * 5, 100)
      reason  += ` · ${streak}x ${streakType} streak confirms`
      if (strength === "MODERATE" && streak >= 5) strength = "STRONG"
    }
  }

  return {
    shouldFire, direction, reason,
    oddPct50: op50, evenPct50: ep50,
    oddPct25: op25, evenPct25: ep25,
    oddPct10: op10, evenPct10: ep10,
    streak, streakType, strength, score,
  }
}

// ─── Tiny tooltip ─────────────────────────────────────────────────────────────
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function ChartTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null
  return (
    <div className="bg-[#0d1526] border border-[#1e2a3a] rounded-lg px-2.5 py-1.5 text-xs">
      <div className="text-slate-500 mb-0.5">Tick {label}</div>
      {/* eslint-disable-next-line @typescript-eslint/no-explicit-any */}
      {payload.map((p: any) => (
        <div key={p.dataKey} style={{ color: p.color }} className="font-semibold">
          {p.name}: {p.value}%
        </div>
      ))}
    </div>
  )
}

// ─── Ratio bar component ──────────────────────────────────────────────────────
function RatioBar({
  leftPct, leftColor, rightColor, leftLabel, rightLabel, markers = [],
}: {
  leftPct: number; leftColor: string; rightColor: string
  leftLabel: string; rightLabel: string
  markers?: { pct: number; color: string; label: string }[]
}) {
  return (
    <div>
      <div className="flex items-center justify-between mb-1">
        <span className="text-[10px] font-black" style={{ color: leftColor }}>{leftLabel} {leftPct.toFixed(0)}%</span>
        <span className="text-[10px] font-black" style={{ color: rightColor }}>{rightLabel} {(100 - leftPct).toFixed(0)}%</span>
      </div>
      <div className="relative">
        <div className="h-3 rounded-full overflow-hidden flex" style={{ background: "#1e2a3a" }}>
          <div className="h-full transition-all duration-700 ease-out" style={{ width: `${leftPct}%`, background: leftColor, opacity: 0.85 }} />
          <div className="h-full transition-all duration-700 ease-out" style={{ width: `${100 - leftPct}%`, background: rightColor, opacity: 0.85 }} />
        </div>
        {/* 50% midline */}
        <div className="absolute top-0 h-full w-px opacity-30 bg-white" style={{ left: "50%" }} />
        {markers.map(m => (
          <div key={m.pct} className="absolute top-0 h-full w-px" style={{ left: `${m.pct}%`, background: m.color, opacity: 0.6 }} />
        ))}
      </div>
      {markers.length > 0 && (
        <div className="relative h-3 mt-0.5">
          {markers.map(m => (
            <span key={m.pct} className="absolute text-[7px] font-bold" style={{ left: `${m.pct - 2}%`, color: m.color, opacity: 0.8 }}>
              {m.label}
            </span>
          ))}
        </div>
      )}
    </div>
  )
}

// ─── Main component ────────────────────────────────────────────────────────────

export default function DigitChart({
  digits, ticks, symbol, isConnected, stake = 0.35, onTrade
}: Props) {

  // ── Auto-trade state ──────────────────────────────────────────────────────
  const [autoTradeActive, setAutoTradeActive]     = useState(false)
  const [autoTradeCooldown, setAutoTradeCooldown] = useState(false)
  const [autoTradeLog, setAutoTradeLog]           = useState<AutoTradeLog[]>([])
  const autoTradeRef  = useRef(false)
  const cooldownRef   = useRef(false)
  const lastFireRef   = useRef(0)
  const logIdRef      = useRef(0)
  const onTradeRef    = useRef(onTrade)
  useEffect(() => { onTradeRef.current = onTrade }, [onTrade])
  useEffect(() => { autoTradeRef.current = autoTradeActive }, [autoTradeActive])
  useEffect(() => { cooldownRef.current  = autoTradeCooldown }, [autoTradeCooldown])

  // ── Derived digits ────────────────────────────────────────────────────────
  const allDigits = useMemo(() => {
    const fromTicks = ticks.slice(-100).map(getLastDigit)
    return digits.length >= fromTicks.length ? digits.slice(-100) : fromTicks
  }, [digits, ticks])

  const recent50 = allDigits.slice(-50)
  const recent25 = allDigits.slice(-25)
  const recent20 = allDigits.slice(-20)
  const last      = allDigits[allDigits.length - 1] ?? null

  // ── Signal (recomputed on every new tick) ─────────────────────────────────
  const signal = useMemo(() => computeSignal(allDigits), [allDigits])

  // ── Auto-trade fire ───────────────────────────────────────────────────────
  useEffect(() => {
    // Always declare the cleanup timer ref at the top level so return is unconditional
    let cooldownTimer: ReturnType<typeof setTimeout> | null = null

    const shouldRun =
      autoTradeRef.current &&
      isConnected &&
      !cooldownRef.current &&
      signal.shouldFire &&
      signal.direction &&
      signal.strength !== "WEAK"

    if (shouldRun) {
      const now = Date.now()
      if (now - lastFireRef.current >= 4000) {
        lastFireRef.current = now
        const contractType = signal.direction === "EVEN" ? "DIGITEVEN" : "DIGITODD"
        const id = ++logIdRef.current
        setAutoTradeLog(prev => [{
          id, time: now, type: signal.direction!, reason: signal.reason, result: "pending"
        }, ...prev].slice(0, 15))
        onTradeRef.current?.(contractType, "")
        cooldownRef.current = true
        setAutoTradeCooldown(true)
        cooldownTimer = setTimeout(() => {
          cooldownRef.current = false
          setAutoTradeCooldown(false)
        }, 4000)
      }
    }

    // Always return a cleanup function — prevents the conditional-return lint issue
    return () => { if (cooldownTimer) clearTimeout(cooldownTimer) }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [allDigits.length, isConnected, signal.shouldFire, signal.direction, signal.strength])

  const toggleAutoTrade = useCallback(() => {
    const next = !autoTradeRef.current
    autoTradeRef.current = next
    setAutoTradeActive(next)
    if (!next) { cooldownRef.current = false; setAutoTradeCooldown(false) }
    else { lastFireRef.current = 0 }
  }, [])

  // ── Stats ─────────────────────────────────────────────────────────────────
  const evenCount  = recent50.filter(isEven).length
  const oddCount   = recent50.length - evenCount
  const evenPct    = recent50.length > 0 ? (evenCount / recent50.length) * 100 : 50
  const oddPct     = 100 - evenPct
  const evenCount25= recent25.filter(isEven).length
  const evenPct25  = recent25.length > 0 ? (evenCount25 / recent25.length) * 100 : 50
  const overCount  = recent50.filter(isOver5).length
  const underCount = recent50.length - overCount
  const overPct    = recent50.length > 0 ? (overCount / recent50.length) * 100 : 50

  // Current streak
  let streak = 0; let streakType = ""
  for (let i = allDigits.length - 1; i >= 0; i--) {
    const t = isEven(allDigits[i]) ? "EVEN" : "ODD"
    if (i === allDigits.length - 1) streakType = t
    if (t === streakType) streak++; else break
  }

  // ── Frequency chart data ──────────────────────────────────────────────────
  const freqData = useMemo(() => {
    const counts = Array(10).fill(0) as number[]
    recent50.forEach(d => { if (d >= 0 && d <= 9) counts[d]++ })
    return counts.map((c, d) => ({
      digit: String(d),
      count: c,
      pct: recent50.length > 0 ? Math.round((c / recent50.length) * 100) : 0,
      even: isEven(d),
    }))
  }, [recent50])

  // ── Rolling ratio chart ────────────────────────────────────────────────────
  const rollingData = useMemo(() => {
    if (recent50.length < 10) return []
    return Array.from({ length: recent50.length - 9 }, (_, i) => {
      const w = recent50.slice(i, i + 10)
      const ec = w.filter(isEven).length
      return { idx: i + 10, evenPct: Math.round((ec / 10) * 100), oddPct: Math.round(((10 - ec) / 10) * 100) }
    })
  }, [recent50])

  // ── Over/Under hit-rates ──────────────────────────────────────────────────
  const thresholdStats = useMemo(() => {
    const stats: Record<string, { hits: number; pct: number; lastFive: boolean[] }> = {}
    if (recent50.length === 0) return stats
    OVER_THRESHOLDS.forEach(t => {
      const b = parseInt(t.barrier, 10)
      const hits = recent50.filter(d => d > b).length
      stats[`over_${t.barrier}`] = { hits, pct: Math.round((hits / recent50.length) * 100), lastFive: recent50.slice(-5).map(d => d > b) }
    })
    UNDER_THRESHOLDS.forEach(t => {
      const b = parseInt(t.barrier, 10)
      const hits = recent50.filter(d => d < b).length
      stats[`under_${t.barrier}`] = { hits, pct: Math.round((hits / recent50.length) * 100), lastFive: recent50.slice(-5).map(d => d < b) }
    })
    return stats
  }, [recent50])

  const isLoading   = allDigits.length < 15
  const signalColor = signal.direction === "EVEN" ? "#34d399" : signal.direction === "ODD" ? "#f87171" : "#64748b"
  const strengthColor: Record<string, string> = { STRONG:"#34d399", MODERATE:"#fbbf24", WEAK:"#64748b" }
  const sc = strengthColor[signal.strength]

  // ─── RENDER ───────────────────────────────────────────────────────────────
  return (
    <div className="rounded-2xl overflow-hidden" style={{ background:"#0d1117", border:"1px solid #1e2a3a" }}>

      {/* Header */}
      <div className="px-4 pt-4 pb-3 flex items-center justify-between" style={{ borderBottom:"1px solid #1e2a3a" }}>
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background:"rgba(167,139,250,0.1)", border:"1px solid rgba(167,139,250,0.25)" }}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#a78bfa" strokeWidth="2.5">
              <rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/>
            </svg>
          </div>
          <div>
            <p className="text-xs font-bold text-slate-200">Even / Odd Live Chart</p>
            <p className="text-[10px] text-slate-600">{symbol} · last {recent50.length} ticks</p>
          </div>
        </div>
        <div className="flex items-center gap-1.5">
          <span className={`w-1.5 h-1.5 rounded-full ${isConnected && !isLoading ? "bg-emerald-400 animate-pulse" : "bg-slate-600"}`} />
          <span className="text-[10px] text-slate-500">{isLoading ? `${allDigits.length}/15` : "Live"}</span>
        </div>
      </div>

      {isLoading ? (
        <div className="flex flex-col items-center justify-center py-16 gap-3">
          <div className="w-8 h-8 rounded-full border-2 border-violet-700/40 border-t-violet-400 animate-spin" />
          <p className="text-xs text-slate-600">Collecting digits… {allDigits.length}/15</p>
        </div>
      ) : (
        <div className="p-4 space-y-5">

          {/* ═══════════════════════════════════════════════════════════
              SECTION 1 — LIVE SIGNAL CARD (the "should I trade?" answer)
          ═══════════════════════════════════════════════════════════ */}
          <div
            className="rounded-2xl p-4 space-y-4"
            style={{
              background: signal.shouldFire
                ? signal.direction === "EVEN" ? "rgba(52,211,153,0.05)" : "rgba(248,113,113,0.05)"
                : "#080c14",
              border: `1px solid ${signal.shouldFire ? signalColor + "35" : "#1e2a3a"}`,
              transition: "all 0.4s",
            }}
          >
            {/* Big direction badge + score */}
            <div className="flex items-center gap-4">
              <div
                className="w-16 h-16 rounded-2xl flex flex-col items-center justify-center flex-shrink-0"
                style={{
                  background: signal.shouldFire ? `${signalColor}12` : "#0d1117",
                  border: `2px solid ${signal.shouldFire ? signalColor : "#1e2a3a"}`,
                }}
              >
                <span className="text-xl font-black leading-none" style={{ color: signal.shouldFire ? signalColor : "#334155" }}>
                  {signal.direction ?? "—"}
                </span>
                {signal.shouldFire && (
                  <span className="text-[8px] font-black mt-0.5 uppercase tracking-widest" style={{ color: sc }}>
                    {signal.strength}
                  </span>
                )}
              </div>

              <div className="flex-1 min-w-0 space-y-1.5">
                {/* Confidence score bar */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">Win Confidence</span>
                    <span className="text-xs font-black" style={{ color: signal.score >= 60 ? sc : "#64748b" }}>
                      {signal.score}%
                    </span>
                  </div>
                  <div className="h-2 rounded-full overflow-hidden" style={{ background:"#1e2a3a" }}>
                    <div
                      className="h-full rounded-full transition-all duration-700"
                      style={{
                        width:`${signal.score}%`,
                        background: signal.score >= 70 ? "#34d399" : signal.score >= 45 ? "#fbbf24" : "#f87171",
                      }}
                    />
                  </div>
                </div>
                {/* Reason */}
                <p className="text-[10px] leading-relaxed" style={{ color: signal.shouldFire ? "#94a3b8" : "#475569" }}>
                  {signal.reason}
                </p>
              </div>
            </div>

            {/* 3-window Even/Odd ratio bars */}
            <div className="space-y-2.5">
              <RatioBar
                leftPct={signal.evenPct50} leftColor="#34d399" rightColor="#f87171"
                leftLabel="EVEN" rightLabel="ODD"
                markers={[
                  { pct: 32, color:"#f87171", label:"32%" },
                  { pct: 68, color:"#34d399", label:"68%" },
                ]}
              />
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <div className="flex items-center justify-between mb-0.5">
                    <span className="text-[9px] text-slate-600 font-semibold">25-tick</span>
                    <span className="text-[9px] font-bold text-slate-500">E{signal.evenPct25.toFixed(0)}% O{signal.oddPct25.toFixed(0)}%</span>
                  </div>
                  <div className="h-1.5 rounded-full overflow-hidden flex" style={{ background:"#1e2a3a" }}>
                    <div className="h-full" style={{ width:`${signal.evenPct25}%`, background:"#34d399", opacity:0.7 }}/>
                    <div className="h-full" style={{ width:`${signal.oddPct25}%`,  background:"#f87171", opacity:0.7 }}/>
                  </div>
                </div>
                <div>
                  <div className="flex items-center justify-between mb-0.5">
                    <span className="text-[9px] text-slate-600 font-semibold">10-tick</span>
                    <span className="text-[9px] font-bold text-slate-500">E{signal.evenPct10.toFixed(0)}% O{signal.oddPct10.toFixed(0)}%</span>
                  </div>
                  <div className="h-1.5 rounded-full overflow-hidden flex" style={{ background:"#1e2a3a" }}>
                    <div className="h-full" style={{ width:`${signal.evenPct10}%`, background:"#34d399", opacity:0.7 }}/>
                    <div className="h-full" style={{ width:`${signal.oddPct10}%`,  background:"#f87171", opacity:0.7 }}/>
                  </div>
                </div>
              </div>
            </div>

            {/* Streak + last digit */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-[9px] text-slate-600 font-semibold uppercase tracking-wide">Streak</span>
                <span
                  className="text-xs font-black px-2 py-0.5 rounded-lg"
                  style={{
                    color:   signal.streakType === "EVEN" ? "#34d399" : signal.streakType === "ODD" ? "#f87171" : "#64748b",
                    background: signal.streakType === "EVEN" ? "rgba(52,211,153,0.1)" : signal.streakType === "ODD" ? "rgba(248,113,113,0.1)" : "#0d1117",
                    border: `1px solid ${signal.streakType === "EVEN" ? "rgba(52,211,153,0.25)" : signal.streakType === "ODD" ? "rgba(248,113,113,0.25)" : "#1e2a3a"}`,
                  }}
                >
                  {signal.streak}x {signal.streakType ?? "—"}
                </span>
                {signal.streak >= 4 && (
                  <span className="text-[8px] font-bold text-amber-500 bg-amber-950/40 border border-amber-800/40 px-1.5 py-0.5 rounded uppercase tracking-wide">
                    Reversion due
                  </span>
                )}
              </div>
              {last !== null && (
                <div className="flex items-center gap-1.5">
                  <span className="text-[9px] text-slate-600 font-semibold">Last digit</span>
                  <div
                    className="w-8 h-8 rounded-xl flex items-center justify-center font-black text-sm"
                    style={{
                      background: isEven(last) ? "rgba(52,211,153,0.1)" : "rgba(248,113,113,0.1)",
                      border:     isEven(last) ? "1px solid rgba(52,211,153,0.3)" : "1px solid rgba(248,113,113,0.3)",
                      color:      isEven(last) ? "#34d399" : "#f87171",
                    }}
                  >
                    {last}
                  </div>
                  <span className="text-[8px] font-bold" style={{ color: isEven(last) ? "#34d399" : "#f87171" }}>
                    {isEven(last) ? "EVEN" : "ODD"}
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* ═══════════════════════════════════════════════════════════
              SECTION 2 — EVEN / ODD REVERSION AUTO BOT
          ═══════════════════════════════════════════════════════════ */}
          <div
            className="rounded-2xl overflow-hidden"
            style={{
              background: autoTradeActive
                ? signal.direction === "EVEN" ? "rgba(52,211,153,0.04)" : "rgba(248,113,113,0.04)"
                : "#080c14",
              border: `1px solid ${autoTradeActive ? (signalColor + "30") : "#1e2a3a"}`,
              transition: "all 0.4s",
            }}
          >
            {/* Bot header row */}
            <div className="px-4 py-3 flex items-center justify-between" style={{ borderBottom:"1px solid #1e2a3a" }}>
              <div className="flex items-center gap-3">
                <div
                  className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
                  style={{
                    background: autoTradeActive ? `${signalColor}12` : "rgba(30,42,58,0.6)",
                    border:     `1px solid ${autoTradeActive ? signalColor + "30" : "#1e2a3a"}`,
                  }}
                >
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke={autoTradeActive ? signalColor : "#475569"} strokeWidth="2.5">
                    <circle cx="12" cy="12" r="3"/><path d="M12 1v4M12 19v4M4.22 4.22l2.83 2.83M16.95 16.95l2.83 2.83M1 12h4M19 12h4M4.22 19.78l2.83-2.83M16.95 7.05l2.83-2.83"/>
                  </svg>
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm font-black text-slate-100">Even Reversion Bot</span>
                    {autoTradeActive && (
                      <span className="text-[8px] font-black px-1.5 py-0.5 rounded uppercase tracking-widest animate-pulse"
                        style={{ color:signalColor, background:`${signalColor}15`, border:`1px solid ${signalColor}30` }}>
                        Running
                      </span>
                    )}
                    {autoTradeCooldown && (
                      <span className="text-[8px] font-bold px-1.5 py-0.5 rounded text-blue-400 bg-blue-950/40 border border-blue-800/40 uppercase tracking-wide">
                        Cooling
                      </span>
                    )}
                  </div>
                  <p className="text-[9px] text-slate-500 mt-0.5 leading-tight">
                    Fires EVEN when ODD {">"}= 68% · Fires ODD when EVEN {">"}= 68% · 4+ streak bonus
                  </p>
                </div>
              </div>

              {/* Toggle */}
              <button
                disabled={!isConnected}
                onClick={toggleAutoTrade}
                className={`relative w-14 h-7 rounded-full transition-all duration-200 flex-shrink-0 ${!isConnected ? "opacity-40 cursor-not-allowed" : "cursor-pointer"}`}
                style={{ background: autoTradeActive ? signalColor : "#1e2a3a", touchAction:"manipulation" }}
              >
                <div
                  className="absolute top-1 w-5 h-5 rounded-full bg-white shadow transition-all duration-200"
                  style={{ left: autoTradeActive ? "34px" : "4px" }}
                />
              </button>
            </div>

            {/* Manual Even/Odd buttons */}
            <div className="p-3 grid grid-cols-2 gap-2">
              <button
                disabled={!isConnected}
                onClick={() => onTrade?.("DIGITEVEN", "")}
                className="py-4 rounded-xl font-black text-base uppercase tracking-wide border active:scale-[0.97] transition-all duration-100 flex items-center justify-center gap-2"
                style={{
                  touchAction:"manipulation",
                  background: isConnected ? "rgba(52,211,153,0.08)" : "#0a0e1a",
                  borderColor: isConnected
                    ? (signal.direction === "EVEN" && signal.shouldFire ? "#34d399" : "rgba(52,211,153,0.3)")
                    : "#1e2a3a",
                  color: isConnected ? "#34d399" : "#334155",
                  cursor: isConnected ? "pointer" : "not-allowed",
                  boxShadow: signal.direction === "EVEN" && signal.shouldFire && isConnected
                    ? "0 0 20px rgba(52,211,153,0.2)" : "none",
                }}
              >
                {signal.direction === "EVEN" && signal.shouldFire && (
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse flex-shrink-0" />
                )}
                EVEN
              </button>
              <button
                disabled={!isConnected}
                onClick={() => onTrade?.("DIGITODD", "")}
                className="py-4 rounded-xl font-black text-base uppercase tracking-wide border active:scale-[0.97] transition-all duration-100 flex items-center justify-center gap-2"
                style={{
                  touchAction:"manipulation",
                  background: isConnected ? "rgba(248,113,113,0.08)" : "#0a0e1a",
                  borderColor: isConnected
                    ? (signal.direction === "ODD" && signal.shouldFire ? "#f87171" : "rgba(248,113,113,0.3)")
                    : "#1e2a3a",
                  color: isConnected ? "#f87171" : "#334155",
                  cursor: isConnected ? "pointer" : "not-allowed",
                  boxShadow: signal.direction === "ODD" && signal.shouldFire && isConnected
                    ? "0 0 20px rgba(248,113,113,0.2)" : "none",
                }}
              >
                {signal.direction === "ODD" && signal.shouldFire && (
                  <span className="w-2 h-2 rounded-full bg-red-400 animate-pulse flex-shrink-0" />
                )}
                ODD
              </button>
            </div>

            {/* Bot trade log */}
            {autoTradeLog.length > 0 && (
              <div className="px-3 pb-3">
                <p className="text-[8px] text-slate-700 font-bold uppercase tracking-widest mb-1.5">Bot log (last {autoTradeLog.length})</p>
                <div className="space-y-1 max-h-24 overflow-y-auto">
                  {autoTradeLog.map(log => (
                    <div key={log.id} className="flex items-center gap-2 rounded-lg px-2 py-1" style={{ background:"#0a0e1a", border:"1px solid #1e2a3a" }}>
                      <span className="text-[9px] font-black" style={{ color: log.type === "EVEN" ? "#34d399" : "#f87171", minWidth:28 }}>{log.type}</span>
                      <span className="text-[8px] text-slate-600 flex-1 truncate">{log.reason}</span>
                      <span className="text-[8px] font-bold" style={{ color: log.result === "pending" ? "#64748b" : log.result === "win" ? "#34d399" : "#f87171" }}>
                        {log.result === "pending" ? "..." : log.result}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* ═══════════════════════════════════════════════════════════
              SECTION 3 — LAST 20 DIGIT DOTS
          ═══════════════════════════════════════════════════════════ */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Last 20 Digits</span>
              <span className="text-[9px] text-slate-700">green=even · red=odd</span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {recent20.map((d, i) => (
                <div
                  key={i}
                  className="w-8 h-8 rounded-lg flex items-center justify-center font-black text-xs"
                  style={{
                    background: isEven(d) ? "rgba(52,211,153,0.1)"  : "rgba(248,113,113,0.1)",
                    border:     isEven(d) ? "1px solid rgba(52,211,153,0.3)" : "1px solid rgba(248,113,113,0.3)",
                    color:      isEven(d) ? "#34d399" : "#f87171",
                  }}
                >
                  {d}
                </div>
              ))}
            </div>
          </div>

          {/* ═══════════════════════════════════════════════════════════
              SECTION 4 — ROLLING RATIO LINE CHART
          ═══════════════════════════════════════════════════════════ */}
          {rollingData.length >= 5 && (
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Rolling 10-tick Ratio</span>
                <span className="text-[9px] text-slate-700">trend over time</span>
              </div>
              <ResponsiveContainer width="100%" height={90}>
                <LineChart data={rollingData} margin={{ top:4, right:4, left:-24, bottom:0 }}>
                  <CartesianGrid stroke="#1e2a3a" strokeDasharray="3 3" />
                  <XAxis dataKey="idx" tick={{ fill:"#334155", fontSize:8 }} />
                  <YAxis domain={[0,100]} tick={{ fill:"#334155", fontSize:8 }} />
                  <Tooltip content={<ChartTooltip />} />
                  <ReferenceLine y={68} stroke="#f87171" strokeDasharray="4 2" strokeOpacity={0.4} />
                  <ReferenceLine y={32} stroke="#34d399" strokeDasharray="4 2" strokeOpacity={0.4} />
                  <ReferenceLine y={50} stroke="#475569" strokeDasharray="2 2" strokeOpacity={0.3} />
                  <Line type="monotone" dataKey="evenPct" stroke="#34d399" strokeWidth={2} dot={false} name="Even%" />
                  <Line type="monotone" dataKey="oddPct"  stroke="#f87171" strokeWidth={2} dot={false} name="Odd%" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          )}

          {/* ═══════════════════════════════════════════════════════════
              SECTION 5 — DIGIT FREQUENCY BAR CHART
          ═══════════════════════════════════════════════════════════ */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Digit Frequency (50 ticks)</span>
              <span className="text-[9px] text-slate-700">green=even · red=odd</span>
            </div>
            <ResponsiveContainer width="100%" height={90}>
              <BarChart data={freqData} margin={{ top:2, right:4, left:-24, bottom:0 }}>
                <CartesianGrid stroke="#1e2a3a" strokeDasharray="3 3" />
                <XAxis dataKey="digit" tick={{ fill:"#475569", fontSize:9 }} />
                <YAxis tick={{ fill:"#334155", fontSize:8 }} />
                <Tooltip content={<ChartTooltip />} />
                <Bar dataKey="pct" radius={[3,3,0,0]} name="Freq%">
                  {freqData.map(entry => (
                    <Cell key={entry.digit} fill={entry.even ? "#34d399" : "#f87171"} fillOpacity={0.75} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* ═══════════════════════════════════════════════════════════
              SECTION 6 — OVER / UNDER TRADE PANEL
          ═══════════════════════════════════════════════════════════ */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <div className="w-5 h-5 rounded flex items-center justify-center" style={{ background:"rgba(52,211,153,0.1)", border:"1px solid rgba(52,211,153,0.25)" }}>
                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#34d399" strokeWidth="2.5">
                  <polyline points="18 15 12 9 6 15"/>
                </svg>
              </div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Over / Under Panel</span>
              <span className="text-[9px] text-slate-700">stake ${stake.toFixed(2)}</span>
            </div>
            <div className="rounded-xl p-3 space-y-2" style={{ background:"#080c14", border:"1px solid #1e2a3a" }}>
              {[...OVER_THRESHOLDS, ...UNDER_THRESHOLDS].map(t => {
                const key = t.label.startsWith("Over") ? `over_${t.barrier}` : `under_${t.barrier}`
                const s = thresholdStats[key]
                const pct = s?.pct ?? 0
                const isOver = t.label.startsWith("Over")
                const contractType = isOver ? "DIGITOVER" : "DIGITUNDER"
                const lastFive = s?.lastFive ?? []
                return (
                  <div key={t.label} className="flex items-center gap-2 rounded-lg px-3 py-2.5" style={{ background:"#0d1117", border:"1px solid #1e2a3a" }}>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-black" style={{ color: t.color }}>{t.label}</span>
                        <span className="text-[9px] font-bold" style={{ color: pct >= 80 ? "#34d399" : pct >= 60 ? "#fbbf24" : "#f87171" }}>{pct}%</span>
                      </div>
                      <div className="h-1.5 rounded-full overflow-hidden" style={{ background:"#1e2a3a" }}>
                        <div className="h-full rounded-full transition-all duration-500" style={{ width:`${pct}%`, background: t.color }}/>
                      </div>
                      <div className="flex items-center justify-between mt-1">
                        <span className="text-[8px] text-slate-700">{t.desc}</span>
                        <div className="flex gap-0.5">
                          {lastFive.map((hit,i) => (
                            <span key={i} className="w-2 h-2 rounded-full" style={{ background: hit ? "#34d399" : "#f87171", opacity:0.8 }} />
                          ))}
                        </div>
                      </div>
                    </div>
                    <button
                      disabled={!isConnected}
                      onClick={() => onTrade?.(contractType, t.barrier)}
                      className="flex-shrink-0 px-3 py-2 rounded-xl font-black text-[10px] uppercase tracking-wide border active:scale-[0.96] transition-all duration-100"
                      style={{
                        touchAction:"manipulation",
                        background: isConnected ? `${t.color}12` : "#0a0e1a",
                        borderColor: isConnected ? `${t.color}40` : "#1e2a3a",
                        color: isConnected ? t.color : "#334155",
                        cursor: isConnected ? "pointer" : "not-allowed",
                      }}
                    >
                      Trade
                    </button>
                  </div>
                )
              })}
            </div>
          </div>

          {/* ═══════════════════════════════════════════════════════════
              SECTION 7 — MATCH / DIFFER PANEL
          ═══════════════════════════════════════════════════════════ */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <div className="w-5 h-5 rounded flex items-center justify-center" style={{ background:"rgba(167,139,250,0.1)", border:"1px solid rgba(167,139,250,0.25)" }}>
                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#a78bfa" strokeWidth="2.5">
                  <circle cx="9" cy="12" r="1"/><circle cx="15" cy="12" r="1"/>
                </svg>
              </div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Match / Differ Panel</span>
            </div>
            <div className="rounded-xl p-3 space-y-3" style={{ background:"#080c14", border:"1px solid #1e2a3a" }}>
              {(() => {
                const differCount = recent50.length > 1 ? recent50.filter((d,i,a) => i > 0 && d !== a[i-1]).length : 0
                const matchCount  = recent50.length > 1 ? (recent50.length - 1) - differCount : 0
                const total       = differCount + matchCount
                const differPct   = total > 0 ? Math.round((differCount / total) * 100) : 90
                const matchPct    = 100 - differPct
                return (
                  <>
                    <RatioBar leftPct={differPct} leftColor="#a78bfa" rightColor="#f472b6"
                      leftLabel="DIFFER" rightLabel="MATCH" />
                    <p className="text-[9px] text-slate-600 text-center leading-relaxed">
                      Differ is expected ~90% of the time · Match is rare · Trade Differ for consistency
                    </p>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        disabled={!isConnected}
                        onClick={() => onTrade?.("DIGITDIFF", "")}
                        className="py-3.5 rounded-xl font-black text-sm uppercase tracking-wide border active:scale-[0.97] transition-all duration-100"
                        style={{
                          touchAction:"manipulation",
                          background: isConnected ? "rgba(167,139,250,0.08)" : "#0a0e1a",
                          borderColor: isConnected ? "rgba(167,139,250,0.35)" : "#1e2a3a",
                          color: isConnected ? "#a78bfa" : "#334155",
                          cursor: isConnected ? "pointer" : "not-allowed",
                        }}
                      >
                        DIFFER
                      </button>
                      <button
                        disabled={!isConnected}
                        onClick={() => onTrade?.("DIGITMATCH", "")}
                        className="py-3.5 rounded-xl font-black text-sm uppercase tracking-wide border active:scale-[0.97] transition-all duration-100"
                        style={{
                          touchAction:"manipulation",
                          background: isConnected ? "rgba(244,114,182,0.08)" : "#0a0e1a",
                          borderColor: isConnected ? "rgba(244,114,182,0.35)" : "#1e2a3a",
                          color: isConnected ? "#f472b6" : "#334155",
                          cursor: isConnected ? "pointer" : "not-allowed",
                        }}
                      >
                        MATCH
                      </button>
                    </div>
                  </>
                )
              })()}
            </div>
          </div>

          {/* ═══════════════════════════════════════════════════════════
              SECTION 8 — RISE / FALL PANEL
          ═══════════════════════════════════════════════════════════ */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <div className="w-5 h-5 rounded flex items-center justify-center" style={{ background:"rgba(52,211,153,0.1)", border:"1px solid rgba(52,211,153,0.25)" }}>
                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#34d399" strokeWidth="2.5">
                  <polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/>
                </svg>
              </div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Rise / Fall Panel</span>
            </div>
            <div className="rounded-xl p-3 space-y-3" style={{ background:"#080c14", border:"1px solid #1e2a3a" }}>
              {(() => {
                const rises = ticks.length > 1 ? ticks.slice(-50).filter((p,i,a) => i > 0 && p > a[i-1]).length : 0
                const falls = ticks.length > 1 ? ticks.slice(-50).filter((p,i,a) => i > 0 && p < a[i-1]).length : 0
                const total    = rises + falls || 1
                const risePct  = Math.round((rises / total) * 100)
                const fallPct  = 100 - risePct
                const trend    = risePct >= 60 ? "RISING" : fallPct >= 60 ? "FALLING" : "NEUTRAL"
                const trendClr = trend === "RISING" ? "#34d399" : trend === "FALLING" ? "#f87171" : "#64748b"
                return (
                  <>
                    <RatioBar leftPct={risePct} leftColor="#34d399" rightColor="#f87171" leftLabel="RISE" rightLabel="FALL" />
                    <div className="flex items-center justify-center">
                      <span className="text-[10px] font-black px-3 py-1 rounded-lg uppercase tracking-widest"
                        style={{ color:trendClr, background:`${trendClr}12`, border:`1px solid ${trendClr}30` }}>
                        {trend === "RISING" ? "Price trending up — RISE has edge"
                          : trend === "FALLING" ? "Price trending down — FALL has edge"
                          : "Balanced — no clear directional edge"}
                      </span>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        disabled={!isConnected}
                        onClick={() => onTrade?.("CALL", "")}
                        className="py-3.5 rounded-xl font-black text-sm uppercase tracking-wide border active:scale-[0.97] transition-all duration-100 flex items-center justify-center gap-1.5"
                        style={{
                          touchAction:"manipulation",
                          background: isConnected ? (trend==="RISING" ? "rgba(52,211,153,0.15)" : "rgba(52,211,153,0.06)") : "#0a0e1a",
                          borderColor: isConnected ? (trend==="RISING" ? "rgba(52,211,153,0.5)" : "rgba(52,211,153,0.25)") : "#1e2a3a",
                          color: isConnected ? "#34d399" : "#334155",
                          cursor: isConnected ? "pointer" : "not-allowed",
                          boxShadow: trend==="RISING" && isConnected ? "0 0 16px rgba(52,211,153,0.15)" : "none",
                        }}
                      >
                        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                          <polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/>
                        </svg>
                        RISE
                      </button>
                      <button
                        disabled={!isConnected}
                        onClick={() => onTrade?.("PUT", "")}
                        className="py-3.5 rounded-xl font-black text-sm uppercase tracking-wide border active:scale-[0.97] transition-all duration-100 flex items-center justify-center gap-1.5"
                        style={{
                          touchAction:"manipulation",
                          background: isConnected ? (trend==="FALLING" ? "rgba(248,113,113,0.15)" : "rgba(248,113,113,0.06)") : "#0a0e1a",
                          borderColor: isConnected ? (trend==="FALLING" ? "rgba(248,113,113,0.5)" : "rgba(248,113,113,0.25)") : "#1e2a3a",
                          color: isConnected ? "#f87171" : "#334155",
                          cursor: isConnected ? "pointer" : "not-allowed",
                          boxShadow: trend==="FALLING" && isConnected ? "0 0 16px rgba(248,113,113,0.15)" : "none",
                        }}
                      >
                        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                          <polyline points="23 18 13.5 8.5 8.5 13.5 1 6"/><polyline points="17 18 23 18 23 12"/>
                        </svg>
                        FALL
                      </button>
                    </div>
                  </>
                )
              })()}
            </div>
          </div>

        </div>
      )}
    </div>
  )
}
