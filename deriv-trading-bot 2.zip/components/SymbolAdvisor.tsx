"use client"

import { Target, TrendingUp, Shuffle } from "lucide-react"
import { PAIR_COMPATIBILITY } from "@/components/TradingStrategies"

// Full symbol label map
const SYMBOL_LABELS: Record<string, string> = {
  R_10:    "Volatility 10 Index",
  R_25:    "Volatility 25 Index",
  R_50:    "Volatility 50 Index",
  R_75:    "Volatility 75 Index",
  R_100:   "Volatility 100 Index",
  "1HZ10V":  "Volatility 10 (1s) Index",
  "1HZ25V":  "Volatility 25 (1s) Index",
  "1HZ50V":  "Volatility 50 (1s) Index",
  "1HZ75V":  "Volatility 75 (1s) Index",
  "1HZ100V": "Volatility 100 (1s) Index",
}

// Strategy display names
const STRATEGY_NAMES: Record<string, string> = {
  digitai:     "DigitAI (Even/Odd)",
  unibet:      "Unibet (Rise/Fall)",
  tradex:      "TradeX (Match/Differ)",
  optimax:     "OptimaX (Over/Under)",
  accumulator: "Accumulator Bot",
  autors:      "Auto RS (Touch/No Touch)",
}

// Best autopilot mode per regime
const REGIME_MODE_TIPS: Record<string, {
  recommended: string
  reason: string
  color: string
}> = {
  Ranging: {
    recommended: "Precision",
    reason: "Range markets need tight gates — only take the clearest setups",
    color: "text-blue-400",
  },
  Trending: {
    recommended: "Balanced",
    reason: "Trending markets provide reliable entries — balanced mode captures them well",
    color: "text-emerald-400",
  },
  Volatile: {
    recommended: "Conservative",
    reason: "Volatile conditions — tight risk management, fewer trades, bigger signals only",
    color: "text-orange-400",
  },
}

interface Props {
  activeStrategy: string | null
  currentSymbol: string
  regime: "Ranging" | "Trending" | "Volatile"
  pilotMode: string
  onSymbolChange?: (symbol: string) => void
}

export default function SymbolAdvisor({ activeStrategy, currentSymbol, regime, pilotMode, onSymbolChange }: Props) {
  if (!activeStrategy) return null

  const pairs = PAIR_COMPATIBILITY[activeStrategy] ?? []
  const best = pairs.filter(p => p.rating === 3)
  const current = pairs.find(p => p.symbol === currentSymbol)
  const regimeTip = REGIME_MODE_TIPS[regime]

  // Is the current symbol optimal?
  const isOptimal = current?.rating === 3
  const topRecommendation = best[0]

  return (
    <div className="trade-card space-y-3">
      {/* Header */}
      <div className="flex items-center gap-2">
        <Target size={15} className="text-amber-400" />
        <span className="text-sm font-semibold text-slate-200">Symbol Advisor</span>
        <span className="text-[9px] px-1.5 py-0.5 rounded bg-amber-900/20 text-amber-400 border border-amber-800/30 font-bold ml-auto">
          {STRATEGY_NAMES[activeStrategy] ?? activeStrategy}
        </span>
      </div>

      {/* Current symbol rating */}
      <div className={`flex items-center gap-3 p-2.5 rounded-xl border ${
        isOptimal
          ? "bg-emerald-950/20 border-emerald-800/30"
          : current?.rating === 2
          ? "bg-yellow-950/20 border-yellow-800/30"
          : "bg-red-950/20 border-red-800/30"
      }`}>
        <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${
          isOptimal ? "bg-emerald-900/30" : "bg-slate-800/50"
        }`}>
          <TrendingUp size={14} className={isOptimal ? "text-emerald-400" : "text-slate-500"} />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-200">
              {SYMBOL_LABELS[currentSymbol] ?? currentSymbol}
            </span>
            <span className={`text-[9px] px-1.5 py-0.5 rounded border font-bold ${
              isOptimal
                ? "text-emerald-400 bg-emerald-900/30 border-emerald-800/30"
                : current?.rating === 2
                ? "text-yellow-400 bg-yellow-900/30 border-yellow-800/30"
                : "text-red-400 bg-red-900/30 border-red-800/30"
            }`}>
              {isOptimal ? "Ideal" : current?.rating === 2 ? "Acceptable" : current ? "Weak match" : "Not rated"}
            </span>
          </div>
          <p className="text-[10px] text-slate-500 mt-0.5 leading-tight">
            {current?.note ?? "No compatibility data for this symbol."}
          </p>
        </div>
      </div>

      {/* Recommendation — only show if current is not ideal */}
      {!isOptimal && topRecommendation && (
        <div className="rounded-xl border border-blue-800/30 bg-blue-950/15 p-2.5">
          <div className="flex items-center gap-2 mb-1.5">
            <Shuffle size={12} className="text-blue-400 flex-shrink-0" />
            <span className="text-[10px] font-bold text-blue-300">Switch to best pair</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-200">
              {SYMBOL_LABELS[topRecommendation.symbol] ?? topRecommendation.symbol}
            </span>
            {onSymbolChange && (
              <button
                onClick={() => onSymbolChange(topRecommendation.symbol)}
                className="ml-auto text-[10px] px-2.5 py-1 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold transition-colors"
              >
                Switch
              </button>
            )}
          </div>
          <p className="text-[10px] text-slate-500 mt-1 leading-tight">{topRecommendation.note}</p>
        </div>
      )}

      {/* All best pairs chips */}
      {best.length > 1 && (
        <div>
          <p className="text-[9px] text-slate-600 mb-1.5 font-medium uppercase tracking-wide">Top pairs for this strategy</p>
          <div className="flex flex-wrap gap-1.5">
            {best.map(p => (
              <button
                key={p.symbol}
                onClick={() => onSymbolChange?.(p.symbol)}
                className={`text-[10px] px-2 py-1 rounded-lg border font-bold transition-colors ${
                  p.symbol === currentSymbol
                    ? "text-emerald-300 bg-emerald-900/30 border-emerald-700/50"
                    : "text-slate-400 bg-slate-800/30 border-slate-700/30 hover:border-slate-500 hover:text-slate-300"
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Auto-pilot mode recommendation */}
      {regimeTip && (
        <div className="rounded-xl border border-[#1e2a3a] bg-[#0d1117] p-2.5 space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-slate-500 font-medium">Recommended auto-pilot for {regime} market</span>
            <span className={`text-[10px] font-bold ${regimeTip.color}`}>{regimeTip.recommended}</span>
          </div>
          <p className="text-[9px] text-slate-600 leading-tight">{regimeTip.reason}</p>
          {pilotMode.toLowerCase() !== regimeTip.recommended.toLowerCase() && (
            <p className={`text-[9px] font-semibold ${regimeTip.color}`}>
              You are using <span className="capitalize">{pilotMode}</span> — consider switching to {regimeTip.recommended} for better results.
            </p>
          )}
        </div>
      )}
    </div>
  )
}
