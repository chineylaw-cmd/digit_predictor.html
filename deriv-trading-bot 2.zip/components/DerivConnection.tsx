"use client"
import { useState } from "react"
import { Wifi, WifiOff, Eye, EyeOff, Copy, Check, ExternalLink } from "lucide-react"

interface Props {
  isConnected: boolean
  isConnecting: boolean
  balance: number | null
  currency: string
  accountType: string
  onConnect: (token: string) => void
  onDisconnect: () => void
  error: string
}

export default function DerivConnection({
  isConnected, isConnecting, balance, currency, accountType,
  onConnect, onDisconnect, error
}: Props) {
  const [token, setToken] = useState("")
  const [showToken, setShowToken] = useState(false)
  const [copied, setCopied] = useState(false)

  const handleConnect = () => {
    if (token.trim()) onConnect(token.trim())
  }

  const handleCopy = async () => {
    if (token) {
      await navigator.clipboard.writeText(token)
      setCopied(true)
      setTimeout(() => setCopied(false), 1500)
    }
  }

  return (
    <div className="trade-card">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-[#1e2a3a] flex items-center justify-center">
            <Wifi size={16} className="text-blue-400" />
          </div>
          <div>
            <div className="text-sm font-semibold text-slate-200">Deriv Connection</div>
            <div className="text-xs text-slate-500">API Token required</div>
          </div>
        </div>
        <div className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold ${
          isConnected ? "bg-emerald-900/40 text-emerald-400 border border-emerald-700/50"
          : "bg-slate-800 text-slate-400 border border-slate-700"
        }`}>
          <span className={`w-1.5 h-1.5 rounded-full ${isConnected ? "bg-emerald-400 pulse-live" : "bg-slate-500"}`} />
          {isConnected ? "Online" : "Offline"}
        </div>
      </div>

      {/* Connected state */}
      {isConnected && balance !== null && (
        <div className="mb-4 p-3 bg-emerald-900/20 border border-emerald-700/40 rounded-xl">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-xs text-emerald-400 font-medium mb-0.5">Balance</div>
              <div className="text-xl font-bold text-emerald-300">
                {balance.toFixed(2)} <span className="text-sm">{currency}</span>
              </div>
              <div className="text-xs text-slate-400 mt-0.5">{accountType}</div>
            </div>
            <button
              onClick={onDisconnect}
              className="px-3 py-1.5 bg-red-900/40 border border-red-700/50 text-red-400 rounded-lg text-xs font-semibold hover:bg-red-900/60 transition-colors"
            >
              Disconnect
            </button>
          </div>
        </div>
      )}

      {/* Token input */}
      {!isConnected && (
        <>
          <div className="relative mb-3">
            <input
              type={showToken ? "text" : "password"}
              value={token}
              onChange={e => setToken(e.target.value)}
              placeholder="Paste your Deriv API token"
              className="w-full bg-[#0a0e1a] border border-[#1e2a3a] rounded-xl px-4 py-3 text-sm text-slate-300 placeholder-slate-600 outline-none focus:border-blue-500/60 pr-20 transition-colors"
              onKeyDown={e => e.key === "Enter" && handleConnect()}
            />
            <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-2">
              <button onClick={() => setShowToken(v => !v)} className="text-slate-500 hover:text-slate-300 transition-colors">
                {showToken ? <EyeOff size={15} /> : <Eye size={15} />}
              </button>
              <button onClick={handleCopy} className="text-slate-500 hover:text-slate-300 transition-colors">
                {copied ? <Check size={15} className="text-emerald-400" /> : <Copy size={15} />}
              </button>
            </div>
          </div>

          {error && (
            <div className="mb-3 px-3 py-2 bg-red-900/30 border border-red-700/40 rounded-lg text-xs text-red-400">
              {error}
            </div>
          )}

          <button
            onClick={handleConnect}
            disabled={!token.trim() || isConnecting}
            className="btn-connect w-full py-3 rounded-xl text-sm font-semibold tracking-wide transition-opacity disabled:opacity-50"
          >
            {isConnecting ? (
              <span className="flex items-center justify-center gap-2">
                <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Connecting...
              </span>
            ) : "Connect to Deriv"}
          </button>

          {/* Instructions */}
          <div className="mt-4 p-3 bg-[#0a0e1a] border border-[#1a2236] rounded-xl">
            <div className="text-xs font-semibold text-slate-400 mb-2 flex items-center gap-1">
              How to get your API token:
            </div>
            <ol className="space-y-1 text-xs text-slate-500">
              <li>1. Log in to your Deriv account</li>
              <li>2. Go to Settings → API Token</li>
              <li>3. Create token with &quot;Trade&quot; permission</li>
              <li>4. Copy and paste it above</li>
            </ol>
            <a
              href="https://app.deriv.com/account/api-token"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1 mt-2 text-xs text-blue-400 hover:text-blue-300 transition-colors"
            >
              <ExternalLink size={11} /> Get API Token
            </a>
          </div>
        </>
      )}
    </div>
  )
}
