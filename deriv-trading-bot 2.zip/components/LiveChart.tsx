"use client"
import { useMemo } from "react"
import { Activity, TrendingUp, TrendingDown } from "lucide-react"
import {
  AreaChart, Area, XAxis, YAxis, Tooltip,
  ResponsiveContainer, ReferenceLine, CartesianGrid,
} from "recharts"
import { calcBollingerBands, calcRSI, calcMACD, calcStochastic, calcEMA } from "@/lib/indicators"

interface Props {
  ticks: number[]
  symbol: string
  upCount: number
  downCount: number
  lastQuote: number | null
  isConnected: boolean
}

const NEEDED = 60
const DISPLAY = 80

function formatQuote(n: number) {
  if (n >= 1000) return n.toFixed(2)
  if (n >= 100) return n.toFixed(3)
  return n.toFixed(4)
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function PriceTooltip({ active, payload }: any) {
  if (!active || !payload?.length) return null
  return (
    <div className="bg-[#0d1526] border border-[#1e2a3a] rounded-lg px-2 py-1 text-xs">
      <span className="text-slate-400">Price: </span>
      <span className="text-blue-300 font-mono font-bold">{formatQuote(payload[0]?.value ?? 0)}</span>
    </div>
  )
}

export default function LiveChart({ ticks, symbol, upCount, downCount, lastQuote, isConnected }: Props) {
  const isReady = ticks.length >= NEEDED
  const displayTicks = ticks.slice(-DISPLAY)

  // Compute indicators once
  const indicators = useMemo(() => {
    if (!isReady) return null
    const bb = calcBollingerBands(ticks, 20, 2)
    const ema14arr = calcEMA(ticks, 14)
    const rsi = calcRSI(ticks, 14)
    const macd = calcMACD(ticks)
    const stoch = calcStochastic(ticks, 14)
    return {
      bb,
      ema14: ema14arr[ema14arr.length - 1] ?? 0,
      rsi,
      macd,
      stoch,
    }
  }, [ticks, isReady])

  // Build chart data once
  const chartData = useMemo(() =>
    displayTicks.map((price, i) => ({ i, price })),
    [displayTicks]
  )

  // Price range with padding
  const { minY, maxY } = useMemo(() => {
    if (!displayTicks.length) return { minY: 0, maxY: 1 }
    const lo = Math.min(...displayTicks)
    const hi = Math.max(...displayTicks)
    const pad = (hi - lo) * 0.15 || 0.001
    return { minY: lo - pad, maxY: hi + pad }
  }, [displayTicks])

  // Trend: compare last price vs 20-tick-ago price
  const trend = useMemo(() => {
    if (displayTicks.length < 20) return "neutral"
    const recent = displayTicks[displayTicks.length - 1]
    const past = displayTicks[displayTicks.length - 20]
    return recent > past ? "up" : recent < past ? "down" : "neutral"
  }, [displayTicks])

  const lineColor = trend === "up" ? "#10b981" : trend === "down" ? "#ef4444" : "#3b82f6"
  const fillColor = trend === "up" ? "#10b981" : trend === "down" ? "#ef4444" : "#3b82f6"

  // Indicator pills config
  const pills = useMemo(() => {
    if (!indicators) return []
    const { rsi, macd, stoch, bb } = indicators
    const last = displayTicks[displayTicks.length - 1] ?? 0
    const bbPct = bb.upper !== bb.lower
      ? ((last - bb.lower) / (bb.upper - bb.lower)) * 100
      : 50

    return [
      {
        label: "RSI",
        value: rsi.toFixed(1),
        sub: rsi > 70 ? "Overbought" : rsi < 30 ? "Oversold" : "Neutral",
        color: rsi > 70 ? "text-red-400" : rsi < 30 ? "text-emerald-400" : "text-slate-300",
        bg: rsi > 70 ? "bg-red-950/40 border-red-800/40" : rsi < 30 ? "bg-emerald-950/40 border-emerald-800/40" : "bg-[#0d1526] border-[#1e2a3a]",
      },
      {
        label: "MACD",
        value: (macd.histogram > 0 ? "+" : "") + macd.histogram.toFixed(3),
        sub: macd.histogram > 0 ? "Bullish" : "Bearish",
        color: macd.histogram > 0 ? "text-emerald-400" : "text-red-400",
        bg: macd.histogram > 0 ? "bg-emerald-950/40 border-emerald-800/40" : "bg-red-950/40 border-red-800/40",
      },
      {
        label: "STOCH",
        value: stoch.k.toFixed(1),
        sub: stoch.k > 80 ? "Overbought" : stoch.k < 20 ? "Oversold" : "Neutral",
        color: stoch.k > 80 ? "text-red-400" : stoch.k < 20 ? "text-emerald-400" : "text-slate-300",
        bg: stoch.k > 80 ? "bg-red-950/40 border-red-800/40" : stoch.k < 20 ? "bg-emerald-950/40 border-emerald-800/40" : "bg-[#0d1526] border-[#1e2a3a]",
      },
      {
        label: "BB%",
        value: bbPct.toFixed(0) + "%",
        sub: bbPct > 80 ? "Near Upper" : bbPct < 20 ? "Near Lower" : "Mid Range",
        color: "text-yellow-400",
        bg: "bg-yellow-950/30 border-yellow-800/30",
      },
    ]
  }, [indicators, displayTicks])

  return (
    <div className="trade-card">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Activity size={15} className="text-blue-400" />
          <span className="text-sm font-semibold text-slate-200">Live Chart</span>
          <span className="text-[10px] px-1.5 py-0.5 bg-[#1e2a3a] text-slate-400 rounded font-mono">{symbol}</span>
        </div>
        <div className={`flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-lg ${
          isReady
            ? "bg-emerald-900/30 text-emerald-400 border border-emerald-700/30"
            : "bg-slate-800/60 text-slate-500 border border-slate-700/40"
        }`}>
          {isReady && <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 pulse-live" />}
          {isReady ? "LIVE" : "WAIT"}
        </div>
      </div>

      {/* Quote + direction row */}
      <div className="flex items-start justify-between mb-4 px-0.5">
        <div>
          <div className="text-[10px] text-slate-500 mb-0.5 uppercase tracking-wide">Last Quote</div>
          <div className="text-xl font-mono font-bold text-slate-100 tracking-tight">
            {lastQuote ? formatQuote(lastQuote) : <span className="text-slate-600">——.————</span>}
          </div>
        </div>
        <div className="flex flex-col items-end gap-1">
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 text-xs text-emerald-400 font-semibold">
              <TrendingUp size={12} />
              <span>{upCount} UP</span>
            </div>
            <div className="flex items-center gap-1 text-xs text-red-400 font-semibold">
              <TrendingDown size={12} />
              <span>{downCount} DN</span>
            </div>
          </div>
          <div className="text-[10px] text-slate-600">{ticks.length} ticks</div>
        </div>
      </div>

      {/* Chart */}
      <div className="relative rounded-xl overflow-hidden bg-[#070d1a] border border-[#1a2436]" style={{ height: 160 }}>
        {!isConnected ? (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-2">
            <Activity size={22} className="text-slate-700" />
            <p className="text-xs text-slate-600">Connect to Deriv to stream data</p>
          </div>
        ) : !isReady ? (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 px-6">
            <div className="flex gap-1 items-end h-8">
              {Array.from({ length: 12 }).map((_, i) => (
                <div
                  key={i}
                  className="w-1.5 bg-blue-500/40 rounded-sm"
                  style={{
                    height: `${20 + Math.sin(i * 0.8) * 14}px`,
                    opacity: i < (ticks.length / NEEDED) * 12 ? 1 : 0.2,
                    transition: "opacity 0.3s",
                  }}
                />
              ))}
            </div>
            <div className="text-xs text-slate-400 font-medium">
              Collecting ticks... {ticks.length}/{NEEDED}
            </div>
            <div className="w-40 h-1 bg-[#1e2a3a] rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-blue-600 to-blue-400 rounded-full transition-all duration-300"
                style={{ width: `${(ticks.length / NEEDED) * 100}%` }}
              />
            </div>
          </div>
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData} margin={{ top: 8, right: 0, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="chartFill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={fillColor} stopOpacity={0.22} />
                  <stop offset="100%" stopColor={fillColor} stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid
                strokeDasharray="3 3"
                stroke="#1a2436"
                vertical={false}
              />
              <XAxis dataKey="i" hide />
              <YAxis
                domain={[minY, maxY]}
                hide
              />
              <Tooltip content={<PriceTooltip />} cursor={{ stroke: "#334155", strokeWidth: 1, strokeDasharray: "4 4" }} />
              {/* BB middle line as reference */}
              {indicators && (
                <ReferenceLine
                  y={indicators.bb.middle}
                  stroke="#475569"
                  strokeDasharray="4 4"
                  strokeWidth={0.8}
                />
              )}
              {/* EMA line as reference */}
              {indicators && (
                <ReferenceLine
                  y={indicators.ema14}
                  stroke="#f59e0b"
                  strokeDasharray="3 3"
                  strokeWidth={0.8}
                />
              )}
              <Area
                type="monotoneX"
                dataKey="price"
                stroke={lineColor}
                strokeWidth={2}
                fill="url(#chartFill)"
                dot={false}
                activeDot={{ r: 3, fill: lineColor, stroke: "#0a0e1a", strokeWidth: 2 }}
                isAnimationActive={false}
              />
            </AreaChart>
          </ResponsiveContainer>
        )}
      </div>

      {/* Chart legend */}
      {isReady && indicators && (
        <div className="flex items-center gap-3 mt-2 px-0.5">
          <div className="flex items-center gap-1.5">
            <span className="w-4 h-0.5 rounded" style={{ background: lineColor, display: "inline-block" }} />
            <span className="text-[10px] text-slate-500">Price</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-4 rounded" style={{ borderTop: "1px dashed #475569", display: "inline-block" }} />
            <span className="text-[10px] text-slate-500">BB Mid</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-4 rounded" style={{ borderTop: "1px dashed #f59e0b", display: "inline-block" }} />
            <span className="text-[10px] text-slate-500">EMA 14</span>
          </div>
        </div>
      )}

      {/* Indicator pills */}
      {isReady && indicators && (
        <div className="mt-3 grid grid-cols-4 gap-2">
          {pills.map(pill => (
            <div
              key={pill.label}
              className={`border rounded-xl p-2 text-center ${pill.bg}`}
            >
              <div className="text-[9px] text-slate-500 font-medium uppercase tracking-wider mb-0.5">{pill.label}</div>
              <div className={`text-sm font-bold font-mono leading-none ${pill.color}`}>{pill.value}</div>
              <div className="text-[9px] text-slate-600 mt-0.5">{pill.sub}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
