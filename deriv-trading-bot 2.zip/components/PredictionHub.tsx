"use client"
import { useState } from "react"
import {
  TrendingUp, TrendingDown, Minus, Zap,
  CheckCircle2, XCircle, ChevronDown, ChevronUp,
} from "lucide-react"
import type { IndicatorVote } from "@/lib/indicators"

export interface PredictionData {
  confidence: number
  grade: "POOR" | "FAIR" | "GOOD" | "STRONG"
  signal: "BUY" | "SELL" | "WAIT"
  marketRegime: "Ranging" | "Trending" | "Volatile"
  regimeDesc: string
  recStake: number
  strategyInsight: string
  ticksCollected: number
  totalTicks: number
  winRate: number
  tradesCount: number
  votes?: IndicatorVote[]
  callScore?: number
  putScore?: number
  rsi?: number
  streak?: { direction: "up" | "down" | "flat"; count: number }
  shouldTrade?: boolean
  riskScore?: number
  winGateCount?: number
  winGateLocked?: boolean
  winGatePhase?: "hunting" | "building" | "cooldown"
  cooldownRemaining?: number
  familyScore?: {
    momentum: "CALL" | "PUT" | "NEUTRAL"
    trend: "CALL" | "PUT" | "NEUTRAL"
    volatility: "CALL" | "PUT" | "NEUTRAL"
    flow: "CALL" | "PUT" | "NEUTRAL"
    agreedFamilies: number
    totalFamilies: number
  }
  signalAge?: number
  signalStrength?: number
  supertrend?: { direction: "CALL" | "PUT"; line: number; strength: number }
  heikinAshi?: { direction: "CALL" | "PUT" | "NEUTRAL"; consecutive: number }
  roc?: number
  signalReadiness?: string
  priceActionOk?: boolean
  confluenceScore?: number
  tradeType?: string
}

interface Props {
  data: PredictionData
  isConnected: boolean
  onFireTrade?: (direction: "BUY" | "SELL") => void
  lossStreak?: number
  recentResults?: ("win" | "loss")[]
  totalCycles?: number
  sessionWins?: number
  sessionLosses?: number
  signalSkipped?: boolean
  onSkipSignal?: () => void
  onUnskipSignal?: () => void
  tenWinMode?: boolean
  tenWinCount?: number
  onToggleTenWin?: () => void
}

// ─── Derives human-readable labels from the trade type + signal direction ──────
function getTradeLabels(tradeType: string | undefined, signal: "BUY" | "SELL" | "WAIT") {
  const type = tradeType ?? "CALL_PUT"

  if (type === "DIGITEVEN_ODD") {
    // CALL = predict EVEN, PUT = predict ODD
    if (signal === "BUY")  return { action: "EVEN",  sub: "Last digit will be Even (0,2,4,6,8)", color: "#10b981", bg: "#052014", border: "#0d6632", Icon: TrendingUp }
    if (signal === "SELL") return { action: "ODD",   sub: "Last digit will be Odd (1,3,5,7,9)", color: "#ef4444", bg: "#150505", border: "#7f1d1d", Icon: TrendingDown }
    return { action: "WAIT", sub: "Analysing digit pattern...", color: "#475569", bg: "#0a0e1a", border: "#1e2a3a", Icon: Minus }
  }

  if (type === "DIGITMATCH_DIFF") {
    if (signal === "BUY")  return { action: "DIFFER", sub: "Last digit will differ from target", color: "#10b981", bg: "#052014", border: "#0d6632", Icon: TrendingUp }
    if (signal === "SELL") return { action: "MATCH",  sub: "Last digit will match target",       color: "#ef4444", bg: "#150505", border: "#7f1d1d", Icon: TrendingDown }
    return { action: "WAIT", sub: "Analysing match/differ pattern...", color: "#475569", bg: "#0a0e1a", border: "#1e2a3a", Icon: Minus }
  }

  if (type === "DIGITOVER_UNDER") {
    if (signal === "BUY")  return { action: "OVER 5",  sub: "Last digit will be 6,7,8,9", color: "#10b981", bg: "#052014", border: "#0d6632", Icon: TrendingUp }
    if (signal === "SELL") return { action: "UNDER 5", sub: "Last digit will be 0,1,2,3,4", color: "#f97316", bg: "#130a00", border: "#9a3412", Icon: TrendingDown }
    return { action: "WAIT", sub: "Analysing over/under pattern...", color: "#475569", bg: "#0a0e1a", border: "#1e2a3a", Icon: Minus }
  }

  // CALL_PUT, ONETOUCH_NOTOUCH — default Rise/Fall
  if (signal === "BUY")  return { action: "RISE",  sub: "Price is expected to go UP",   color: "#10b981", bg: "#052014", border: "#0d6632", Icon: TrendingUp }
  if (signal === "SELL") return { action: "FALL",  sub: "Price is expected to go DOWN", color: "#ef4444", bg: "#150505", border: "#7f1d1d", Icon: TrendingDown }
  return { action: "WAIT", sub: "Waiting for a clear entry point...", color: "#475569", bg: "#0a0e1a", border: "#1e2a3a", Icon: Minus }
}

// ─── Plain-English reason builder ────────────────────────────────────────────
function buildReason(data: PredictionData): string {
  const type = data.tradeType ?? "CALL_PUT"
  const signal = data.signal
  const streak = data.streak

  if (signal === "WAIT") return "No clear trade yet — keep watching."

  if (type === "DIGITEVEN_ODD") {
    const votes = data.votes ?? []
    const ratio = votes.find(v => v.name === "Ratio30")?.value ?? ""
    const streakV = votes.find(v => v.name === "Streak")?.value ?? ""
    return signal === "BUY"
      ? `More ODD digits recently (${ratio}). Pattern suggests EVEN is due. Streak: ${streakV}.`
      : `More EVEN digits recently (${ratio}). Pattern suggests ODD is due. Streak: ${streakV}.`
  }

  if (type === "DIGITMATCH_DIFF") {
    const votes = data.votes ?? []
    const ratio = votes.find(v => v.name === "Ratio30")?.value ?? ""
    return signal === "BUY"
      ? `Digits have been differing ${ratio} of the time. DIFFER trade likely.`
      : `Digits have been matching more often (${ratio}). MATCH trade likely.`
  }

  if (type === "DIGITOVER_UNDER") {
    const votes = data.votes ?? []
    const ratio = votes.find(v => v.name === "Ratio20")?.value ?? ""
    return signal === "BUY"
      ? `Low digits dominating (${ratio}). Digit likely to be OVER 5.`
      : `High digits dominating (${ratio}). Digit likely to be UNDER 5.`
  }

  // CALL_PUT / Rise-Fall
  const stStr = streak && streak.direction !== "flat"
    ? ` ${streak.count} ticks moving ${streak.direction === "up" ? "upward" : "downward"}.`
    : ""
  const confScore = data.confluenceScore ?? 0
  const families  = data.familyScore?.agreedFamilies ?? 0
  return signal === "BUY"
    ? `${confScore}/4 indicators agree to RISE.${stStr} ${families}/4 market families confirm upward momentum.`
    : `${confScore}/4 indicators agree to FALL.${stStr} ${families}/4 market families confirm downward pressure.`
}

// ─── Single condition check row ───────────────────────────────────────────────
function CondRow({ label, met, value }: { label: string; met: boolean; value?: string }) {
  return (
    <div className={`flex items-center justify-between px-3 py-2 rounded-lg border ${
      met ? "border-emerald-900/40 bg-emerald-950/20" : "border-[#1a2233] bg-[#080c14]"
    }`}>
      <div className="flex items-center gap-2">
        {met
          ? <CheckCircle2 size={12} className="text-emerald-400 flex-shrink-0" />
          : <XCircle      size={12} className="text-slate-600   flex-shrink-0" />}
        <span className={`text-[11px] font-medium ${met ? "text-slate-300" : "text-slate-600"}`}>{label}</span>
      </div>
      {value && (
        <span className={`text-[10px] font-bold tabular-nums ${met ? "text-emerald-400" : "text-slate-600"}`}>{value}</span>
      )}
    </div>
  )
}

// ─── Main component ───────────────────────────────────────────────────────────
export default function PredictionHub({
  data, isConnected, onFireTrade,
  recentResults = [], sessionWins = 0, sessionLosses = 0,
  tenWinMode = false, tenWinCount = 0, onToggleTenWin,
}: Props) {
  const [votesOpen, setVotesOpen] = useState(false)

  const isReady    = data.ticksCollected >= data.totalTicks
  // Manual "Take Trade" fires as soon as there is any signal — no shouldTrade gate
  // The user has chosen to trade; we respect that decision immediately.
  const canFire    = isReady && isConnected && data.signal !== "WAIT"
  // Auto-trade (10-Win Bot) still requires shouldTrade quality gate
  const inCooldown = data.winGatePhase === "cooldown"

  const conf       = data.confidence
  const families   = data.familyScore?.agreedFamilies ?? 0
  const paOk       = data.priceActionOk ?? false
  const confScore  = data.confluenceScore ?? 0
  const last8      = recentResults.slice(-8)

  const lbl    = getTradeLabels(data.tradeType, data.signal)
  const reason = buildReason(data)

  // Derive conditions that are relevant for each trade type
  const isDigit   = ["DIGITEVEN_ODD", "DIGITMATCH_DIFF", "DIGITOVER_UNDER"].includes(data.tradeType ?? "")
  const conditions = isDigit ? [
    { label: "Pattern confidence ≥ 62%",   met: conf >= 62,     value: `${conf}%` },
    { label: "Digit ratio is imbalanced",  met: confScore >= 1, value: confScore >= 1 ? "Yes" : "No" },
    { label: "Streak in one direction",    met: paOk,           value: paOk ? "Yes" : "No" },
  ] : [
    { label: "Confidence ≥ 63%",              met: conf >= 63,     value: `${conf}%` },
    { label: "3+ indicator families agree",   met: families >= 3,  value: `${families}/4` },
    { label: "2+ closes confirm direction",   met: paOk,          value: paOk ? "Yes" : "No" },
    { label: "3+ core indicators aligned",    met: confScore >= 3, value: `${confScore}/4` },
  ]

  const allMet = conditions.every(c => c.met)

  return (
    <div className="rounded-2xl bg-[#0a0e1a] border border-[#1e2a3a] overflow-hidden">

      {/* ── Header ── */}
      <div className="px-4 pt-4 pb-3 flex items-center justify-between border-b border-[#1e2a3a]">
        <div className="flex items-center gap-2">
          <Zap size={14} className="text-blue-400" />
          <span className="text-xs font-bold text-slate-300 uppercase tracking-wide">Signal</span>
        </div>
        <div className="flex items-center gap-1.5">
          {last8.map((r, i) => (
            <div key={i} className={`w-2 h-2 rounded-full ${r === "win" ? "bg-emerald-500" : "bg-red-500"}`} />
          ))}
          {last8.length > 0 && (
            <span className="text-[10px] text-slate-600 ml-1 tabular-nums">{sessionWins}W {sessionLosses}L</span>
          )}
        </div>
      </div>

      <div className="p-4 flex flex-col gap-3">

        {/* ── Warmup ── */}
        {!isReady && isConnected && (
          <div>
            <div className="flex justify-between mb-1.5">
              <span className="text-[11px] text-slate-500">Loading data...</span>
              <span className="text-[11px] text-slate-500 tabular-nums">{data.ticksCollected}/{data.totalTicks}</span>
            </div>
            <div className="h-1.5 bg-[#1e2a3a] rounded-full overflow-hidden">
              <div
                className="h-full bg-blue-500 rounded-full transition-all duration-300"
                style={{ width: `${Math.round((data.ticksCollected / data.totalTicks) * 100)}%` }}
              />
            </div>
          </div>
        )}

        {/* ── Not connected ── */}
        {!isConnected && (
          <div className="py-8 text-center">
            <Minus size={24} className="text-slate-700 mx-auto mb-2" />
            <p className="text-sm text-slate-500">Connect to Deriv to see signals</p>
          </div>
        )}

        {isConnected && isReady && (
          <>
            {/* ── Big signal card ── */}
            <div
              className="rounded-xl p-4 border transition-all duration-500"
              style={{ background: lbl.bg, borderColor: lbl.border }}
            >
              {/* Direction label */}
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full flex items-center justify-center border"
                    style={{ background: lbl.color + "20", borderColor: lbl.color + "50" }}>
                    <lbl.Icon size={20} style={{ color: lbl.color }} />
                  </div>
                  <div>
                    <div className="text-2xl font-black tracking-tight leading-none" style={{ color: lbl.color }}>
                      {lbl.action}
                    </div>
                    <div className="text-[10px] mt-0.5" style={{ color: lbl.color + "99" }}>{lbl.sub}</div>
                  </div>
                </div>
                {/* Confidence badge */}
                <div className="text-right">
                  <div className="text-2xl font-black tabular-nums" style={{ color: lbl.color }}>{conf}%</div>
                  <div className="text-[9px] text-slate-600 uppercase tracking-wide">confidence</div>
                </div>
              </div>

              {/* Confidence bar */}
              <div className="h-2 bg-black/40 rounded-full overflow-hidden mb-3">
                <div
                  className="h-full rounded-full transition-all duration-700"
                  style={{ width: `${conf}%`, background: lbl.color }}
                />
              </div>

              {/* Plain English reason */}
              <p className="text-[11px] leading-relaxed" style={{ color: canFire ? "#86efac" : "#64748b" }}>
                {reason}
              </p>
            </div>

            {/* ── Conditions ── */}
            <div className="flex flex-col gap-1.5">
              <div className="flex items-center justify-between px-1 mb-0.5">
                <span className="text-[9px] font-bold text-slate-600 uppercase tracking-widest">
                  Bot quality gates
                </span>
                {allMet
                  ? <span className="text-[9px] font-bold text-emerald-500 uppercase tracking-wide">All clear</span>
                  : <span className="text-[9px] text-slate-600">Manual trade always works</span>
                }
              </div>
              {conditions.map(c => (
                <CondRow key={c.label} label={c.label} met={c.met} value={c.value} />
              ))}
            </div>

            {/* ── 10-Win Bot toggle ── */}
            <button
              onClick={() => isConnected && onToggleTenWin?.()}
              disabled={!isConnected}
              className={`w-full flex items-center justify-between px-4 py-3 rounded-xl border transition-all duration-200 ${
                tenWinMode
                  ? "bg-amber-950/50 border-amber-600/70"
                  : "bg-[#080c14] border-[#1e2a3a] hover:border-amber-800/40"
              } ${!isConnected ? "opacity-40 cursor-not-allowed" : "cursor-pointer"}`}
            >
              <div className="flex items-center gap-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                  tenWinMode ? "bg-amber-500/20 border border-amber-500/40" : "bg-[#0d1117] border border-[#1e2a3a]"
                }`}>
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"
                    style={{ color: tenWinMode ? "#fbbf24" : "#475569" }}>
                    <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
                  </svg>
                </div>
                <div className="text-left">
                  <div className="flex items-center gap-2">
                    <span className={`text-xs font-bold ${tenWinMode ? "text-amber-300" : "text-slate-300"}`}>
                      10-Win Bot
                    </span>
                    {tenWinMode && (
                      <span className="text-[8px] font-bold px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-400 border border-amber-500/30 uppercase tracking-wide animate-pulse">
                        Active
                      </span>
                    )}
                  </div>
                  <div className="text-[10px] mt-0.5">
                    {tenWinMode
                      ? <span className="text-amber-600">{tenWinCount}/10 wins — stops on first loss</span>
                      : <span className="text-slate-600">Auto-trades until 10 wins. Stops on any loss.</span>}
                  </div>
                </div>
              </div>
              <div className={`relative w-10 h-5 rounded-full transition-colors flex-shrink-0 ${
                tenWinMode ? "bg-amber-500" : "bg-[#1e2a3a]"
              }`}>
                <div className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-all duration-200 ${
                  tenWinMode ? "left-[22px]" : "left-0.5"
                }`} />
              </div>
            </button>

            {/* 10-win progress dots */}
            {tenWinMode && (
              <div className="flex gap-1 px-0.5">
                {Array.from({ length: 10 }).map((_, i) => (
                  <div
                    key={i}
                    className={`flex-1 h-2.5 rounded-sm transition-all duration-300 ${
                      i < tenWinCount ? "bg-amber-400" : "bg-[#1e2a3a]"
                    }`}
                  />
                ))}
              </div>
            )}

            {/* ── Instant Trade buttons — always available when connected ── */}
            {!tenWinMode && (
              <div className="flex flex-col gap-2">

                {/* Signal-aligned "Trade Now" button — prominent when signal is active */}
                {canFire && !inCooldown ? (
                  <button
                    onClick={() => onFireTrade?.(data.signal as "BUY" | "SELL")}
                    style={{ touchAction: "manipulation" }}
                    className={`w-full py-4 rounded-xl font-black uppercase tracking-wider transition-all duration-100 border flex items-center justify-center gap-2 active:scale-[0.97] text-base ${
                      data.signal === "BUY"
                        ? "bg-emerald-600 hover:bg-emerald-500 border-emerald-500 text-white shadow-lg shadow-emerald-900/60"
                        : "bg-red-600 hover:bg-red-500 border-red-500 text-white shadow-lg shadow-red-900/60"
                    }`}
                  >
                    <lbl.Icon size={16} />
                    Trade Now — {lbl.action}
                  </button>
                ) : inCooldown ? (
                  <div className="w-full py-3 rounded-xl border border-blue-900/50 bg-blue-950/20 text-center text-xs text-blue-500 font-semibold">
                    Resting {data.cooldownRemaining ?? 0}s...
                  </div>
                ) : null}

                {/* ── Instant BUY / SELL — always available, no signal gate ── */}
                <div className="grid grid-cols-2 gap-2">
                  <button
                    disabled={!isConnected || !isReady}
                    onClick={() => isConnected && isReady && onFireTrade?.("BUY")}
                    style={{ touchAction: "manipulation" }}
                    className={`py-3.5 rounded-xl font-black text-sm uppercase tracking-wide border flex items-center justify-center gap-1.5 active:scale-[0.97] transition-all duration-100 ${
                      isConnected && isReady
                        ? "bg-emerald-950/60 hover:bg-emerald-900/60 border-emerald-700/60 text-emerald-300 shadow-md shadow-emerald-950/60"
                        : "bg-[#0d1117] border-[#1e2a3a] text-slate-700 cursor-not-allowed"
                    }`}
                  >
                    <TrendingUp size={15} />
                    {isDigit ? (data.tradeType === "DIGITEVEN_ODD" ? "EVEN" : data.tradeType === "DIGITOVER_UNDER" ? "OVER" : "DIFFER") : "RISE"}
                  </button>
                  <button
                    disabled={!isConnected || !isReady}
                    onClick={() => isConnected && isReady && onFireTrade?.("SELL")}
                    style={{ touchAction: "manipulation" }}
                    className={`py-3.5 rounded-xl font-black text-sm uppercase tracking-wide border flex items-center justify-center gap-1.5 active:scale-[0.97] transition-all duration-100 ${
                      isConnected && isReady
                        ? "bg-red-950/60 hover:bg-red-900/60 border-red-700/60 text-red-300 shadow-md shadow-red-950/60"
                        : "bg-[#0d1117] border-[#1e2a3a] text-slate-700 cursor-not-allowed"
                    }`}
                  >
                    <TrendingDown size={15} />
                    {isDigit ? (data.tradeType === "DIGITEVEN_ODD" ? "ODD" : data.tradeType === "DIGITOVER_UNDER" ? "UNDER" : "MATCH") : "FALL"}
                  </button>
                </div>

                {/* Quality hint */}
                <div className={`text-center text-[9px] font-semibold uppercase tracking-widest ${
                  allMet ? "text-emerald-600" : canFire ? "text-amber-700" : "text-slate-700"
                }`}>
                  {allMet
                    ? "All quality gates passed"
                    : canFire
                    ? "Signal active — manual gates not all met"
                    : isReady
                    ? "Analysing — instant buttons always ready"
                    : ""}
                </div>
              </div>
            )}

            {/* ── Votes breakdown (collapsible) ── */}
            {(data.votes?.length ?? 0) > 0 && (
              <div className="rounded-xl border border-[#1e2a3a] overflow-hidden">
                <button
                  onClick={() => setVotesOpen(o => !o)}
                  className="w-full flex items-center justify-between px-3 py-2.5 hover:bg-white/[0.02] transition-colors"
                >
                  <span className="text-[10px] font-semibold text-slate-500 uppercase tracking-wide">
                    Indicator votes ({data.votes?.filter(v => v.signal !== "NEUTRAL").length ?? 0} active)
                  </span>
                  {votesOpen
                    ? <ChevronUp   size={12} className="text-slate-600" />
                    : <ChevronDown size={12} className="text-slate-600" />}
                </button>
                {votesOpen && (
                  <div className="px-3 pb-3 flex flex-col gap-1 border-t border-[#1e2a3a]">
                    {data.votes?.filter(v => v.signal !== "NEUTRAL").map((v, i) => (
                      <div key={i} className="flex items-center justify-between py-1">
                        <span className="text-[10px] text-slate-500 font-medium w-12 flex-shrink-0">{v.name}</span>
                        <div className="flex-1 mx-2 h-1 bg-[#1e2a3a] rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full ${v.signal === "CALL" ? "bg-emerald-500" : "bg-red-500"}`}
                            style={{ width: `${Math.min((v.weight / 20) * 100, 100)}%` }}
                          />
                        </div>
                        <span className={`text-[10px] font-bold w-16 text-right ${v.signal === "CALL" ? "text-emerald-400" : "text-red-400"}`}>
                          {v.signal === "CALL"
                            ? (isDigit ? (data.tradeType === "DIGITEVEN_ODD" ? "EVEN" : data.tradeType === "DIGITOVER_UNDER" ? "OVER" : "DIFFER") : "RISE")
                            : (isDigit ? (data.tradeType === "DIGITEVEN_ODD" ? "ODD"  : data.tradeType === "DIGITOVER_UNDER" ? "UNDER" : "MATCH")  : "FALL")}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  )
}
