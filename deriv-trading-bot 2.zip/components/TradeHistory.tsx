"use client"
import { History, TrendingUp, TrendingDown, Activity, Clock } from "lucide-react"

export interface Trade {
  id: string
  time: number
  symbol: string
  contractType: string
  direction: "CALL" | "PUT"
  stake: number
  payout: number | null
  profit: number | null
  result: "win" | "loss" | "pending"
}

interface Props {
  trades: Trade[]
  netProfit: number
  currency: string
}

export default function TradeHistory({ trades, netProfit, currency }: Props) {
  const wins = trades.filter(t => t.result === "win").length
  const losses = trades.filter(t => t.result === "loss").length
  const total = wins + losses
  const winRate = total > 0 ? (wins / total) * 100 : 0

  const formatTime = (ts: number) => {
    const d = new Date(ts)
    return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })
  }

  const getContractLabel = (type: string) => {
    const map: Record<string, string> = {
      CALL: "Rise", PUT: "Fall", DIGITEVEN: "Even", DIGITODD: "Odd",
      DIGITMATCH: "Match", DIGITDIFF: "Differ", DIGITOVER: "Over", DIGITUNDER: "Under",
      ONETOUCH: "Touch", NOTOUCH: "No Touch", ACCU: "Accu"
    }
    return map[type] || type
  }

  return (
    <div className="trade-card">
      {/* Header */}
      <div className="flex items-center gap-2 mb-4">
        <History size={16} className="text-blue-400" />
        <span className="text-sm font-semibold text-slate-200">Trade History</span>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-2 gap-3 mb-4">
        <div className="bg-[#0a0e1a] border border-[#1e2a3a] rounded-xl p-3">
          <div className="text-xs text-slate-500 mb-1">Net Profit / Loss</div>
          <div className={`text-lg font-bold ${netProfit >= 0 ? "text-emerald-400" : "text-red-400"}`}>
            {netProfit >= 0 ? "+" : ""}{netProfit.toFixed(2)} <span className="text-sm font-normal text-slate-400">{currency}</span>
          </div>
        </div>
        <div className="bg-[#0a0e1a] border border-[#1e2a3a] rounded-xl p-3">
          <div className="text-xs text-slate-500 mb-1">Win Rate</div>
          <div className={`text-lg font-bold ${winRate >= 50 ? "text-emerald-400" : "text-red-400"}`}>
            {winRate.toFixed(0)}%
            <span className="text-xs font-normal text-slate-500 ml-1">({wins}/{total})</span>
          </div>
        </div>
      </div>

      {/* Totals row */}
      <div className="grid grid-cols-3 gap-2 mb-4">
        {[
          { label: "Total", value: total, icon: <Activity size={16} className="text-blue-400" />, color: "text-slate-300" },
          { label: "Wins", value: wins, icon: <TrendingUp size={16} className="text-emerald-400" />, color: "text-emerald-400" },
          { label: "Losses", value: losses, icon: <TrendingDown size={16} className="text-red-400" />, color: "text-red-400" },
        ].map(item => (
          <div key={item.label} className="bg-[#0a0e1a] border border-[#1e2a3a] rounded-xl p-3 flex flex-col items-center gap-1">
            {item.icon}
            <div className={`text-xl font-bold ${item.color}`}>{item.value}</div>
            <div className="text-[10px] text-slate-500">{item.label}</div>
          </div>
        ))}
      </div>

      {/* Trade list */}
      {trades.length === 0 ? (
        <div className="flex flex-col items-center py-8 gap-2">
          <History size={28} className="text-slate-700" />
          <div className="text-sm text-slate-500 font-medium">No trades executed yet</div>
          <div className="text-xs text-slate-600">Connect to Deriv and place your first trade</div>
        </div>
      ) : (
        <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
          {[...trades].reverse().map(trade => (
            <div
              key={trade.id}
              className={`flex items-center justify-between px-3 py-2.5 rounded-xl border ${
                trade.result === "win" ? "bg-emerald-900/10 border-emerald-800/30" :
                trade.result === "loss" ? "bg-red-900/10 border-red-800/30" :
                "bg-[#0a0e1a] border-[#1e2a3a]"
              }`}
            >
              <div className="flex items-center gap-2">
                <div className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 ${
                  trade.result === "win" ? "bg-emerald-900/40" :
                  trade.result === "loss" ? "bg-red-900/40" :
                  "bg-slate-800"
                }`}>
                  {trade.result === "win" ? <TrendingUp size={12} className="text-emerald-400" /> :
                   trade.result === "loss" ? <TrendingDown size={12} className="text-red-400" /> :
                   <Clock size={12} className="text-slate-400" />}
                </div>
                <div>
                  <div className="text-xs font-semibold text-slate-300">
                    {getContractLabel(trade.contractType)} · {trade.symbol}
                  </div>
                  <div className="text-[10px] text-slate-600 flex items-center gap-1">
                    <Clock size={9} />
                    {formatTime(trade.time)}
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className={`text-xs font-bold ${
                  trade.result === "win" ? "text-emerald-400" :
                  trade.result === "loss" ? "text-red-400" :
                  "text-slate-400"
                }`}>
                  {trade.result === "pending" ? "..." :
                   trade.profit !== null ? `${trade.profit >= 0 ? "+" : ""}${trade.profit.toFixed(2)}` : "—"}
                </div>
                <div className="text-[10px] text-slate-600">${trade.stake.toFixed(2)}</div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
