"use client"
import { BarChart2, TrendingUp, TrendingDown, Flame, Award, AlertTriangle, Target, Trophy } from "lucide-react"
import { AreaChart, Area, ResponsiveContainer, Tooltip } from "recharts"
import type { Trade } from "@/components/TradeHistory"

interface Props {
  trades: Trade[]
  currency: string
  strategySignals?: Record<string, { signal: "BUY" | "SELL" | "WAIT"; confidence: number }>
  regime?: "Ranging" | "Trending" | "Volatile"
}

function StatCard({ label, value, sub, color = "text-slate-200" }: {
  label: string; value: string; sub?: string; color?: string
}) {
  return (
    <div className="bg-[#0a0e1a] border border-[#1e2a3a] rounded-xl p-3">
      <div className="text-[10px] text-slate-500 uppercase tracking-wide mb-1">{label}</div>
      <div className={`text-base font-bold font-mono ${color}`}>{value}</div>
      {sub && <div className="text-[10px] text-slate-600 mt-0.5">{sub}</div>}
    </div>
  )
}

const STRATEGY_LABELS: Record<string, string> = {
  CALL: "Unibet", PUT: "Unibet", DIGITEVEN: "DigitAI", DIGITODD: "DigitAI",
  DIGITMATCH: "TradeX", DIGITDIFF: "TradeX", DIGITOVER: "OptimaX", DIGITUNDER: "OptimaX",
  ACCU: "Accumulator", ONETOUCH: "Auto RS", NOTOUCH: "Auto RS",
}

export default function LiveAnalysis({ trades, currency, strategySignals, regime }: Props) {
  const done = trades.filter(t => t.result !== "pending")
  const wins = done.filter(t => t.result === "win")
  const losses = done.filter(t => t.result === "loss")
  const wr = done.length > 0 ? (wins.length / done.length) * 100 : 0

  // Equity curve
  const equityCurve: { i: number; equity: number }[] = []
  let running = 0
  done.forEach((t, i) => {
    running += t.profit ?? 0
    equityCurve.push({ i, equity: parseFloat(running.toFixed(2)) })
  })

  // Avg profit / loss
  const avgWin = wins.length > 0
    ? wins.reduce((s, t) => s + (t.profit ?? 0), 0) / wins.length : 0
  const avgLoss = losses.length > 0
    ? Math.abs(losses.reduce((s, t) => s + (t.profit ?? 0), 0) / losses.length) : 0
  const profitFactor = avgLoss > 0 ? avgWin / avgLoss : avgWin > 0 ? 99 : 0

  // Streaks
  let curStreak = 0, maxWinStreak = 0, maxLossStreak = 0
  let streakType: "win" | "loss" | null = null
  for (const t of done) {
    if (t.result === streakType) {
      curStreak++
    } else {
      curStreak = 1
      streakType = t.result as "win" | "loss"
    }
    if (streakType === "win" && curStreak > maxWinStreak) maxWinStreak = curStreak
    if (streakType === "loss" && curStreak > maxLossStreak) maxLossStreak = curStreak
  }
  // Current streak
  let currentStreakCount = 0
  let currentStreakDir: "win" | "loss" | null = null
  for (let i = done.length - 1; i >= 0; i--) {
    const r = done[i].result as "win" | "loss"
    if (currentStreakDir === null) { currentStreakDir = r; currentStreakCount = 1 }
    else if (r === currentStreakDir) currentStreakCount++
    else break
  }

  // Best / worst trade
  const bestTrade = done.reduce<Trade | null>((b, t) =>
    (t.profit ?? -Infinity) > (b?.profit ?? -Infinity) ? t : b, null)
  const worstTrade = done.reduce<Trade | null>((b, t) =>
    (t.profit ?? Infinity) < (b?.profit ?? Infinity) ? t : b, null)

  // Expected value per trade
  const ev = (wr / 100) * avgWin - ((1 - wr / 100) * avgLoss)

  // Per-strategy stats
  const stratStats: Record<string, { wins: number; losses: number; profit: number }> = {}
  for (const t of done) {
    const label = STRATEGY_LABELS[t.contractType] ?? t.contractType
    if (!stratStats[label]) stratStats[label] = { wins: 0, losses: 0, profit: 0 }
    if (t.result === "win") stratStats[label].wins++
    else stratStats[label].losses++
    stratStats[label].profit += t.profit ?? 0
  }
  const stratList = Object.entries(stratStats)
    .map(([name, s]) => ({
      name,
      total: s.wins + s.losses,
      wr: s.wins + s.losses > 0 ? (s.wins / (s.wins + s.losses)) * 100 : 0,
      profit: s.profit,
    }))
    .sort((a, b) => b.wr - a.wr)

  // Best strategy by signal + regime alignment
  const bestSignalStrategy = strategySignals
    ? Object.entries(strategySignals)
        .filter(([, s]) => s.signal !== "WAIT")
        .sort((a, b) => b[1].confidence - a[1].confidence)[0]?.[0]
    : null

  // Suggested action
  function getSuggestion(): { text: string; color: string; icon: React.ReactNode } {
    if (done.length < 5) return { text: "Need at least 5 trades for analysis.", color: "text-slate-500", icon: <BarChart2 size={13} className="text-slate-500" /> }
    if (wr >= 65 && ev > 0) return { text: "Strong performance. Keep current strategy. Consider slight stake increase.", color: "text-emerald-400", icon: <Award size={13} className="text-emerald-400" /> }
    if (wr >= 50 && ev > 0) return { text: "Positive edge. Stay consistent. Avoid increasing stake aggressively.", color: "text-blue-400", icon: <TrendingUp size={13} className="text-blue-400" /> }
    if (currentStreakDir === "loss" && currentStreakCount >= 3) return { text: `${currentStreakCount} consecutive losses. Pause and wait for a fresh signal.`, color: "text-orange-400", icon: <AlertTriangle size={13} className="text-orange-400" /> }
    if (wr < 40) return { text: "Win rate below 40%. Consider switching strategy or trade type.", color: "text-red-400", icon: <TrendingDown size={13} className="text-red-400" /> }
    return { text: "Mixed results. Wait for Prediction Hub grade GOOD or better before trading.", color: "text-yellow-400", icon: <Flame size={13} className="text-yellow-400" /> }
  }

  const suggestion = getSuggestion()

  if (done.length === 0) {
    return (
      <div className="trade-card">
        <div className="flex items-center gap-2 mb-4">
          <BarChart2 size={15} className="text-blue-400" />
          <span className="text-sm font-semibold text-slate-200">Live Analysis</span>
        </div>
        <div className="flex flex-col items-center py-8 gap-2">
          <BarChart2 size={28} className="text-slate-700" />
          <p className="text-sm text-slate-500 font-medium">No trades to analyze yet</p>
          <p className="text-xs text-slate-600">Place your first trade to see live analysis</p>
        </div>
      </div>
    )
  }

  return (
    <div className="trade-card space-y-3">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <BarChart2 size={15} className="text-blue-400" />
          <span className="text-sm font-semibold text-slate-200">Live Analysis</span>
        </div>
        <span className="text-[10px] text-slate-500">{done.length} trades analyzed</span>
      </div>

      {/* Equity curve */}
      {equityCurve.length >= 2 && (
        <div className="bg-[#0a0e1a] border border-[#1e2a3a] rounded-xl overflow-hidden" style={{ height: 72 }}>
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={equityCurve} margin={{ top: 4, right: 0, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="eqFill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={running >= 0 ? "#10b981" : "#ef4444"} stopOpacity={0.25} />
                  <stop offset="100%" stopColor={running >= 0 ? "#10b981" : "#ef4444"} stopOpacity={0} />
                </linearGradient>
              </defs>
              <Tooltip
                content={({ active, payload }) =>
                  active && payload?.length ? (
                    <div className="bg-[#0d1526] border border-[#1e2a3a] rounded px-2 py-1 text-[10px]">
                      <span className={payload[0].value >= 0 ? "text-emerald-400" : "text-red-400"}>
                        {(payload[0].value as number) >= 0 ? "+" : ""}{(payload[0].value as number).toFixed(2)} {currency}
                      </span>
                    </div>
                  ) : null
                }
                cursor={{ stroke: "#334155", strokeWidth: 1 }}
              />
              <Area
                type="monotone"
                dataKey="equity"
                stroke={running >= 0 ? "#10b981" : "#ef4444"}
                strokeWidth={1.5}
                fill="url(#eqFill)"
                dot={false}
                isAnimationActive={false}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Stats grid */}
      <div className="grid grid-cols-2 gap-2">
        <StatCard label="Win Rate" value={`${wr.toFixed(1)}%`}
          sub={`${wins.length}W / ${losses.length}L`}
          color={wr >= 50 ? "text-emerald-400" : "text-red-400"} />
        <StatCard label="Profit Factor" value={profitFactor >= 99 ? "∞" : profitFactor.toFixed(2)}
          sub="Avg win / avg loss"
          color={profitFactor >= 1 ? "text-emerald-400" : "text-red-400"} />
        <StatCard label="Avg Win" value={`+${avgWin.toFixed(2)}`}
          sub={currency} color="text-emerald-400" />
        <StatCard label="Avg Loss" value={`-${avgLoss.toFixed(2)}`}
          sub={currency} color="text-red-400" />
        <StatCard label="Expected Value" value={`${ev >= 0 ? "+" : ""}${ev.toFixed(3)}`}
          sub="Per trade edge"
          color={ev > 0 ? "text-emerald-400" : "text-red-400"} />
        <StatCard label="Current Streak"
          value={currentStreakDir ? `${currentStreakCount} ${currentStreakDir === "win" ? "W" : "L"}` : "—"}
          sub={currentStreakDir === "win" ? "Win streak" : "Loss streak"}
          color={currentStreakDir === "win" ? "text-emerald-400" : currentStreakDir === "loss" ? "text-red-400" : "text-slate-400"} />
      </div>

      {/* Best / Worst */}
      <div className="grid grid-cols-2 gap-2">
        <div className="bg-emerald-900/10 border border-emerald-800/25 rounded-xl p-2.5">
          <div className="flex items-center gap-1 mb-1">
            <TrendingUp size={10} className="text-emerald-400" />
            <span className="text-[9px] text-emerald-400 font-semibold uppercase">Best Trade</span>
          </div>
          <div className="text-sm font-bold font-mono text-emerald-400">
            {bestTrade?.profit !== null && bestTrade?.profit !== undefined
              ? `+${bestTrade.profit.toFixed(2)}`
              : "—"}
          </div>
          <div className="text-[9px] text-slate-600 mt-0.5">{bestTrade?.contractType ?? ""}</div>
        </div>
        <div className="bg-red-900/10 border border-red-800/25 rounded-xl p-2.5">
          <div className="flex items-center gap-1 mb-1">
            <TrendingDown size={10} className="text-red-400" />
            <span className="text-[9px] text-red-400 font-semibold uppercase">Worst Trade</span>
          </div>
          <div className="text-sm font-bold font-mono text-red-400">
            {worstTrade?.profit !== null && worstTrade?.profit !== undefined
              ? `${worstTrade.profit.toFixed(2)}`
              : "—"}
          </div>
          <div className="text-[9px] text-slate-600 mt-0.5">{worstTrade?.contractType ?? ""}</div>
        </div>
      </div>

      {/* Streak bars */}
      <div className="flex items-center gap-3 px-3 py-2 bg-[#0a0e1a] border border-[#1e2a3a] rounded-xl">
        <Flame size={12} className="text-orange-400 flex-shrink-0" />
        <div className="flex-1 text-[10px] text-slate-400">
          Best win streak: <span className="text-emerald-400 font-bold">{maxWinStreak}</span>
          <span className="text-slate-600 mx-2">·</span>
          Worst loss streak: <span className="text-red-400 font-bold">{maxLossStreak}</span>
        </div>
      </div>

      {/* Best strategy recommendation */}
      {bestSignalStrategy && (
        <div className="flex items-center gap-2.5 px-3 py-2.5 bg-blue-950/30 border border-blue-800/30 rounded-xl">
          <Target size={13} className="text-blue-400 flex-shrink-0" />
          <div>
            <div className="text-[10px] text-slate-500 font-semibold uppercase tracking-wide">Best Signal Now</div>
            <div className="text-xs font-bold text-blue-300">
              {bestSignalStrategy.charAt(0).toUpperCase() + bestSignalStrategy.slice(1)}
              {regime && <span className="text-slate-500 font-normal ml-1">· {regime} market</span>}
            </div>
          </div>
          {strategySignals?.[bestSignalStrategy] && (
            <div className={`ml-auto text-xs font-bold px-2 py-1 rounded border ${
              strategySignals[bestSignalStrategy].signal === "BUY"
                ? "text-emerald-400 bg-emerald-900/20 border-emerald-800/30"
                : "text-red-400 bg-red-900/20 border-red-800/30"
            }`}>
              {strategySignals[bestSignalStrategy].signal} {strategySignals[bestSignalStrategy].confidence}%
            </div>
          )}
        </div>
      )}

      {/* Per-strategy breakdown */}
      {stratList.length > 0 && (
        <div>
          <div className="flex items-center gap-1.5 mb-2">
            <Trophy size={12} className="text-yellow-400" />
            <span className="text-[10px] text-slate-500 font-semibold uppercase tracking-wide">Strategy Performance</span>
          </div>
          <div className="space-y-1.5">
            {stratList.map(s => (
              <div key={s.name} className="flex items-center gap-3 px-3 py-2 bg-[#0a0e1a] border border-[#1e2a3a] rounded-xl">
                <div className="text-xs font-semibold text-slate-300 w-24 flex-shrink-0">{s.name}</div>
                <div className="flex-1 h-1.5 bg-[#1e2a3a] rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all"
                    style={{
                      width: `${s.wr}%`,
                      background: s.wr >= 55 ? "#10b981" : s.wr >= 45 ? "#f59e0b" : "#ef4444",
                    }}
                  />
                </div>
                <div className={`text-[10px] font-bold w-8 text-right ${s.wr >= 55 ? "text-emerald-400" : s.wr >= 45 ? "text-yellow-400" : "text-red-400"}`}>
                  {s.wr.toFixed(0)}%
                </div>
                <div className={`text-[10px] font-mono w-12 text-right ${s.profit >= 0 ? "text-emerald-400" : "text-red-400"}`}>
                  {s.profit >= 0 ? "+" : ""}{s.profit.toFixed(2)}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* AI Suggestion */}
      <div className="flex items-start gap-2.5 p-3 bg-[#0d1526] border border-[#1e3a5f] rounded-xl">
        <div className="flex-shrink-0 mt-0.5">{suggestion.icon}</div>
        <div>
          <div className="text-[10px] text-slate-500 font-semibold uppercase tracking-wide mb-0.5">AI Suggestion</div>
          <p className={`text-[11px] leading-relaxed font-medium ${suggestion.color}`}>{suggestion.text}</p>
        </div>
      </div>
    </div>
  )
}
