"use client"
import { Rocket, Info, Zap, Shield, Gauge, Flame, Brain, Target } from "lucide-react"

export type PilotMode = "smart" | "conservative" | "balanced" | "aggressive" | "turbo" | "precision"

export const PILOT_MODES: {
  id: PilotMode; name: string; tag: string; desc: string
  agree: string; conf: string; cooldown: string; icon: React.ReactNode
  highlight?: string
}[] = [
  {
    id: "smart", name: "Smart", tag: "SMART",
    desc: "Adapts mode automatically based on live win rate and signal strength.",
    agree: "auto", conf: "auto", cooldown: "auto",
    icon: <Brain size={14} className="text-blue-400" />,
  },
  {
    id: "precision", name: "Precision", tag: "BEST",
    desc: "5/5 families agree · 85%+ conf · 12s cooldown. Highest win rate, fewest trades.",
    agree: "5/5", conf: "85%+", cooldown: "12s",
    icon: <Target size={14} className="text-emerald-400" />,
    highlight: "emerald",
  },
  {
    id: "conservative", name: "Conservative", tag: "",
    desc: "4/5 agree · 75%+ conf · 8s cooldown. Fewer trades, higher quality.",
    agree: "4/5", conf: "75%+", cooldown: "8s",
    icon: <Shield size={14} className="text-sky-400" />,
  },
  {
    id: "balanced", name: "Balanced", tag: "",
    desc: "3/5 agree · 62%+ conf · 5s cooldown. Good mix of frequency and quality.",
    agree: "3/5", conf: "62%+", cooldown: "5s",
    icon: <Gauge size={14} className="text-yellow-400" />,
  },
  {
    id: "aggressive", name: "Aggressive", tag: "",
    desc: "3/5 agree · 56%+ conf · 3s cooldown. More trades, more risk.",
    agree: "3/5", conf: "56%+", cooldown: "3s",
    icon: <Flame size={14} className="text-orange-400" />,
  },
  {
    id: "turbo", name: "Turbo", tag: "",
    desc: "4/5 agree · 67%+ conf · 2s cooldown. Maximum speed, tight gate.",
    agree: "4/5", conf: "67%+", cooldown: "2s",
    icon: <Zap size={14} className="text-purple-400" />,
  },
]

interface Props {
  mode: PilotMode
  onModeChange: (m: PilotMode) => void
  agree: number
  maxAgree: number
  strength: number
  winProb: number
  cooldown: number
  status: string
  isConnected: boolean
  sessionWins?: number
  sessionLosses?: number
  tenWinMode?: boolean
  tenWinCount?: number
  onToggleTenWin?: () => void
}

export default function AutoPilot({
  mode, onModeChange, agree, maxAgree, strength, winProb, cooldown, status, isConnected,
  sessionWins = 0, sessionLosses = 0,
  tenWinMode = false, tenWinCount = 0, onToggleTenWin,
}: Props) {
  const currentMode = PILOT_MODES.find(m => m.id === mode)
  const totalSettled = sessionWins + sessionLosses
  const sessionWR = totalSettled > 0 ? Math.round((sessionWins / totalSettled) * 100) : 0
  const wrColor = sessionWR >= 65 ? "text-emerald-400" : sessionWR >= 50 ? "text-yellow-400" : "text-red-400"

  const modeNeeded = () => {
    if (mode === "precision") return 5
    if (mode === "conservative") return 4
    if (mode === "balanced") return 3
    if (mode === "aggressive") return 3
    if (mode === "turbo") return 4
    return 3  // smart
  }

  return (
    <div className="trade-card">
      {/* Header */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Rocket size={16} className="text-blue-400" />
          <span className="text-sm font-semibold text-slate-200">Auto-Pilot</span>
          <span className="text-[10px] px-2 py-0.5 bg-blue-900/40 text-blue-300 border border-blue-700/40 rounded-md font-medium">
            {currentMode?.name}
          </span>
        </div>
        {/* Session win-rate badge */}
        {totalSettled > 0 && (
          <div className="flex items-center gap-1.5 px-2 py-1 bg-[#0a0e1a] border border-[#1e2a3a] rounded-lg">
            <span className="text-[10px] text-slate-500">Session WR</span>
            <span className={`text-[10px] font-bold ${wrColor}`}>{sessionWR}%</span>
            <span className="text-[9px] text-slate-600">{sessionWins}W/{sessionLosses}L</span>
          </div>
        )}
      </div>

      {/* Mode grid */}
      <div className="grid grid-cols-2 gap-2 mb-3">
        {PILOT_MODES.map(m => (
          <div
            key={m.id}
            onClick={() => isConnected && onModeChange(m.id)}
            className={`relative p-2.5 rounded-xl border cursor-pointer transition-all ${
              mode === m.id
                ? m.highlight === "emerald"
                  ? "bg-emerald-900/20 border-emerald-700/50"
                  : "bg-blue-900/20 border-blue-700/50"
                : "bg-[#0a0e1a] border-[#1e2a3a] hover:border-slate-600"
            } ${!isConnected ? "opacity-40 cursor-not-allowed" : ""}`}
          >
            <div className="flex items-center gap-1.5 mb-1">
              {m.icon}
              <span className={`text-xs font-bold ${mode === m.id ? "text-slate-100" : "text-slate-300"}`}>{m.name}</span>
              {m.tag && (
                <span className={`text-[9px] px-1.5 py-0.5 rounded font-bold ml-auto ${
                  m.tag === "BEST"
                    ? "bg-emerald-900/40 text-emerald-300 border border-emerald-700/40"
                    : "bg-blue-900/40 text-blue-300"
                }`}>
                  {m.tag}
                </span>
              )}
            </div>
            <p className="text-[9px] text-slate-600 leading-tight">{m.desc}</p>
            {/* Conf + cooldown badges */}
            <div className="flex items-center gap-1 mt-1.5">
              <span className="text-[8px] px-1 py-0.5 rounded bg-slate-800 text-slate-500 border border-slate-700/30">{m.conf}</span>
              <span className="text-[8px] px-1 py-0.5 rounded bg-slate-800 text-slate-500 border border-slate-700/30">{m.cooldown}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-4 gap-2 mb-3">
        {[
          { label: "Agree", value: `${agree}/${maxAgree}`, color: "text-slate-300" },
          { label: "Strength", value: `${strength}%`, color: strength >= 60 ? "text-emerald-400" : "text-slate-400" },
          { label: "Win Prob", value: `${winProb}%`, color: winProb >= 60 ? "text-yellow-400" : "text-slate-400" },
          { label: "Cooldown", value: `${cooldown}s`, color: "text-slate-300" },
        ].map(s => (
          <div key={s.label} className="bg-[#0a0e1a] border border-[#1e2a3a] rounded-xl p-2 text-center">
            <div className="text-[9px] text-slate-500 mb-1">{s.label}</div>
            <div className={`text-sm font-bold ${s.color}`}>{s.value}</div>
          </div>
        ))}
      </div>

      {/* Status bar */}
      <div className="flex items-center gap-2 px-3 py-2.5 bg-[#0a0e1a] border border-[#1e2a3a] rounded-xl mb-3">
        <div className={`w-2 h-2 rounded-full flex-shrink-0 ${agree >= modeNeeded() ? "bg-emerald-400 pulse-live" : "bg-slate-600"}`} />
        <span className="text-xs text-slate-400">
          {agree >= modeNeeded()
            ? `Signal ready: ${agree}/${modeNeeded()} indicators aligned`
            : `Waiting: need ${modeNeeded()}/${maxAgree} indicators aligned`}
        </span>
      </div>

      {/* 10-Win Mode button */}
      <button
        onClick={() => isConnected && onToggleTenWin?.()}
        disabled={!isConnected}
        className={`w-full flex items-center justify-between px-4 py-3 rounded-xl border transition-all mb-3 ${
          tenWinMode
            ? "bg-amber-950/40 border-amber-600/60 shadow-sm shadow-amber-900/30"
            : "bg-[#0a0e1a] border-[#1e2a3a] hover:border-amber-800/50"
        } ${!isConnected ? "opacity-40 cursor-not-allowed" : "cursor-pointer"}`}
      >
        <div className="flex items-center gap-3">
          <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
            tenWinMode ? "bg-amber-500/20 border border-amber-500/40" : "bg-slate-800 border border-slate-700"
          }`}>
            <Target size={15} className={tenWinMode ? "text-amber-400" : "text-slate-500"} />
          </div>
          <div className="text-left">
            <div className="flex items-center gap-1.5">
              <span className={`text-xs font-bold ${tenWinMode ? "text-amber-300" : "text-slate-300"}`}>
                10-Win Mode
              </span>
              {tenWinMode && (
                <span className="text-[8px] font-bold px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-400 border border-amber-500/30 uppercase tracking-wide">
                  Trading
                </span>
              )}
            </div>
            <div className="text-[10px] mt-0.5">
              {tenWinMode
                ? <span className="text-amber-600">{tenWinCount}/10 wins collected — stops on any loss</span>
                : <span className="text-slate-600">Tap to start auto-trading. Stops after 10 wins or on first loss.</span>}
            </div>
          </div>
        </div>

        <div className="flex flex-col items-end gap-1.5 flex-shrink-0">
          {/* Toggle pill */}
          <div className={`relative w-10 h-5 rounded-full transition-colors ${
            tenWinMode ? "bg-amber-500" : "bg-slate-700"
          }`}>
            <div className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-all ${
              tenWinMode ? "left-[22px]" : "left-0.5"
            }`} />
          </div>
          {/* Mini win dots */}
          {tenWinMode && (
            <div className="flex gap-0.5">
              {Array.from({ length: 10 }).map((_, i) => (
                <div
                  key={i}
                  className={`w-1.5 h-1.5 rounded-full ${i < tenWinCount ? "bg-amber-400" : "bg-amber-950/60 border border-amber-900/40"}`}
                />
              ))}
            </div>
          )}
        </div>
      </button>

      {/* Info */}
      <div className="flex items-start gap-2 px-2 py-1">
        <Info size={11} className="text-slate-600 flex-shrink-0 mt-0.5" />
        <p className="text-[10px] text-slate-600 leading-tight">
          {mode === "precision"
            ? "Precision waits for all 5 indicator families to agree — trades rarely but with the highest possible accuracy."
            : mode === "smart"
            ? "Smart auto-selects the best mode based on your live win rate each session."
            : "Higher cooldown = fewer trades but each trade has been more thoroughly validated."}
        </p>
      </div>
    </div>
  )
}
