"use client"

import { useState, useEffect, useRef, useCallback } from "react"
import DerivConnection from "@/components/DerivConnection"
import TradingStrategies from "@/components/TradingStrategies"
import TradeSettings, { type TradeConfig } from "@/components/TradeSettings"
import TradeHistory, { type Trade } from "@/components/TradeHistory"

import PredictionHub, { type PredictionData } from "@/components/PredictionHub"
import SymbolAdvisor from "@/components/SymbolAdvisor"
import DigitChart from "@/components/DigitChart"
import LiveAnalysis from "@/components/LiveAnalysis"
import { getDerivWS, resetDerivWS } from "@/lib/deriv-ws"
import {
  getFullSignal,
  getLastDigit,
} from "@/lib/indicators"
import type { PilotMode } from "@/lib/types"
import { MessageSquare } from "lucide-react"

// ─── helpers ─────────────────────────────────────────────────────────────────

function contractTypeForSettings(tradeType: string, signal: "BUY" | "SELL" | "WAIT"): string {
  const map: Record<string, [string, string]> = {
    CALL_PUT: ["CALL", "PUT"],
    DIGITEVEN_ODD: ["DIGITEVEN", "DIGITODD"],
    DIGITMATCH_DIFF: ["DIGITMATCH", "DIGITDIFF"],
    DIGITOVER_UNDER: ["DIGITOVER", "DIGITUNDER"],
    ONETOUCH_NOTOUCH: ["ONETOUCH", "NOTOUCH"],
  }
  const pair = map[tradeType] ?? ["CALL", "PUT"]
  return signal === "BUY" ? pair[0] : pair[1]
}

function durationForType(tradeType: string): [number, string] {
  if (tradeType === "CALL_PUT") return [1, "m"]           // Rise/Fall — 1 minute
  if (tradeType === "ONETOUCH_NOTOUCH") return [5, "m"]  // Touch — 5 minutes
  // All digit contracts (Even/Odd, Match/Differ, Over/Under) use ticks
  return [1, "t"]
}

// ─── default states ───────────────────────────────────────────────────────────

const DEFAULT_CONFIG: TradeConfig = {
  symbol: "R_10",
  tradeType: "CALL_PUT",
  stake: 0.35,
  martingale: false,
  takeProfit: "",
  stopLoss: "",
  stakeBoost: 1,
  autoTrading: false,
  fastAutoTrade: false,
  bestSignalOnly: false,  // default OFF — let shouldTrade engine decide quality
}

const DEFAULT_PREDICTION: PredictionData = {
  confidence: 5,
  grade: "POOR",
  signal: "WAIT",
  marketRegime: "Ranging",
  regimeDesc: "Good for Over/Under, Match/Differ",
  recStake: 0.35,
  strategyInsight: "Select a strategy to see strategy-specific tips.",
  ticksCollected: 0,
  totalTicks: 60,
  winRate: 0,
  tradesCount: 0,
}

// ─── main component ────────────────────────────────────────────────────────────

export default function TradingBotPage() {
  // Connection
  const [isConnected, setIsConnected] = useState(false)
  const [isConnecting, setIsConnecting] = useState(false)
  const [connError, setConnError] = useState("")
  const [balance, setBalance] = useState<number | null>(null)
  const [currency, setCurrency] = useState("USD")
  const [accountType, setAccountType] = useState("")

  // Strategy
  const [activeStrategy, setActiveStrategy] = useState<string | null>(null)

  // Trade config
  const [config, setConfig] = useState<TradeConfig>(DEFAULT_CONFIG)
  const configRef = useRef(config)
  const prevAutoTradingRef = useRef(false)
  useEffect(() => {
    const wasOff = !prevAutoTradingRef.current
    const isNowOn = config.autoTrading
    // Whenever autoTrading is turned ON from any source, reset all stale locks
    if (wasOff && isNowOn) {
      tradeInFlightRef.current = false
      signalSkippedRef.current = false
      lastAutoTradeRef.current = 0
      signalPersistenceRef.current = { signal: "WAIT", count: 0 }
      if (winGatePhaseRef.current === "cooldown") {
        winGateCountRef.current = 0
        winGatePhaseRef.current = "hunting"
        setWinGateCount(0)
        setWinGatePhase("hunting")
      }
    }
    prevAutoTradingRef.current = config.autoTrading
    configRef.current = config
    if (!config.martingale) {
      initialStakeRef.current = config.stake
    }
  }, [config])

  // Ticks
  const [ticks, setTicks] = useState<number[]>([])
  const [digits, setDigits] = useState<number[]>([])
  const [upCount, setUpCount] = useState(0)
  const [downCount, setDownCount] = useState(0)
  const [lastQuote, setLastQuote] = useState<number | null>(null)
  const ticksRef = useRef<number[]>([])
  const digitsRef = useRef<number[]>([])

  // Trades
  const [trades, setTrades] = useState<Trade[]>([])
  const tradesRef = useRef<Trade[]>([])
  const [isBuying, setIsBuying] = useState(false)
  const [isSelling, setIsSelling] = useState(false)

  // Per-strategy live signals
  const [strategySignals, setStrategySignals] = useState<Record<string, { signal: "BUY" | "SELL" | "WAIT"; confidence: number }>>({})

  // 10-Win Mode: target 10 consecutive wins before any loss
  // When active: win target = 10, any loss resets count to 0 + stops auto-trading
  const [tenWinMode, setTenWinMode] = useState(false)
  const tenWinModeRef = useRef(false)
  const [tenWinCount, setTenWinCount] = useState(0)
  const tenWinCountRef = useRef(0)

  // Helper: toggle 10-Win Mode, keeping ref in sync immediately (not via useEffect delay)
  function activateTenWinMode(active: boolean) {
    tenWinModeRef.current = active
    setTenWinMode(active)
    if (active) {
      // Reset all counters and locks so the first valid signal fires instantly
      tenWinCountRef.current = 0
      setTenWinCount(0)
      winGateCountRef.current = 0
      winGatePhaseRef.current = "hunting"
      setWinGateCount(0)
      setWinGatePhase("hunting")
      tradeInFlightRef.current = false
      lastAutoTradeRef.current = 0
      signalPersistenceRef.current = { signal: "WAIT", count: 0 }
    } else {
      // Stopping: release any in-flight lock
      tradeInFlightRef.current = false
      tenWinCountRef.current = 0
      setTenWinCount(0)
    }
  }

  // Win-Gate cycle: 3 wins (or 10 in tenWinMode) → cooldown → restart
  // Phase: "hunting" | "building" | "cooldown"
  // hunting  = need wins (0 wins, tightest gates, half stake)
  // building = wins accumulating, gates open progressively
  // cooldown = target wins achieved, resting before next cycle
  const [winGateCount, setWinGateCount] = useState(0)
  const [winGatePhase, setWinGatePhase] = useState<"hunting" | "building" | "cooldown">("hunting")
  const [cooldownEndsAt, setCooldownEndsAt] = useState<number>(0)
  const [cooldownRemaining, setCooldownRemaining] = useState(0)
  const cooldownRemainingRef = useRef(0)
  const CYCLE_COOLDOWN_MS = 30_000  // 30s rest after completing a win cycle
  const LOSS_COOLDOWN_MS  = 15_000  // 15s penalty cooldown after any loss
  const winGateCountRef = useRef(0)
  const winGatePhaseRef = useRef<"hunting" | "building" | "cooldown">("hunting")
  useEffect(() => {
    winGateCountRef.current = winGateCount
    winGatePhaseRef.current = winGatePhase
  }, [winGateCount, winGatePhase])

  // Tick the cooldown display every second
  useEffect(() => {
    if (winGatePhase !== "cooldown") return
    const timer = setInterval(() => {
      const rem = Math.max(0, Math.ceil((cooldownEndsAt - Date.now()) / 1000))
      cooldownRemainingRef.current = rem
      setCooldownRemaining(rem)
      if (rem <= 0) {
        // Cooldown finished — restart cycle
        winGateCountRef.current = 0
        winGatePhaseRef.current = "hunting"
        cooldownRemainingRef.current = 0
        setWinGateCount(0)
        setWinGatePhase("hunting")
        setCooldownRemaining(0)
      }
    }, 500)
    return () => clearInterval(timer)
  }, [winGatePhase, cooldownEndsAt])

  // Convenience boolean: gate is "locked" (hunting or cooldown = no free trading)
  const winGateLocked = winGatePhase !== "building" || winGateCount < 3
  const winGateLockedRef = useRef(true)
  useEffect(() => {
    winGateLockedRef.current = winGatePhase !== "building" || winGateCount < 3
  }, [winGatePhase, winGateCount])

  // Risk score: 0-100, updated on each signal (higher = safer to trade)
  const [riskScore, setRiskScore] = useState(0)

  // Cycle stats: track wins/losses per cycle across all cycles
  const [totalCycles, setTotalCycles] = useState(0)
  const [sessionWins, setSessionWins] = useState(0)
  const [sessionLosses, setSessionLosses] = useState(0)
  // Last 10 trade results for mini-chart
  const [recentResults, setRecentResults] = useState<("win" | "loss")[]>([])

  // Skip-signal: user can force bot to wait for next better signal
  const [signalSkipped, setSignalSkipped] = useState(false)
  const signalSkippedRef = useRef(false)
  useEffect(() => { signalSkippedRef.current = signalSkipped }, [signalSkipped])

  // Signal persistence: track how many consecutive ticks the current signal has held
  // Requires signal to hold for N ticks before auto-pilot fires — prevents reacting to noise
  const signalPersistenceRef = useRef<{ signal: "BUY" | "SELL" | "WAIT"; count: number }>({ signal: "WAIT", count: 0 })
  const [signalAge, setSignalAge] = useState(0)  // displayed in UI

  // Pending-trade lock so we never stack two simultaneous trades
  const tradeInFlightRef = useRef(false)

  // Pilot
  const [pilotMode, setPilotMode] = useState<PilotMode>("balanced")
  const [pilotAgree, setPilotAgree] = useState(0)
  const [pilotMaxAgree, setPilotMaxAgree] = useState(9)
  const [pilotStrength, setPilotStrength] = useState(0)
  const [pilotWinProb, setPilotWinProb] = useState(50)
  const [pilotCooldown, setPilotCooldown] = useState(4)

  // Prediction
  const [prediction, setPrediction] = useState<PredictionData>(DEFAULT_PREDICTION)

  // Auto-trade cooldown
  const lastAutoTradeRef = useRef<number>(0)
  const currentSymbolRef = useRef<string>("R_10")
  const initialStakeRef = useRef<number>(DEFAULT_CONFIG.stake)
  const pilotModeRef = useRef<PilotMode>("balanced")
  useEffect(() => { pilotModeRef.current = pilotMode }, [pilotMode])
  const isConnectedRef = useRef(false)
  useEffect(() => { isConnectedRef.current = isConnected }, [isConnected])
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const executeTradeRef = useRef<(contractType: string, cfg: TradeConfig, barrier?: string) => Promise<void>>(async () => {})
  const computeIndicatorsRef = useRef<(prices: number[], digs: number[]) => void>(() => {})

  // ─── compute indicators whenever ticks update ───────────────────────────────
  const computeIndicators = useCallback((prices: number[], digs: number[]) => {
    const cfg = configRef.current
    const NEEDED = 60
    const collected = prices.length

    if (collected < NEEDED) {
      setPrediction((p) => ({ ...p, ticksCollected: collected, totalTicks: NEEDED }))
      return
    }

    // Use the master full-signal engine
    const fs = getFullSignal(prices, cfg.tradeType, digs)

    const signal: "BUY" | "SELL" | "WAIT" =
      fs.direction === "CALL" ? "BUY" :
      fs.direction === "PUT" ? "SELL" : "WAIT"

    const { confidence } = fs

    // Autopilot counts from votes
    const callVotes = fs.votes.filter(v => v.signal === "CALL").length
    const putVotes  = fs.votes.filter(v => v.signal === "PUT").length
    const agreeCount = signal === "BUY" ? callVotes : signal === "SELL" ? putVotes : 0
    const maxAgree   = fs.votes.length || 9
    const strength   = Math.round((agreeCount / maxAgree) * 100)

    // Signal persistence — count consecutive ticks the same signal has held
    const prev = signalPersistenceRef.current
    if (signal === prev.signal && signal !== "WAIT") {
      signalPersistenceRef.current = { signal, count: prev.count + 1 }
    } else if (signal !== "WAIT") {
      signalPersistenceRef.current = { signal, count: 1 }
    } else {
      signalPersistenceRef.current = { signal: "WAIT", count: 0 }
    }
    setSignalAge(signalPersistenceRef.current.count)

    setPilotAgree(agreeCount)
    setPilotMaxAgree(maxAgree)
    setPilotStrength(strength)
    setPilotWinProb(Math.min(Math.max(confidence, 10), 95))

    // Grade
    let grade: PredictionData["grade"] = "POOR"
    if (confidence >= 80) grade = "STRONG"
    else if (confidence >= 68) grade = "GOOD"
    else if (confidence >= 55) grade = "FAIR"

    // Market regime labels
    const regimeLabels: Record<string, [PredictionData["marketRegime"], string]> = {
      trending: ["Trending", "Good for Rise/Fall contracts"],
      ranging:  ["Ranging",  "Good for Over/Under, Match/Differ"],
      volatile: ["Volatile", "Use caution — high volatility"],
    }
    const [marketRegime, regimeDesc] = regimeLabels[fs.regime] ?? ["Ranging", ""]

    // Strategy insight (richer now)
    const evenCount = digs.filter(d => d % 2 === 0).length
    const oddCount  = digs.length - evenCount
    const macdDir = (fs.macd?.histogram ?? 0) > 0 ? "Bullish +" : "Bearish "
    const macdAbs = Math.abs(fs.macd?.histogram ?? 0).toFixed(4)
    const insightMap: Record<string, string> = {
      digitai:     `Even/Odd: ${evenCount}E vs ${oddCount}O (last ${digs.length}). ${fs.votes.find(v => v.name === "Streak")?.value ?? ""} streak.`,
      unibet:      `RSI ${(fs.rsi ?? 50).toFixed(1)} · MACD ${macdDir}${macdAbs} · BB%: ${(fs.bb?.percentB ?? 50).toFixed(0)}%`,
      tradex:      `Match/Differ: ${fs.votes.find(v => v.name === "Ratio30")?.value ?? fs.votes.find(v => v.name === "Ratio")?.value ?? "—"} · ${signal !== "WAIT" ? "Signal active" : "No clear bias"}`,
      optimax:     `Over/Under: ${fs.votes.find(v => v.name === "Ratio20")?.value ?? fs.votes.find(v => v.name === "Ratio")?.value ?? "—"} · Streak: ${fs.streak?.count ?? 0} ${fs.streak?.direction ?? "flat"}`,
      accumulator: `Momentum ${(fs.momentum ?? 0) > 0 ? "positive +" : "negative "}${Math.abs(fs.momentum ?? 0).toFixed(4)} · ATR ${(fs.atr ?? 0).toFixed(5)} · ${regimeDesc}`,
      autors:      `Streak: ${fs.streak?.count ?? 0} ${fs.streak?.direction ?? "flat"} ticks · CCI: ${(fs.cci ?? 0).toFixed(0)} · ${signal !== "WAIT" ? "Entry detected" : "Awaiting momentum"}`,
    }
    const strategyInsight = activeStrategy
      ? (insightMap[activeStrategy] ?? "Select a strategy to see tips.")
      : "Select a strategy to see strategy-specific tips."

    const doneTrades = tradesRef.current.filter(x => x.result !== "pending")
    const winRate = doneTrades.length > 0
      ? (doneTrades.filter(x => x.result === "win").length / doneTrades.length) * 100 : 0

    // ── Risk Score: composite safety metric (0–100) ──────────────────
    // Penalise volatile regime, reward good grade + high confidence + aligned votes
    const callVotesCount = fs.votes.filter(v => v.signal === "CALL").length
    const putVotesCount  = fs.votes.filter(v => v.signal === "PUT").length
    const activeVotesTotal = fs.votes.filter(v => v.signal !== "NEUTRAL").length
    const winningVotes   = signal === "BUY" ? callVotesCount : signal === "SELL" ? putVotesCount : 0
    const voteAlignPct   = activeVotesTotal > 0 ? (winningVotes / activeVotesTotal) * 100 : 0
    const regimePenalty  = fs.regime === "volatile" ? -15 : fs.regime === "trending" && cfg.tradeType === "CALL_PUT" ? 5 : 0
    const gradePts       = grade === "STRONG" ? 25 : grade === "GOOD" ? 15 : grade === "FAIR" ? 5 : -10
    const rawRiskScore   = Math.round(confidence * 0.45 + voteAlignPct * 0.30 + gradePts + regimePenalty)
    const computedRiskScore = Math.min(Math.max(rawRiskScore, 0), 100)
    setRiskScore(computedRiskScore)

    // ── Recommended stake: scale by risk score ────────────────────────
    // Under 50 risk: reduce to 60% of base stake
    // 50-70 risk: base stake
    // Over 70 risk: allow up to 120% stake (still capped by user's stake)
    const stakeMult = computedRiskScore >= 70 ? 1.0 : computedRiskScore >= 50 ? 0.85 : 0.6
    const recStake  = Math.max(cfg.stake * cfg.stakeBoost * stakeMult, 0.35)

    setPrediction({
      confidence,
      grade,
      signal,
      marketRegime,
      regimeDesc,
      recStake,
      strategyInsight,
      ticksCollected: collected,
      totalTicks: NEEDED,
      winRate,
      tradesCount: tradesRef.current.length,
      votes: fs.votes,
      callScore: fs.callScore,
      putScore: fs.putScore,
      rsi: fs.rsi,
      streak: fs.streak,
      shouldTrade: fs.shouldTrade,
      riskScore: computedRiskScore,
      winGateCount: winGateCountRef.current,
      winGateLocked: winGateLockedRef.current,
      winGatePhase: winGatePhaseRef.current,
      cooldownRemaining: cooldownRemainingRef.current,
      familyScore: fs.familyScore,
      signalAge: signalPersistenceRef.current.count,
      signalStrength: fs.signalStrength,
      supertrend: fs.supertrend,
      heikinAshi: fs.heikinAshi,
      roc: fs.roc,
      signalReadiness: fs.signalReadiness,
      priceActionOk: fs.priceActionOk,
      confluenceScore: fs.confluenceScore,
      tradeType: cfg.tradeType,
    })

    // Compute signals for all strategy types to show live badges
    const stratTypeMap: Record<string, string> = {
      digitai: "DIGITEVEN_ODD",
      unibet: "CALL_PUT",
      tradex: "DIGITMATCH_DIFF",
      optimax: "DIGITOVER_UNDER",
      accumulator: "CALL_PUT",
      autors: "ONETOUCH_NOTOUCH",
    }
    const newSigs: Record<string, { signal: "BUY" | "SELL" | "WAIT"; confidence: number }> = {}
    for (const [id, tt] of Object.entries(stratTypeMap)) {
      const s = getFullSignal(prices, tt, digs)
      newSigs[id] = {
        signal: s.direction === "CALL" ? "BUY" : s.direction === "PUT" ? "SELL" : "WAIT",
        confidence: s.confidence,
      }
    }
    setStrategySignals(newSigs)

    // ── Pre-warm proposal so manual + auto clicks fire in one network hop ────
    // Called on every tick where shouldTrade is true — keeps the cached proposal fresh.
    if (fs.shouldTrade && signal !== "WAIT" && isConnectedRef.current) {
      const [dur, unit] = durationForType(cfg.tradeType)
      const ct = contractTypeForSettings(cfg.tradeType, signal)
      getDerivWS().warmProposal({
        symbol: cfg.symbol,
        contractType: ct,
        duration: dur,
        durationUnit: unit,
        stake: cfg.stake * cfg.stakeBoost,
        basis: "stake",
      })
    }

    // ── 10-Win Mode auto-fire ─────────────────────────────────────────────────
    // When 10-Win Mode is active, fire trades automatically on every valid signal.
    // No cooldown delay — fires the instant shouldTrade becomes true.
    if (
      tenWinModeRef.current &&           // mode must be active
      isConnectedRef.current &&          // must be connected
      fs.shouldTrade &&                  // engine quality gate must pass
      signal !== "WAIT" &&               // must have a clear direction
      !tradeInFlightRef.current &&       // no trade already running
      winGatePhaseRef.current !== "cooldown"  // not in post-cycle rest
    ) {
      tradeInFlightRef.current = true
      const contractType = contractTypeForSettings(cfg.tradeType, signal)
      executeTradeRef.current(contractType, cfg).finally(() => {
        tradeInFlightRef.current = false
      })
    }
  }, [activeStrategy])

  // Keep computeIndicators ref in sync so the tick handler always calls the latest version
  computeIndicatorsRef.current = computeIndicators

  // ─── WebSocket connection ────────────────────────────────────────────────────
  async function handleConnect(token: string) {
    setIsConnecting(true)
    setConnError("")
    try {
      resetDerivWS()
      const ws = getDerivWS()
      const account = await ws.connect(token)
      setBalance(account.balance)
      setCurrency(account.currency)
      setAccountType(account.loginid)
      setIsConnected(true)
      setConnError("")

      // Subscribe ticks for first connection
      ws.subscribeTicks(configRef.current.symbol)
      ws.subscribeBalance()
      currentSymbolRef.current = configRef.current.symbol

      // After auto-reconnect: re-subscribe ticks + balance so live data resumes
      ws.onReconnect(() => {
        ws.subscribeTicks(configRef.current.symbol)
        ws.subscribeBalance()
        setIsConnected(true)
      })

      // Clear any handlers from a previous connection before re-registering —
      // prevents duplicate tick/balance/settlement events after reconnect
      ws.offAll("tick")
      ws.offAll("balance")
      ws.offAll("contract_update")

      // Tick handler
      ws.on("tick", (data) => {
        const tick = data as { quote: number; epoch: number }
        const price = tick.quote
        setLastQuote(price)
        const digit = getLastDigit(price)

        ticksRef.current = [...ticksRef.current.slice(-299), price]
        digitsRef.current = [...digitsRef.current.slice(-299), digit]

        setTicks([...ticksRef.current])
        setDigits([...digitsRef.current])
        setUpCount((c) => (ticksRef.current.length >= 2 && price > ticksRef.current[ticksRef.current.length - 2] ? c + 1 : c))
        setDownCount((c) => (ticksRef.current.length >= 2 && price < ticksRef.current[ticksRef.current.length - 2] ? c + 1 : c))

        computeIndicatorsRef.current(ticksRef.current, digitsRef.current)
      })

      // Balance handler
      ws.on("balance", (data) => {
        const b = data as { balance: number; currency: string }
        setBalance(b.balance)
        setCurrency(b.currency)
      })

      // Global contract settlement handler — registered ONCE here
      ws.on("contract_update", (data) => {
        const c = data as { contract_id: string; profit: number; status: string; sell_price?: number; buy_price?: number }
        const settled = c.status === "sold" || c.status === "won" || c.status === "lost"
        if (!settled) return
        const profit = typeof c.profit === "number" ? c.profit : 0
        const result: "win" | "loss" = profit >= 0 ? "win" : "loss"

        setTrades((prev) => {
          const idx = prev.findIndex((t) => t.id === String(c.contract_id))
          if (idx === -1) return prev
          const updated = [...prev]
          updated[idx] = { ...updated[idx], result, profit, payout: c.sell_price ?? null }
          tradesRef.current = updated

          // Martingale logic on settlement
          const cfg = configRef.current
          if (result === "loss" && cfg.martingale) {
            const baseStake = initialStakeRef.current
            const nextStake = Math.min(updated[idx].stake * 2, 1000)
            setConfig((p) => ({ ...p, stake: nextStake }))
            if (nextStake >= baseStake * 8) {
              setConfig((p) => ({ ...p, stake: baseStake, martingale: false }))
            }
          } else if (result === "win" && cfg.martingale) {
            setConfig((p) => ({ ...p, stake: initialStakeRef.current }))
          }
          return updated
        })

        // ── Win-Gate cycle logic ───────────────────────────────────────
        // Clear in-flight lock so the next signal can fire
        tradeInFlightRef.current = false
        // Clear any skip so the next trade cycle starts fresh
        signalSkippedRef.current = false
        setSignalSkipped(false)

        // Update session totals + recent results
        if (result === "win") {
          setSessionWins(w => w + 1)
        } else {
          setSessionLosses(l => l + 1)
        }
        setRecentResults(prev => {
          const next = [...prev, result]
          return next.length > 10 ? next.slice(-10) : next
        })

        const winTarget = tenWinModeRef.current ? 10 : 3

        if (result === "win") {
          const prev = winGateCountRef.current
          const next = prev + 1

          // Track 10-win mode counter separately
          if (tenWinModeRef.current) {
            tenWinCountRef.current = next
            setTenWinCount(next)
          }

          if (next >= winTarget) {
            // Cycle complete — enter cooldown, then restart
            winGateCountRef.current = winTarget
            winGatePhaseRef.current = "cooldown"
            setWinGateCount(winTarget)
            setWinGatePhase("cooldown")
            setTotalCycles(c => c + 1)
            const endsAt = Date.now() + CYCLE_COOLDOWN_MS
            setCooldownEndsAt(endsAt)
            cooldownRemainingRef.current = Math.ceil(CYCLE_COOLDOWN_MS / 1000)
            setCooldownRemaining(cooldownRemainingRef.current)
            lastAutoTradeRef.current = endsAt
          } else {
            winGateCountRef.current = next
            winGatePhaseRef.current = "building"
            setWinGateCount(next)
            setWinGatePhase("building")
          }
        } else {
          // Loss — reset entire cycle
          winGateCountRef.current = 0
          winGatePhaseRef.current = "hunting"
          setWinGateCount(0)
          setWinGatePhase("hunting")
          cooldownRemainingRef.current = 0
          setCooldownRemaining(0)
          lastAutoTradeRef.current = Date.now() + LOSS_COOLDOWN_MS

          // 10-Win Mode: any loss resets streak and stops the bot immediately
          if (tenWinModeRef.current) {
            activateTenWinMode(false)
          }
        }
      })
    } catch (err) {
      setConnError(err instanceof Error ? err.message : "Connection failed")
    } finally {
      setIsConnecting(false)
    }
  }

  function handleDisconnect() {
    // Clear all app-level handlers BEFORE resetting so they don't fire on the final close event
    const ws = getDerivWS()
    ws.offAll("tick")
    ws.offAll("balance")
    ws.offAll("contract_update")
    resetDerivWS()
    setIsConnected(false)
    setBalance(null)
    setTicks([])
    setDigits([])
    ticksRef.current = []
    digitsRef.current = []
    setLastQuote(null)
    setUpCount(0)
    setDownCount(0)
    setPrediction(DEFAULT_PREDICTION)
    tradeInFlightRef.current = false
    setIsBuying(false)
    setIsSelling(false)
  }

  // ─── Re-subscribe when symbol changes ────────────────────────────────────────
  useEffect(() => {
    if (!isConnected) return
    const ws = getDerivWS()
    if (config.symbol !== currentSymbolRef.current) {
      ws.unsubscribeTicks(currentSymbolRef.current)
      setTicks([])
      setDigits([])
      ticksRef.current = []
      digitsRef.current = []
      setLastQuote(null)
      setUpCount(0)
      setDownCount(0)
      setPrediction(DEFAULT_PREDICTION)
      ws.subscribeTicks(config.symbol)
      currentSymbolRef.current = config.symbol
    }
  }, [config.symbol, isConnected])

  // ─── Trade execution ──────────────────────────────────────────────────────────
  async function executeTrade(contractType: string, cfg: TradeConfig, barrier?: string): Promise<void> {
    // Use ref (not state) so stale closure on isConnected never silently drops a trade
    if (!isConnectedRef.current) return
    const ws = getDerivWS()
    const [duration, unit] = durationForType(cfg.tradeType)
    const actualStake = cfg.stake * cfg.stakeBoost

    const tradeId = Date.now().toString()

    // ── Fire the socket call IMMEDIATELY — zero React state updates before this ──
    let boughtResult: Record<string, unknown> | null = null
    try {
      boughtResult = await ws.buyFromWarmed({
        symbol: cfg.symbol,
        contractType,
        duration,
        durationUnit: unit,
        stake: actualStake,
        basis: "stake",
        // Only include barrier when it's a non-empty string (Over/Under/Match/Differ)
        ...(barrier ? { barrier } : {}),
      })
    } catch (err) {
      // Trade failed before it was recorded — just release the lock and bail
      tradeInFlightRef.current = false
      return
    }

    const bought = boughtResult as { contract_id: string; buy_price: number; payout: number }
    const confirmedId = String(bought.contract_id || tradeId)

    // ── Record the trade in state AFTER confirmation (accurate, no ghost trades) ──
    const newTrade: Trade = {
      id: confirmedId,
      time: Date.now(),
      symbol: cfg.symbol,
      contractType,
      direction: contractType === "CALL" || contractType === "DIGITEVEN" || contractType === "DIGITMATCH" || contractType === "DIGITOVER" ? "CALL" : "PUT",
      stake: bought.buy_price ?? actualStake,
      payout: bought.payout ?? null,
      profit: null,
      result: "pending",
    }
    setTrades((prev) => {
      const updated = [...prev, newTrade]
      tradesRef.current = updated
      return updated
    })

    // Subscribe so the global contract_update handler receives settlement events
    ws.subscribeContract(confirmedId)
  }

  // Keep ref in sync
  executeTradeRef.current = executeTrade

  // Synchronous refs prevent double-fire without waiting for a React render cycle
  const buyLockRef  = useRef(false)
  const sellLockRef = useRef(false)

  function handleBuy() {
    if (buyLockRef.current) return
    if (!isConnectedRef.current) return  // bail early — no lock needed
    buyLockRef.current = true
    setIsBuying(true)
    const ct = contractTypeForSettings(config.tradeType, "BUY")
    executeTrade(ct, config).finally(() => { buyLockRef.current = false; setIsBuying(false) })
  }

  function handleSell() {
    if (sellLockRef.current) return
    if (!isConnectedRef.current) return
    sellLockRef.current = true
    setIsSelling(true)
    const ct = contractTypeForSettings(config.tradeType, "SELL")
    executeTrade(ct, config).finally(() => { sellLockRef.current = false; setIsSelling(false) })
  }

  function handleMultipliedBuy(multiplier: number) {
    if (buyLockRef.current) return
    if (!isConnectedRef.current) return
    buyLockRef.current = true
    setIsBuying(true)
    const ct = contractTypeForSettings(config.tradeType, "BUY")
    const boostedConfig = { ...config, stake: config.stake * multiplier }
    executeTrade(ct, boostedConfig).finally(() => { buyLockRef.current = false; setIsBuying(false) })
  }

  function handleMultipliedSell(multiplier: number) {
    if (sellLockRef.current) return
    if (!isConnectedRef.current) return
    sellLockRef.current = true
    setIsSelling(true)
    const ct = contractTypeForSettings(config.tradeType, "SELL")
    const boostedConfig = { ...config, stake: config.stake * multiplier }
    executeTrade(ct, boostedConfig).finally(() => { sellLockRef.current = false; setIsSelling(false) })
  }

  function handleClearHistory() {
    setTrades([])
    tradesRef.current = []
  }

  // ─── Net profit ───────────────────────────────────────────────────────────────
  const netProfit = trades.reduce((sum, t) => {
    if (t.result === "win" && t.profit !== null) return sum + t.profit
    if (t.result === "loss" && t.profit !== null) return sum + t.profit
    return sum
  }, 0)

  // ─── TP / SL guard ────────────────────────────────────────────────────────────
  useEffect(() => {
    if (!config.autoTrading) return
    const tp = parseFloat(config.takeProfit)
    const sl = parseFloat(config.stopLoss)
    if (!isNaN(tp) && tp > 0 && netProfit >= tp) {
      setConfig((c) => ({ ...c, autoTrading: false }))
    }
    if (!isNaN(sl) && sl > 0 && netProfit <= -sl) {
      setConfig((c) => ({ ...c, autoTrading: false }))
    }
  }, [netProfit, config.autoTrading, config.takeProfit, config.stopLoss])

  // ─── render ───────────────────────────────────────────────────────────────────
  return (
    <div className="min-h-screen bg-[#0a0e1a]">
      {/* Header */}
      <div
        className="sticky top-0 z-50 flex items-center justify-between px-4 py-3"
        style={{ background: "#0a0e1a", borderBottom: "1px solid #1e2a3a" }}
      >
        <div className="flex items-center gap-2.5">
          <div
            className="w-8 h-8 rounded-full flex items-center justify-center"
            style={{ background: "linear-gradient(135deg,#1d4ed8,#0ea5e9)" }}
          >
            <MessageSquare size={14} color="#fff" />
          </div>
          <div>
            <p className="text-sm font-bold text-slate-200 leading-none">Blackbox AI</p>
            <p className="text-[10px] text-slate-500 leading-none mt-0.5">AI-Powered Trading Bot</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-slate-800 text-slate-400 border border-slate-700">
            <span className={`w-1.5 h-1.5 rounded-full ${isConnected ? "bg-emerald-400 pulse-live" : "bg-slate-500"}`} />
            {isConnected ? "Online" : "Offline"}
          </div>
        </div>
      </div>

      {/* 10-Win Mode progress banner */}
      {tenWinMode && isConnected && winGatePhase !== "cooldown" && (
        <div className="mx-4 mt-2 px-4 py-2.5 bg-amber-950/40 border border-amber-700/40 rounded-xl">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" className="text-amber-400 flex-shrink-0"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
              <span className="text-xs text-amber-300 font-bold">10-Win Mode</span>
              <span className="text-[10px] text-amber-700">— stops on any loss</span>
            </div>
            <span className="text-sm font-bold text-amber-400 tabular-nums">{tenWinCount}/10</span>
          </div>
          {/* Progress dots */}
          <div className="flex gap-1">
            {Array.from({ length: 10 }).map((_, i) => (
              <div
                key={i}
                className={`flex-1 h-2 rounded-sm transition-all duration-300 ${
                  i < tenWinCount ? "bg-amber-400" : "bg-amber-950/60 border border-amber-900/40"
                }`}
              />
            ))}
          </div>
        </div>
      )}

      {/* Cycle cooldown banner */}
      {winGatePhase === "cooldown" && cooldownRemaining > 0 && (
        <div className="mx-4 mt-2 flex items-center justify-between gap-3 px-4 py-2.5 bg-blue-950/40 border border-blue-800/40 rounded-xl">
          <div className="flex items-center gap-2">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="text-blue-400 flex-shrink-0"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
            <div>
              <span className="text-xs text-blue-300 font-semibold">
                {tenWinMode ? "10-win target reached" : "3-win cycle complete"} — cooldown active
              </span>
              <div className="text-[10px] text-blue-600">Auto-trading resumes in <span className="text-blue-400 font-bold">{cooldownRemaining}s</span>. Win cycle resets.</div>
            </div>
          </div>
          <div className="text-xl font-bold text-blue-400 tabular-nums flex-shrink-0">{cooldownRemaining}s</div>
        </div>
      )}

      {/* Loss streak lockout banner */}
      {(() => {
        const done = trades.filter(t => t.result !== "pending")
        let streak = 0
        for (let i = done.length - 1; i >= 0; i--) {
          if (done[i].result === "loss") streak++; else break
        }
        return streak >= 3 && config.autoTrading === false ? (
          <div className="mx-4 mt-2 flex items-center justify-between gap-3 px-4 py-2.5 bg-red-950/50 border border-red-800/40 rounded-xl">
            <div className="flex items-center gap-2">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" className="text-red-400 flex-shrink-0"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
              <span className="text-xs text-red-300 font-medium">{streak} consecutive losses — auto-trading paused for protection</span>
            </div>
            <button
              onClick={() => {
                setConfig(c => ({ ...c, autoTrading: false, stake: initialStakeRef.current }))
                setWinGateCount(0)
                setWinGatePhase("hunting")
              }}
              className="text-[10px] text-red-400 border border-red-800/50 px-2 py-1 rounded hover:bg-red-900/30 transition-colors flex-shrink-0"
            >
              Reset
            </button>
          </div>
        ) : null
      })()}

      {/* Scrollable content */}
      <div className="px-4 py-4 space-y-4 pb-10 max-w-2xl mx-auto">
        {/* 1. Connection */}
        <DerivConnection
          isConnected={isConnected}
          isConnecting={isConnecting}
          balance={balance}
          currency={currency}
          accountType={accountType}
          onConnect={handleConnect}
          onDisconnect={handleDisconnect}
          error={connError}
        />

        {/* 2. Trading Strategies */}
        <TradingStrategies
          activeStrategy={activeStrategy}
          regime={prediction.marketRegime}
          strategySignals={strategySignals}
          currentSymbol={config.symbol}
          onSelect={(id) => {
            const typeMap: Record<string, string> = {
              digitai: "DIGITEVEN_ODD",
              unibet: "CALL_PUT",
              tradex: "DIGITMATCH_DIFF",
              optimax: "DIGITOVER_UNDER",
              accumulator: "CALL_PUT",
              autors: "ONETOUCH_NOTOUCH",
            }
            setActiveStrategy((prev) => {
              if (prev === id) return null  // deselect — don't change trade type
              if (typeMap[id]) setConfig((c) => ({ ...c, tradeType: typeMap[id] }))
              return id
            })
          }}
        />

        {/* 3. Symbol Advisor — visible when a strategy is selected */}
        <SymbolAdvisor
          activeStrategy={activeStrategy}
          currentSymbol={config.symbol}
          regime={prediction.marketRegime}
          pilotMode={pilotMode}
          onSymbolChange={(sym) => {
            // Resubscribe ticks on new symbol
            setConfig((c) => ({ ...c, symbol: sym }))
            const ws = getDerivWS()
            ws.subscribeTicks(sym)
            currentSymbolRef.current = sym
            // Reset tick history so indicators recalculate fresh
            ticksRef.current = []
            digitsRef.current = []
            setTicks([])
            setDigits([])
          }}
        />

        {/* 4. Trade Settings */}
        <TradeSettings
          config={config}
          onChange={(partial) => setConfig((c) => ({ ...c, ...partial }))}
          onBuy={handleBuy}
          onSell={handleSell}
          onClearHistory={handleClearHistory}
          isConnected={isConnected}
          isBuying={isBuying}
          isSelling={isSelling}
          onMultipliedBuy={handleMultipliedBuy}
          onMultipliedSell={handleMultipliedSell}
        />

        {/* 5. Trade History */}
        <TradeHistory
          trades={trades}
          netProfit={netProfit}
          currency={currency}
        />



        {/* 6. Prediction Hub */}
        {(() => {
          const done = trades.filter(t => t.result !== "pending")
          let ls = 0
          for (let i = done.length - 1; i >= 0; i--) {
            if (done[i].result === "loss") ls++; else break
          }
          return (
            <PredictionHub
              data={prediction}
              isConnected={isConnected}
              recentResults={recentResults}
              totalCycles={totalCycles}
              sessionWins={sessionWins}
              sessionLosses={sessionLosses}
              lossStreak={ls}
              signalSkipped={signalSkipped}
              tenWinMode={tenWinMode}
              tenWinCount={tenWinCount}
              onToggleTenWin={() => activateTenWinMode(!tenWinMode)}
              onSkipSignal={() => setSignalSkipped(true)}
              onUnskipSignal={() => setSignalSkipped(false)}
              onFireTrade={(dir) => {
                if (dir === "BUY") handleBuy()
                else handleSell()
              }}
            />
          )
        })()}

        {/* 7. Even / Odd Digit Chart */}
        <DigitChart
          digits={digits}
          ticks={ticks}
          symbol={config.symbol}
          isConnected={isConnected}
          stake={config.stake * config.stakeBoost}
          onTrade={(contractType, barrier) => {
            if (buyLockRef.current) return
            buyLockRef.current = true
            setIsBuying(true)

            // Map contract type to the right tradeType for duration lookup
            const tradeTypeKey =
              contractType === "DIGITEVEN" || contractType === "DIGITODD" ? "DIGITEVEN_ODD" :
              contractType === "DIGITMATCH" || contractType === "DIGITDIFF" ? "DIGITMATCH_DIFF" :
              contractType === "DIGITOVER" || contractType === "DIGITUNDER" ? "DIGITOVER_UNDER" :
              contractType === "CALL" || contractType === "PUT" ? "CALL_PUT" :
              "DIGITOVER_UNDER"

            // Only pass barrier for contracts that need it (Over/Under/Match/Differ with specific digit)
            const barrierVal = (barrier && barrier !== "") ? barrier : undefined

            const actualStake = config.stake * config.stakeBoost
            const ws = getDerivWS()
            const [duration, unit] = durationForType(tradeTypeKey)

            ws.buyFromWarmed({
              symbol: config.symbol,
              contractType,
              duration,
              durationUnit: unit,
              stake: actualStake,
              basis: "stake",
              ...(barrierVal ? { barrier: barrierVal } : {}),
            }).then((result) => {
              const bought = result as { contract_id: string; buy_price: number; payout: number }
              const confirmedId = String(bought.contract_id || Date.now())
              const newTrade: Trade = {
                id: confirmedId,
                time: Date.now(),
                symbol: config.symbol,
                contractType,
                direction: ["CALL","DIGITEVEN","DIGITMATCH","DIGITOVER"].includes(contractType) ? "CALL" : "PUT",
                stake: bought.buy_price ?? actualStake,
                payout: bought.payout ?? null,
                profit: null,
                result: "pending",
              }
              setTrades(prev => {
                const updated = [...prev, newTrade]
                tradesRef.current = updated
                return updated
              })
              ws.subscribeContract(confirmedId)
            }).catch(() => {
              // Trade failed — release lock so next click works
              tradeInFlightRef.current = false
            }).finally(() => {
              buyLockRef.current = false
              setIsBuying(false)
            })
          }}
        />

        {/* 8. Live Analysis */}
        <LiveAnalysis
          trades={trades}
          currency={currency}
          strategySignals={strategySignals}
          regime={prediction.marketRegime}
        />

        {/* Community banner */}
        <div
          className="rounded-xl p-4"
          style={{ background: "#0d1526", border: "1px solid #1e3a5f" }}
        >
          <p className="text-[10px] text-blue-400 font-bold uppercase tracking-widest mb-1">
            Blackbox AI Community
          </p>
          <p className="text-sm font-bold text-slate-200 mb-1">
            Ready to Transform Your Trading with Blackbox AI?
          </p>
          <p className="text-xs text-slate-400 mb-3">
            Join thousands of traders already profiting with Blackbox AI automation and a proven 85%+ success rate.
          </p>
          <a
            href="https://t.me/blackboxai"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold text-white transition-opacity hover:opacity-90"
            style={{ background: "#0088cc" }}
          >
            <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8l-1.68 7.92c-.12.56-.46.7-.94.44l-2.6-1.92-1.26 1.22c-.14.14-.26.26-.52.26l.18-2.62 4.76-4.3c.2-.18-.04-.28-.32-.1l-5.88 3.7-2.54-.8c-.54-.18-.56-.54.12-.8l9.92-3.82c.46-.16.86.1.76.82z" />
            </svg>
            Message on Telegram
          </a>
        </div>
      </div>
    </div>
  )
}
