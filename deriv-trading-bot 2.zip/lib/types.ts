export type ConnectionStatus = "offline" | "connecting" | "online"

export type TradeDirection = "rise" | "fall"

export type TradeResult = "win" | "loss" | "pending"

export interface Trade {
  id: string
  timestamp: number
  symbol: string
  direction: TradeDirection
  stake: number
  payout: number
  profit: number
  result: TradeResult
  strategy: string
  contractId?: string
}

export interface TradeSettings {
  symbol: string
  tradeType: string
  stake: number
  martingale: boolean
  takeProfit: number | null
  stopLoss: number | null
  stakeBoost: number
  autoTrading: boolean
}

export interface TickData {
  epoch: number
  quote: number
  id: string
}

export interface OHLCData {
  epoch: number
  open: number
  high: number
  low: number
  close: number
}

export type StrategyId = "digiai" | "unibet" | "tradex" | "optimax" | "accumulator" | "autors"

export interface Strategy {
  id: StrategyId
  name: string
  tag: string
  description: string
  enabled: boolean
}

export type PilotMode = "smart" | "conservative" | "balanced" | "aggressive" | "turbo"

export interface PilotModeConfig {
  id: PilotMode
  name: string
  agree: string
  conf: string
  cooldown: string
  description: string
}

export interface Indicators {
  rsi: number | null
  macd: { value: number; signal: number; histogram: number } | null
  bollinger: { upper: number; middle: number; lower: number } | null
  ema: number | null
  stoch: { k: number; d: number } | null
}

export interface DerivAccount {
  balance: number
  currency: string
  loginid: string
  email: string
}
