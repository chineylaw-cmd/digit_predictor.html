import type { TickData, DerivAccount } from "./types"

const DERIV_WS_URL = "wss://ws.derivws.com/websockets/v3?app_id=1089"

type MessageHandler = (data: unknown) => void

class DerivWebSocket {
  private ws: WebSocket | null = null
  private token: string = ""
  private handlers: Map<string, MessageHandler[]> = new Map()
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null
  private pingInterval: ReturnType<typeof setInterval> | null = null
  private pendingSubscriptions: string[] = []
  private activeContractSubs: Set<string> = new Set()
  private reconnectCallback: (() => void) | null = null

  // Pre-warmed proposal cache — keyed by a hash of the proposal params
  // so clicking Buy fires immediately with a pre-cached proposal ID
  private warmedProposals: Map<string, { id: string; price: number; expiresAt: number }> = new Map()
  // Track last warmed key to avoid re-warming on every tick with same params
  private lastWarmedKey = ""

  onReconnect(cb: () => void) {
    this.reconnectCallback = cb
  }

  connect(token: string): Promise<DerivAccount> {
    this.token = token
    return new Promise((resolve, reject) => {
      try {
        this.ws = new WebSocket(DERIV_WS_URL)

        this.ws.onopen = () => {
          this.startPing()
          this.send({ authorize: token })
        }

        this.ws.onmessage = (event) => {
          try {
            const data = JSON.parse(event.data)
            this.handleMessage(data, resolve, reject)
          } catch {
            // ignore parse errors
          }
        }

        this.ws.onerror = () => {
          reject(new Error("WebSocket connection failed"))
        }

        this.ws.onclose = () => {
          this.stopPing()
          // Invalidate warmed proposals — they were tied to the old connection
          this.warmedProposals.clear()
          this.lastWarmedKey = ""
          this.activeContractSubs.clear()
          // Auto-reconnect after 3s
          this.reconnectTimer = setTimeout(() => {
            if (this.token) {
              this.ws = null
              this.connect(this.token)
                .then(() => {
                  // Re-subscribe to ticks that were active before disconnect
                  // (pendingSubscriptions was populated when subscribeTicks was called on the old socket)
                  this.reconnectCallback?.()
                })
                .catch(() => {/* silent — next reconnect timer will retry */})
            }
          }, 3000)
        }
      } catch (err) {
        reject(err)
      }
    })
  }

  private handleMessage(
    data: Record<string, unknown>,
    resolve?: (account: DerivAccount) => void,
    reject?: (err: Error) => void,
  ) {
    // Always emit raw errors so in-flight promise handlers can clean themselves up
    if (data.error) {
      const errMsg = (data.error as Record<string, string>).message || "Unknown error"
      this.emit("error", data.error)
      // Also emit on the specific channel so proposal/buy handlers can unregister
      if (data.error && (data as Record<string,unknown>).msg_type === "proposal") {
        this.emit("proposal", data)
      }
      if (reject) reject(new Error(errMsg))
      return
    }

    if (data.msg_type === "authorize" && resolve) {
      const auth = data.authorize as Record<string, unknown>
      const account: DerivAccount = {
        balance: (auth.balance as number) || 0,
        currency: (auth.currency as string) || "USD",
        loginid: (auth.loginid as string) || "",
        email: (auth.email as string) || "",
      }
      this.emit("authorize", account)
      resolve(account)
      // Re-subscribe pending
      this.pendingSubscriptions.forEach((sym) => this.subscribeTicks(sym))
      this.pendingSubscriptions = []
      return
    }

    if (data.msg_type === "tick") {
      const tick = data.tick as Record<string, unknown>
      const tickData: TickData = {
        epoch: tick.epoch as number,
        quote: tick.quote as number,
        id: tick.id as string,
      }
      this.emit("tick", tickData)
      return
    }

    if (data.msg_type === "buy") {
      this.emit("buy", data.buy)
      return
    }

    if (data.msg_type === "proposal_open_contract") {
      const poc = data.proposal_open_contract as Record<string, unknown>
      if (!poc) return
      // Compute profit: prefer Deriv's own profit field, fallback to sell_price - buy_price
      if (poc.profit === undefined || poc.profit === null) {
        const buyP = typeof poc.buy_price === "number" ? poc.buy_price : 0
        const sellP = typeof poc.sell_price === "number" ? poc.sell_price : 0
        poc.profit = sellP - buyP
      }
      this.emit("contract_update", poc)
      // Unsubscribe once settled to avoid duplicate events
      if (poc.status && poc.status !== "open") {
        const subId = poc.id as string | undefined
        const cid = poc.contract_id as string | undefined
        if (subId) this.send({ forget: subId })
        if (cid) this.activeContractSubs.delete(cid)
      }
      return
    }

    if (data.msg_type === "balance") {
      this.emit("balance", data.balance)
      return
    }

    if (data.msg_type === "proposal") {
      this.emit("proposal", data.proposal)
      return
    }
  }

  subscribeTicks(symbol: string) {
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.send({ ticks: symbol, subscribe: 1 })
    } else {
      this.pendingSubscriptions.push(symbol)
    }
  }

  unsubscribeTicks(_symbol: string) {
    // forget_all: "ticks" cancels all tick subscriptions — correct behaviour
    // when switching symbols (we immediately re-subscribe to the new symbol after)
    this.send({ forget_all: "ticks" })
    // Also clear pending so the old symbol isn't re-queued on reconnect
    this.pendingSubscriptions = this.pendingSubscriptions.filter(s => s !== _symbol)
  }

  subscribeBalance() {
    this.send({ balance: 1, subscribe: 1 })
  }

  async buyContract(params: {
    symbol: string
    contractType: string
    duration: number
    durationUnit: string
    stake: number
    basis: string
    currency?: string
    barrier?: string
  }): Promise<Record<string, unknown>> {
    // ── Two-phase instant buy ───────────────────────────────────────────────────
    // Phase 1: send proposal and buy in the SAME tick — as soon as the proposal
    //          ID arrives we immediately send the buy without any extra await.
    // Phase 2: wait only for the buy confirmation (not the proposal round-trip).
    // This cuts one full network round-trip vs the old propose→wait→buy flow.
    return new Promise((resolve, reject) => {
      const reqId = Date.now()
      let settled = false

      // Timeout reduced to 8s — if Deriv hasn't confirmed in 8s, something is wrong
      const timer = setTimeout(() => {
        if (!settled) {
          settled = true
          this.off("proposal", proposalHandler)
          this.off("buy", buyHandler)
          reject(new Error("Trade timeout after 8s"))
        }
      }, 8000)

      const proposalHandler = (raw: unknown) => {
        if (settled) return
        const p = raw as Record<string, unknown>
        if (p.req_id !== undefined && p.req_id !== reqId) return
        if (!p || p.error) {
          settled = true
          clearTimeout(timer)
          this.off("proposal", proposalHandler)
          this.off("buy", buyHandler)
          reject(new Error((p?.error as Record<string, string>)?.message || "Proposal failed"))
          return
        }
        // Fire buy immediately — no extra await, no delay
        this.send({ buy: p.id as string, price: params.stake, req_id: reqId + 1 })
      }

      const buyHandler = (raw: unknown) => {
        if (settled) return
        const b = raw as Record<string, unknown>
        // Deriv buy responses don't always echo req_id — accept first valid buy event
        if (!b || (!b.contract_id && !b.buy_price)) return
        settled = true
        clearTimeout(timer)
        this.off("proposal", proposalHandler)
        this.off("buy", buyHandler)
        const contractId = b.contract_id as string
        if (contractId) this.subscribeContract(contractId)
        resolve(b)
      }

      this.on("proposal", proposalHandler)
      this.on("buy", buyHandler)

      // Send proposal immediately — the handler above fires the buy the instant
      // Deriv responds, with zero intentional delay on our side
      this.send({
        proposal: 1,
        amount: params.stake,
        basis: params.basis,
        contract_type: params.contractType,
        currency: params.currency ?? "USD",
        duration: params.duration,
        duration_unit: params.durationUnit,
        symbol: params.symbol,
        req_id: reqId,
        ...(params.barrier !== undefined ? { barrier: params.barrier } : {}),
      })
    })
  }

  // ── Pre-warm a proposal so the next buy fires in one hop ────────────────────
  // Call this as soon as a signal appears. The proposal ID is cached for 25s.
  // On click, buyFromWarmed() fires buy immediately using the cached ID.
  warmProposal(params: {
    symbol: string
    contractType: string
    duration: number
    durationUnit: string
    stake: number
    basis: string
    currency?: string
    barrier?: string
  }) {
    if (this.ws?.readyState !== WebSocket.OPEN) return
    const key = `${params.symbol}|${params.contractType}|${params.duration}${params.durationUnit}|${params.stake}|${params.barrier ?? ""}`
    // Skip if already fresh — avoid re-warming on every tick with the same params
    const existing = this.warmedProposals.get(key)
    if (existing && existing.expiresAt > Date.now()) return // already fresh
    // Skip if same key is already being fetched (prevents flood)
    if (this.lastWarmedKey === key) return
    this.lastWarmedKey = key

    const reqId = Date.now()
    const handler = (raw: unknown) => {
      if (!raw) { this.off("proposal", handler); return }
      const p = raw as Record<string, unknown>
      // Only handle the response that matches our exact req_id
      if (p.req_id !== reqId) return
      if (p.error) { this.off("proposal", handler); return }
      const proposalId = p.id as string
      if (!proposalId) { this.off("proposal", handler); return }
      this.warmedProposals.set(key, {
        id: proposalId,
        price: typeof p.ask_price === "number" ? p.ask_price : params.stake,
        expiresAt: Date.now() + 25_000,
      })
      // Reset so a re-warm can happen when the key changes next time
      this.lastWarmedKey = ""
      this.off("proposal", handler)
    }
    this.on("proposal", handler)
    this.send({
      proposal: 1,
      amount: params.stake,
      basis: params.basis,
      contract_type: params.contractType,
      currency: params.currency ?? "USD",
      duration: params.duration,
      duration_unit: params.durationUnit,
      symbol: params.symbol,
      req_id: reqId,
      ...(params.barrier !== undefined ? { barrier: params.barrier } : {}),
    })
  }

  // ── Buy using pre-warmed proposal (single network hop) ──────────────────────
  // Falls back to full proposal→buy flow if no warm cache exists.
  async buyFromWarmed(params: {
    symbol: string
    contractType: string
    duration: number
    durationUnit: string
    stake: number
    basis: string
    currency?: string
    barrier?: string
  }): Promise<Record<string, unknown>> {
    const key = `${params.symbol}|${params.contractType}|${params.duration}${params.durationUnit}|${params.stake}|${params.barrier ?? ""}`
    const warmed = this.warmedProposals.get(key)

    if (warmed && warmed.expiresAt > Date.now()) {
      // Cache hit — fire buy immediately, no proposal round-trip needed
      this.warmedProposals.delete(key) // consume it (one-use)
      return new Promise((resolve, reject) => {
        let settled = false
        const timer = setTimeout(() => {
          if (!settled) {
            settled = true
            this.off("buy", buyHandler)
            // Proposal may have expired — fall back to full flow
            this.buyContract(params).then(resolve).catch(reject)
          }
        }, 4000)
        // NOTE: Deriv's buy response does NOT reliably echo req_id.
        // Accept the FIRST buy event that arrives after we send — this is safe
        // because we hold the in-flight lock so no concurrent buys can fire.
        const buyHandler = (raw: unknown) => {
          if (settled) return
          const b = raw as Record<string, unknown>
          // Deriv sends buy confirmation as the direct buy object (contract_id present)
          if (!b || (!b.contract_id && !b.buy_price)) return // not a valid buy response
          settled = true
          clearTimeout(timer)
          this.off("buy", buyHandler)
          const contractId = b.contract_id as string
          if (contractId) this.subscribeContract(contractId)
          resolve(b)
        }
        this.on("buy", buyHandler)
        // Single WebSocket send — instant, one hop
        this.send({ buy: warmed.id, price: params.stake })
      })
    }

    // Cache miss — fall back to full two-phase proposal→buy flow
    return this.buyContract(params)
  }

  subscribeContract(contractId: string) {
    if (this.activeContractSubs.has(contractId)) return
    this.activeContractSubs.add(contractId)
    this.send({ proposal_open_contract: 1, contract_id: contractId, subscribe: 1 })
  }

  on(event: string, handler: MessageHandler) {
    if (!this.handlers.has(event)) this.handlers.set(event, [])
    this.handlers.get(event)!.push(handler)
  }

  off(event: string, handler: MessageHandler) {
    const h = this.handlers.get(event)
    if (h) {
      this.handlers.set(event, h.filter((fn) => fn !== handler))
    }
  }

  // Remove ALL handlers for an event — used before re-registering on reconnect
  // to prevent duplicate handlers stacking up after disconnect/reconnect cycles.
  offAll(event: string) {
    this.handlers.delete(event)
  }

  private emit(event: string, data: unknown) {
    this.handlers.get(event)?.forEach((h) => h(data))
  }

  private send(data: Record<string, unknown>) {
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(data))
    }
  }

  private startPing() {
    this.pingInterval = setInterval(() => {
      this.send({ ping: 1 })
    }, 30000)
  }

  private stopPing() {
    if (this.pingInterval) clearInterval(this.pingInterval)
  }

  disconnect() {
    this.stopPing()
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer)
    this.reconnectCallback = null
    this.activeContractSubs.clear()
    this.pendingSubscriptions = []
    if (this.ws) {
      this.ws.onclose = null // prevent auto-reconnect
      this.ws.close()
      this.ws = null
    }
  }

  isConnected() {
    return this.ws?.readyState === WebSocket.OPEN
  }
}

// Singleton
let instance: DerivWebSocket | null = null
export function getDerivWS(): DerivWebSocket {
  if (!instance) instance = new DerivWebSocket()
  return instance
}

export function resetDerivWS() {
  instance?.disconnect()
  instance = null
}
