// ─── Core Indicator Engine ──────────────────────────────────────────────────

export function calcEMA(prices: number[], period: number): number[] {
  if (prices.length < period) return []
  const k = 2 / (period + 1)
  const emas: number[] = []
  let ema = prices.slice(0, period).reduce((a, b) => a + b, 0) / period
  emas.push(ema)
  for (let i = period; i < prices.length; i++) {
    ema = prices[i] * k + ema * (1 - k)
    emas.push(ema)
  }
  return emas
}

export function calcSMA(prices: number[], period: number): number[] {
  const result: number[] = []
  for (let i = period - 1; i < prices.length; i++) {
    const slice = prices.slice(i - period + 1, i + 1)
    result.push(slice.reduce((a, b) => a + b, 0) / period)
  }
  return result
}

export function calcRSI(prices: number[], period = 14): number {
  if (prices.length < period + 1) return 50
  let gains = 0, losses = 0
  for (let i = prices.length - period; i < prices.length; i++) {
    const diff = prices[i] - prices[i - 1]
    if (diff > 0) gains += diff; else losses -= diff
  }
  const avgGain = gains / period
  const avgLoss = losses / period
  if (avgLoss === 0) return 100
  return 100 - 100 / (1 + avgGain / avgLoss)
}

export function calcMACD(prices: number[]): { macd: number; signal: number; histogram: number } {
  if (prices.length < 26) return { macd: 0, signal: 0, histogram: 0 }
  const ema12 = calcEMA(prices, 12)
  const ema26 = calcEMA(prices, 26)
  const macdLine: number[] = []
  const len = Math.min(ema12.length, ema26.length)
  for (let i = 0; i < len; i++) {
    macdLine.push(ema12[ema12.length - len + i] - ema26[ema26.length - len + i])
  }
  const signalArr = calcEMA(macdLine, 9)
  const macd = macdLine[macdLine.length - 1] ?? 0
  const signal = signalArr[signalArr.length - 1] ?? 0
  return { macd, signal, histogram: macd - signal }
}

export function calcBollingerBands(prices: number[], period = 20, stdDev = 2): {
  upper: number; middle: number; lower: number; bandwidth: number; percentB: number
} {
  if (prices.length < period) {
    const p = prices[prices.length - 1] ?? 0
    return { upper: p + 0.1, middle: p, lower: p - 0.1, bandwidth: 0, percentB: 50 }
  }
  const slice = prices.slice(-period)
  const mean = slice.reduce((a, b) => a + b, 0) / period
  const variance = slice.reduce((sum, p) => sum + Math.pow(p - mean, 2), 0) / period
  const std = Math.sqrt(variance)
  const upper = mean + stdDev * std
  const lower = mean - stdDev * std
  const current = prices[prices.length - 1]
  const bandwidth = std > 0 ? (upper - lower) / mean : 0
  const percentB = std > 0 ? ((current - lower) / (upper - lower)) * 100 : 50
  return { upper, middle: mean, lower, bandwidth, percentB }
}

export function calcStochastic(prices: number[], period = 14): { k: number; d: number } {
  if (prices.length < period) return { k: 50, d: 50 }
  const kValues: number[] = []
  const start = Math.max(0, prices.length - period - 3)
  for (let i = start; i < prices.length; i++) {
    if (i < period - 1) continue
    const s = prices.slice(i - period + 1, i + 1)
    const lo = Math.min(...s)
    const hi = Math.max(...s)
    kValues.push(hi === lo ? 50 : ((prices[i] - lo) / (hi - lo)) * 100)
  }
  const k = kValues[kValues.length - 1] ?? 50
  const d = kValues.length >= 3
    ? kValues.slice(-3).reduce((a, b) => a + b, 0) / 3
    : k
  return { k, d }
}

// Average True Range — measures volatility
export function calcATR(prices: number[], period = 14): number {
  if (prices.length < period + 1) return 0
  const trs: number[] = []
  for (let i = 1; i < prices.length; i++) {
    trs.push(Math.abs(prices[i] - prices[i - 1]))
  }
  const recent = trs.slice(-period)
  return recent.reduce((a, b) => a + b, 0) / period
}

// Commodity Channel Index
export function calcCCI(prices: number[], period = 20): number {
  if (prices.length < period) return 0
  const slice = prices.slice(-period)
  const mean = slice.reduce((a, b) => a + b, 0) / period
  const meanDev = slice.reduce((sum, p) => sum + Math.abs(p - mean), 0) / period
  if (meanDev === 0) return 0
  return (prices[prices.length - 1] - mean) / (0.015 * meanDev)
}

// Williams %R
export function calcWilliamsR(prices: number[], period = 14): number {
  if (prices.length < period) return -50
  const slice = prices.slice(-period)
  const highest = Math.max(...slice)
  const lowest = Math.min(...slice)
  const current = prices[prices.length - 1]
  if (highest === lowest) return -50
  return ((highest - current) / (highest - lowest)) * -100
}

// Consecutive direction streak
export function calcStreak(prices: number[]): { direction: "up" | "down" | "flat"; count: number } {
  if (prices.length < 2) return { direction: "flat", count: 0 }
  const last = prices[prices.length - 1]
  const prev = prices[prices.length - 2]
  const dir = last > prev ? "up" : last < prev ? "down" : "flat"
  let count = 1
  for (let i = prices.length - 2; i >= 1; i--) {
    const d = prices[i] > prices[i - 1] ? "up" : prices[i] < prices[i - 1] ? "down" : "flat"
    if (d === dir) count++; else break
  }
  return { direction: dir, count }
}

// Price momentum over N ticks
export function calcMomentum(prices: number[], period = 10): number {
  if (prices.length < period + 1) return 0
  return prices[prices.length - 1] - prices[prices.length - 1 - period]
}

// Detect support/resistance bounce
export function detectBounce(prices: number[]): { isBounce: boolean; direction: "up" | "down" | null } {
  if (prices.length < 20) return { isBounce: false, direction: null }
  const bb = calcBollingerBands(prices, 20, 2)
  const current = prices[prices.length - 1]
  const prev = prices[prices.length - 2]
  if (prev <= bb.lower && current > bb.lower) return { isBounce: true, direction: "up" }
  if (prev >= bb.upper && current < bb.upper) return { isBounce: true, direction: "down" }
  return { isBounce: false, direction: null }
}

// ─── Digit helpers ──────────────────────────────────────────────────────────

export function getLastDigit(price: number): number {
  const str = price.toFixed(2)
  return parseInt(str[str.length - 1])
}

export function analyzeDigitPattern(digits: number[]): {
  evenCount: number; oddCount: number; overFiveCount: number; underFiveCount: number
  matchCount: number; differCount: number; lastDigit: number
  consecutiveEven: number; consecutiveOdd: number; consecutiveOver: number; consecutiveUnder: number
} {
  if (digits.length === 0) {
    return { evenCount: 0, oddCount: 0, overFiveCount: 0, underFiveCount: 0,
      matchCount: 0, differCount: 0, lastDigit: -1,
      consecutiveEven: 0, consecutiveOdd: 0, consecutiveOver: 0, consecutiveUnder: 0 }
  }
  let evenCount = 0, oddCount = 0, overFiveCount = 0, underFiveCount = 0
  let matchCount = 0, differCount = 0
  for (let i = 0; i < digits.length; i++) {
    const d = digits[i]
    if (d % 2 === 0) evenCount++; else oddCount++
    if (d >= 5) overFiveCount++; else underFiveCount++
    if (i > 0 && d === digits[i - 1]) matchCount++
    else if (i > 0) differCount++
  }
  // Count consecutive streaks from the end
  let consecutiveEven = 0, consecutiveOdd = 0, consecutiveOver = 0, consecutiveUnder = 0
  for (let i = digits.length - 1; i >= 0; i--) {
    if (digits[i] % 2 === 0) consecutiveEven++; else break
  }
  for (let i = digits.length - 1; i >= 0; i--) {
    if (digits[i] % 2 !== 0) consecutiveOdd++; else break
  }
  for (let i = digits.length - 1; i >= 0; i--) {
    if (digits[i] >= 5) consecutiveOver++; else break
  }
  for (let i = digits.length - 1; i >= 0; i--) {
    if (digits[i] < 5) consecutiveUnder++; else break
  }
  return { evenCount, oddCount, overFiveCount, underFiveCount, matchCount, differCount,
    lastDigit: digits[digits.length - 1],
    consecutiveEven, consecutiveOdd, consecutiveOver, consecutiveUnder }
}

// ─── Market regime ──────────────────────────────────────────────────────────

export function detectMarketRegime(prices: number[]): "trending" | "ranging" | "volatile" {
  if (prices.length < 20) return "ranging"
  const bb = calcBollingerBands(prices, 20, 2)
  const rsi = calcRSI(prices, 14)
  const atr = calcATR(prices, 14)
  const avgPrice = prices.slice(-14).reduce((a, b) => a + b, 0) / 14
  const atrPct = avgPrice > 0 ? atr / avgPrice : 0
  if (atrPct > 0.002 && (rsi > 65 || rsi < 35)) return "trending"
  if (bb.bandwidth > 0.012 || atrPct > 0.003) return "volatile"
  return "ranging"
}

// ─── Signal interface ───────────────────────────────────────────────────────

export interface Signal {
  direction: "CALL" | "PUT" | "WAIT"
  confidence: number
  reason: string
}

export interface IndicatorVote {
  name: string
  signal: "CALL" | "PUT" | "NEUTRAL"
  value: string
  weight: number
}

export interface FullSignal {
  direction: "CALL" | "PUT" | "WAIT"
  confidence: number
  reason: string
  votes: IndicatorVote[]
  callScore: number
  putScore: number
  totalWeight: number
  shouldTrade: boolean
  // Individual raw values
  rsi: number
  macd: { macd: number; signal: number; histogram: number }
  bb: { upper: number; middle: number; lower: number; bandwidth: number; percentB: number }
  stoch: { k: number; d: number }
  cci: number
  williamsR: number
  atr: number
  streak: { direction: "up" | "down" | "flat"; count: number }
  momentum: number
  regime: "trending" | "ranging" | "volatile"
  familyScore?: {
    momentum: "CALL" | "PUT" | "NEUTRAL"
    trend: "CALL" | "PUT" | "NEUTRAL"
    volatility: "CALL" | "PUT" | "NEUTRAL"
    flow: "CALL" | "PUT" | "NEUTRAL"
    agreedFamilies: number
    totalFamilies: number
  }
  signalStrength: number   // 0-100 composite: confidence + family + persistence proxy
  supertrend?: { direction: "CALL" | "PUT"; line: number; strength: number }
  heikinAshi?: { direction: "CALL" | "PUT" | "NEUTRAL"; consecutive: number }
  roc?: number
  signalReadiness: string  // human-readable: what is missing before a trade is valid
  priceActionOk: boolean   // true = 3+ consecutive closes confirm direction
  confluenceScore: number  // 0-4: how many of RSI/MACD/EMA/ST agree
}

// ─── Supertrend indicator ────────────────────────────────────────────────────
// Uses ATR-based bands to determine trend direction.
// Returns "CALL" when price is above the supertrend line, "PUT" when below.
export function calcSupertrend(prices: number[], period = 10, multiplier = 3): {
  direction: "CALL" | "PUT"
  line: number
  strength: number   // 0-100: how far price is from the line as % of ATR
} {
  if (prices.length < period + 2) {
    return { direction: "CALL", line: prices[prices.length - 1] ?? 0, strength: 0 }
  }
  const atr = calcATR(prices, period)
  const hl2 = prices.slice(-period).reduce((a, b) => a + b, 0) / period  // approximation
  const upperBand = hl2 + multiplier * atr
  const lowerBand = hl2 - multiplier * atr
  const price = prices[prices.length - 1]
  const direction: "CALL" | "PUT" = price > hl2 ? "CALL" : "PUT"
  const line = direction === "CALL" ? lowerBand : upperBand
  const dist = Math.abs(price - line)
  const strength = atr > 0 ? Math.min(Math.round((dist / atr) * 50), 100) : 0
  return { direction, line, strength }
}

// ─── Heikin-Ashi candle direction (using 5-tick bars) ────────────────────────
// Heikin-Ashi smooths candles to filter noise — consecutive same-color HA bars = strong trend.
export function calcHeikinAshi(prices: number[]): {
  direction: "CALL" | "PUT" | "NEUTRAL"
  consecutive: number   // how many consecutive HA bars in same direction
} {
  if (prices.length < 10) return { direction: "NEUTRAL", consecutive: 0 }
  // Build 5-tick HA bars
  const barSize = 5
  const bars: { open: number; close: number; high: number; low: number }[] = []
  for (let i = 0; i + barSize <= prices.length; i += barSize) {
    const slice = prices.slice(i, i + barSize)
    const open  = slice[0]
    const close = slice[slice.length - 1]
    const high  = Math.max(...slice)
    const low   = Math.min(...slice)
    bars.push({ open, close, high, low })
  }
  if (bars.length < 2) return { direction: "NEUTRAL", consecutive: 0 }

  // Build HA bars
  const ha: typeof bars = []
  ha.push(bars[0])
  for (let i = 1; i < bars.length; i++) {
    const prev = ha[i - 1]
    const cur  = bars[i]
    const haClose = (cur.open + cur.close + cur.high + cur.low) / 4
    const haOpen  = (prev.open + prev.close) / 2
    ha.push({ open: haOpen, close: haClose, high: Math.max(cur.high, haOpen, haClose), low: Math.min(cur.low, haOpen, haClose) })
  }

  const last = ha[ha.length - 1]
  const lastDir: "CALL" | "PUT" = last.close >= last.open ? "CALL" : "PUT"
  let consecutive = 1
  for (let i = ha.length - 2; i >= 0; i--) {
    const d: "CALL" | "PUT" = ha[i].close >= ha[i].open ? "CALL" : "PUT"
    if (d === lastDir) consecutive++; else break
  }
  return { direction: lastDir, consecutive }
}

// ─── Price rate-of-change (ROC) ───────────────────────────────────────────────
export function calcROC(prices: number[], period = 12): number {
  if (prices.length < period + 1) return 0
  const current = prices[prices.length - 1]
  const past    = prices[prices.length - 1 - period]
  return past !== 0 ? ((current - past) / past) * 100 : 0
}

// ─── Adaptive RSI thresholds based on volatility regime ──────────────────────
// In a volatile market, widen RSI bands to avoid false signals
export function adaptiveRSIThresholds(regime: "trending" | "ranging" | "volatile"): { low: number; high: number } {
  if (regime === "volatile") return { low: 25, high: 75 }
  if (regime === "trending") return { low: 38, high: 62 }
  return { low: 32, high: 68 }  // ranging — standard
}

// ─── VWAP approximation (tick-based, no volume) ─────────────────────────────
// Uses a session-window weighted average; resets every 100 ticks to simulate daily VWAP
export function calcVWAP(prices: number[], window = 60): number {
  if (prices.length < 2) return prices[0] ?? 0
  const slice = prices.slice(-window)
  // Weight by index position (more recent = higher weight) to approximate volume weighting
  let sumPW = 0, sumW = 0
  for (let i = 0; i < slice.length; i++) {
    const w = i + 1
    sumPW += slice[i] * w
    sumW  += w
  }
  return sumW > 0 ? sumPW / sumW : slice[slice.length - 1]
}

// ─── Double-top / double-bottom detector ─────────────────────────────────────
export function detectDoubleFormation(prices: number[]): "double_top" | "double_bottom" | "none" {
  if (prices.length < 30) return "none"
  const recent = prices.slice(-30)
  const mid = Math.floor(recent.length / 2)

  // Find local high/low in first half and second half
  const firstHalf  = recent.slice(0, mid)
  const secondHalf = recent.slice(mid)

  const high1 = Math.max(...firstHalf)
  const high2 = Math.max(...secondHalf)
  const low1  = Math.min(...firstHalf)
  const low2  = Math.min(...secondHalf)

  const priceMean = recent.reduce((a, b) => a + b, 0) / recent.length
  const tolerance = priceMean * 0.0008  // 0.08% tolerance

  // Double top: two similar peaks with a valley in between
  if (Math.abs(high1 - high2) < tolerance && high1 > priceMean) return "double_top"
  // Double bottom: two similar troughs with a peak in between
  if (Math.abs(low1 - low2) < tolerance && low1 < priceMean)    return "double_bottom"

  return "none"
}

// ─── Keltner Channel ────────────────────────────────────────────────────────
export function calcKeltnerChannel(prices: number[], period = 20, multiplier = 2): {
  upper: number; middle: number; lower: number; percentK: number
} {
  if (prices.length < period) {
    const p = prices[prices.length - 1] ?? 0
    return { upper: p + 0.1, middle: p, lower: p - 0.1, percentK: 50 }
  }
  const emas = calcEMA(prices, period)
  const middle = emas[emas.length - 1] ?? 0
  const atr = calcATR(prices, period)
  const upper = middle + multiplier * atr
  const lower = middle - multiplier * atr
  const current = prices[prices.length - 1]
  const range = upper - lower
  const percentK = range > 0 ? ((current - lower) / range) * 100 : 50
  return { upper, middle, lower, percentK }
}

// ─── Engulfing candle pattern (using tick bars) ──────────────────────────────
export function detectEngulfing(prices: number[]): "bullish" | "bearish" | "none" {
  if (prices.length < 6) return "none"
  // Use 3-tick mini-bars
  const tail = prices.slice(-6)
  const bar1Open = tail[0], bar1Close = tail[2]
  const bar2Open = tail[3], bar2Close = tail[5]
  const bar1Body = Math.abs(bar1Close - bar1Open)
  const bar2Body = Math.abs(bar2Close - bar2Open)
  // Bullish engulfing: bar1 bearish, bar2 bullish and larger
  if (bar1Close < bar1Open && bar2Close > bar2Open && bar2Body > bar1Body * 1.2
      && bar2Open <= bar1Close && bar2Close >= bar1Open) return "bullish"
  // Bearish engulfing: bar1 bullish, bar2 bearish and larger
  if (bar1Close > bar1Open && bar2Close < bar2Open && bar2Body > bar1Body * 1.2
      && bar2Open >= bar1Close && bar2Close <= bar1Open) return "bearish"
  return "none"
}

// ─── Signal family scoring ───────────────────────────────────────────────────
// Returns how many indicator families agree on the same direction
// Families: momentum (RSI/CCI/WR/STOCH), trend (EMA/MACD/MOM), volatility (BB/Keltner/ATR), flow (PRESS/DIV/BOUNCE)
export function calcFamilyScore(votes: IndicatorVote[]): {
  momentum: "CALL" | "PUT" | "NEUTRAL"
  trend: "CALL" | "PUT" | "NEUTRAL"
  volatility: "CALL" | "PUT" | "NEUTRAL"
  flow: "CALL" | "PUT" | "NEUTRAL"
  agreedFamilies: number
  totalFamilies: number
} {
  const familyMap: Record<string, string[]> = {
    momentum:   ["RSI", "CCI", "W%R", "STOCH", "MTF", "ROC"],
    trend:      ["EMA", "MACD", "MOM", "VWAP", "ST", "HA"],
    volatility: ["BB", "KC", "ATR", "ENG"],
    flow:       ["PRESS", "DIV", "BOUNCE", "DBL"],
  }
  const score = (names: string[], dir: "CALL" | "PUT") =>
    votes.filter(v => names.includes(v.name) && v.signal === dir)
         .reduce((s, v) => s + v.weight, 0)

  function familyDir(names: string[]): "CALL" | "PUT" | "NEUTRAL" {
    const c = score(names, "CALL"), p = score(names, "PUT")
    if (c > 0 && c >= p * 1.2) return "CALL"
    if (p > 0 && p >= c * 1.2) return "PUT"
    return "NEUTRAL"
  }

  const momentum   = familyDir(familyMap.momentum)
  const trend      = familyDir(familyMap.trend)
  const volatility = familyDir(familyMap.volatility)
  const flow       = familyDir(familyMap.flow)

  const dirs = [momentum, trend, volatility, flow]
  const winning = ["CALL", "PUT"].map(d => dirs.filter(x => x === d).length)
  const dominantDir = winning[0] >= winning[1] ? "CALL" : "PUT"
  const agreedFamilies = dirs.filter(x => x === dominantDir).length

  return { momentum, trend, volatility, flow, agreedFamilies, totalFamilies: 4 }
}

// ─── Best-time filter: penalise first few ticks after a big price move ───────
export function isCalmedDown(prices: number[], atrMultiplier = 1.8): boolean {
  if (prices.length < 20) return false
  const atrNow = calcATR(prices, 5)     // very recent volatility
  const atrBase = calcATR(prices, 20)   // baseline
  return atrBase === 0 || atrNow <= atrBase * atrMultiplier
}

// ─── RSI Divergence detector ────────────────────────────────────────────────
function detectRSIDivergence(prices: number[]): "bullish" | "bearish" | "none" {
  if (prices.length < 30) return "none"
  const rsiNow = calcRSI(prices, 14)
  const rsiPrev = calcRSI(prices.slice(0, -5), 14)
  const pNow = prices[prices.length - 1]
  const pPrev = prices[prices.length - 6]
  // Bullish divergence: price makes lower low but RSI makes higher low
  if (pNow < pPrev && rsiNow > rsiPrev && rsiNow < 45) return "bullish"
  // Bearish divergence: price makes higher high but RSI makes lower high
  if (pNow > pPrev && rsiNow < rsiPrev && rsiNow > 55) return "bearish"
  return "none"
}

// ─── Volume pressure proxy via tick acceleration ─────────────────────────────
function calcTickPressure(prices: number[]): { buyPressure: number; sellPressure: number; ratio: number } {
  if (prices.length < 20) return { buyPressure: 50, sellPressure: 50, ratio: 1 }
  const recent = prices.slice(-20)
  let buyTicks = 0, sellTicks = 0
  for (let i = 1; i < recent.length; i++) {
    if (recent[i] > recent[i - 1]) buyTicks++
    else if (recent[i] < recent[i - 1]) sellTicks++
  }
  const total = buyTicks + sellTicks || 1
  return {
    buyPressure: (buyTicks / total) * 100,
    sellPressure: (sellTicks / total) * 100,
    ratio: buyTicks / (sellTicks || 1),
  }
}

// ─── Multi-timeframe RSI confluence ──────────────────────────────────────────
function multiTimeframeRSI(prices: number[]): { fast: number; medium: number; slow: number } {
  return {
    fast: calcRSI(prices, 7),
    medium: calcRSI(prices, 14),
    slow: calcRSI(prices, 21),
  }
}

// ─── Adaptive confidence adjustment based on regime ──────────────────────────
function adaptConfidenceForRegime(
  baseConf: number,
  regime: "trending" | "ranging" | "volatile",
  tradeType: string,
): number {
  if (regime === "trending" && tradeType === "CALL_PUT") return Math.min(baseConf + 5, 95)
  if (regime === "ranging" && (tradeType === "DIGITEVEN_ODD" || tradeType === "DIGITMATCH_DIFF" || tradeType === "DIGITOVER_UNDER")) return Math.min(baseConf + 5, 95)
  if (regime === "volatile") return Math.max(baseConf - 8, 10)
  return baseConf
}

// ─── Master signal aggregator (upgraded — 12 weighted indicators) ──────────

export function getFullSignal(prices: number[], tradeType: string, digits: number[]): FullSignal {
  const EMPTY: FullSignal = {
    direction: "WAIT", confidence: 0, reason: "Collecting data...",
    votes: [], callScore: 0, putScore: 0, totalWeight: 0, shouldTrade: false,
    rsi: 50, macd: { macd: 0, signal: 0, histogram: 0 },
    bb: { upper: 0, middle: 0, lower: 0, bandwidth: 0, percentB: 50 },
    stoch: { k: 50, d: 50 }, cci: 0, williamsR: -50, atr: 0,
    streak: { direction: "flat", count: 0 }, momentum: 0, regime: "ranging",
    signalStrength: 0, signalReadiness: "Collecting ticks...", priceActionOk: false, confluenceScore: 0,
  }
  if (prices.length < 60) return EMPTY

  const rsi = calcRSI(prices, 14)
  const macd = calcMACD(prices)
  const bb = calcBollingerBands(prices, 20, 2)
  const stoch = calcStochastic(prices, 14)
  const cci = calcCCI(prices, 20)
  const wR = calcWilliamsR(prices, 14)
  const atr = calcATR(prices, 14)
  const streak = calcStreak(prices)
  const momentum = calcMomentum(prices, 10)
  const regime = detectMarketRegime(prices)
  const bounce = detectBounce(prices)
  const ema8 = calcEMA(prices, 8)
  const ema21 = calcEMA(prices, 21)
  const ema50 = calcEMA(prices, 50)
  const ema8v = ema8[ema8.length - 1] ?? 0
  const ema21v = ema21[ema21.length - 1] ?? 0
  const ema50v = ema50[ema50.length - 1] ?? 0
  const price = prices[prices.length - 1]
  const divergence = detectRSIDivergence(prices)
  const pressure = calcTickPressure(prices)
  const mtRSI = multiTimeframeRSI(prices)
  const atr28 = calcATR(prices, 28)
  const prevMacd = calcMACD(prices.slice(0, -1))
  const keltner = calcKeltnerChannel(prices, 20, 2)
  const engulfing = detectEngulfing(prices)
  const calmed = isCalmedDown(prices)
  const vwap = calcVWAP(prices, 60)
  const doubleForm = detectDoubleFormation(prices)
  const supertrend = calcSupertrend(prices, 10, 3)
  const heikinAshi = calcHeikinAshi(prices)
  const roc = calcROC(prices, 12)
  const rsiThresh = adaptiveRSIThresholds(regime)

  const votes: IndicatorVote[] = []

  if (tradeType === "CALL_PUT" || tradeType === "ONETOUCH_NOTOUCH") {
    // 1. RSI with adaptive thresholds per regime (weight 18)
    if (rsi < rsiThresh.low) votes.push({ name: "RSI", signal: "CALL", value: rsi.toFixed(1), weight: 18 })
    else if (rsi > rsiThresh.high) votes.push({ name: "RSI", signal: "PUT", value: rsi.toFixed(1), weight: 18 })
    else votes.push({ name: "RSI", signal: "NEUTRAL", value: rsi.toFixed(1), weight: 0 })

    // 2. MACD histogram + crossover confirmation (weight 16)
    const macdCrossingUp = macd.histogram > 0 && prevMacd.histogram <= 0
    const macdCrossingDn = macd.histogram < 0 && prevMacd.histogram >= 0
    if (macd.histogram > 0 && macd.macd > macd.signal)
      votes.push({ name: "MACD", signal: "CALL", value: (macdCrossingUp ? "X+" : "+") + macd.histogram.toFixed(4), weight: macdCrossingUp ? 20 : 16 })
    else if (macd.histogram < 0 && macd.macd < macd.signal)
      votes.push({ name: "MACD", signal: "PUT", value: (macdCrossingDn ? "X-" : "") + macd.histogram.toFixed(4), weight: macdCrossingDn ? 20 : 16 })
    else votes.push({ name: "MACD", signal: "NEUTRAL", value: macd.histogram.toFixed(4), weight: 0 })

    // 3. Bollinger Band squeeze/breakout (weight 14)
    if (price < bb.lower) votes.push({ name: "BB", signal: "CALL", value: `${bb.percentB.toFixed(0)}%B`, weight: 14 })
    else if (price > bb.upper) votes.push({ name: "BB", signal: "PUT", value: `${bb.percentB.toFixed(0)}%B`, weight: 14 })
    else votes.push({ name: "BB", signal: "NEUTRAL", value: `${bb.percentB.toFixed(0)}%B`, weight: 0 })

    // 4. EMA alignment (8 > 21 > 50 = strong trend, weight 14)
    if (ema8v > ema21v && ema21v > ema50v)
      votes.push({ name: "EMA", signal: "CALL", value: "8>21>50", weight: 14 })
    else if (ema8v < ema21v && ema21v < ema50v)
      votes.push({ name: "EMA", signal: "PUT", value: "8<21<50", weight: 14 })
    else if (ema8v > ema21v)
      votes.push({ name: "EMA", signal: "CALL", value: "8>21", weight: 8 })
    else
      votes.push({ name: "EMA", signal: "PUT", value: "8<21", weight: 8 })

    // 5. Stochastic with K/D cross (weight 12)
    if (stoch.k < 22 && stoch.k > stoch.d) votes.push({ name: "STOCH", signal: "CALL", value: `K${stoch.k.toFixed(0)}`, weight: 12 })
    else if (stoch.k > 78 && stoch.k < stoch.d) votes.push({ name: "STOCH", signal: "PUT", value: `K${stoch.k.toFixed(0)}`, weight: 12 })
    else if (stoch.k < 35) votes.push({ name: "STOCH", signal: "CALL", value: `K${stoch.k.toFixed(0)}`, weight: 6 })
    else if (stoch.k > 65) votes.push({ name: "STOCH", signal: "PUT", value: `K${stoch.k.toFixed(0)}`, weight: 6 })
    else votes.push({ name: "STOCH", signal: "NEUTRAL", value: stoch.k.toFixed(1), weight: 0 })

    // 6. CCI (weight 10)
    if (cci < -120) votes.push({ name: "CCI", signal: "CALL", value: cci.toFixed(0), weight: 10 })
    else if (cci > 120) votes.push({ name: "CCI", signal: "PUT", value: cci.toFixed(0), weight: 10 })
    else votes.push({ name: "CCI", signal: "NEUTRAL", value: cci.toFixed(0), weight: 0 })

    // 7. Williams %R (weight 8)
    if (wR < -82) votes.push({ name: "W%R", signal: "CALL", value: wR.toFixed(0), weight: 8 })
    else if (wR > -18) votes.push({ name: "W%R", signal: "PUT", value: wR.toFixed(0), weight: 8 })
    else votes.push({ name: "W%R", signal: "NEUTRAL", value: wR.toFixed(0), weight: 0 })

    // 8. Multi-timeframe RSI confluence (weight 12) — all 3 timeframes must agree
    const mtBull = mtRSI.fast < 40 && mtRSI.medium < 50 && mtRSI.slow < 55
    const mtBear = mtRSI.fast > 60 && mtRSI.medium > 50 && mtRSI.slow > 45
    if (mtBull) votes.push({ name: "MTF", signal: "CALL", value: `${mtRSI.fast.toFixed(0)}/${mtRSI.medium.toFixed(0)}/${mtRSI.slow.toFixed(0)}`, weight: 12 })
    else if (mtBear) votes.push({ name: "MTF", signal: "PUT", value: `${mtRSI.fast.toFixed(0)}/${mtRSI.medium.toFixed(0)}/${mtRSI.slow.toFixed(0)}`, weight: 12 })
    else votes.push({ name: "MTF", signal: "NEUTRAL", value: `${mtRSI.fast.toFixed(0)}/${mtRSI.medium.toFixed(0)}/${mtRSI.slow.toFixed(0)}`, weight: 0 })

    // 9. Tick pressure (volume proxy, weight 10)
    if (pressure.buyPressure > 62) votes.push({ name: "PRESS", signal: "CALL", value: `${pressure.buyPressure.toFixed(0)}%↑`, weight: 10 })
    else if (pressure.sellPressure > 62) votes.push({ name: "PRESS", signal: "PUT", value: `${pressure.sellPressure.toFixed(0)}%↓`, weight: 10 })
    else votes.push({ name: "PRESS", signal: "NEUTRAL", value: `${pressure.buyPressure.toFixed(0)}%↑`, weight: 0 })

    // 10. RSI divergence (weight 12 — high quality reversal signal)
    if (divergence === "bullish") votes.push({ name: "DIV", signal: "CALL", value: "Bullish", weight: 12 })
    else if (divergence === "bearish") votes.push({ name: "DIV", signal: "PUT", value: "Bearish", weight: 12 })
    else votes.push({ name: "DIV", signal: "NEUTRAL", value: "—", weight: 0 })

    // 11. BB Bounce (weight 12 — precise mean-reversion entry)
    if (bounce.isBounce && bounce.direction === "up") votes.push({ name: "BOUNCE", signal: "CALL", value: "BB↑", weight: 12 })
    else if (bounce.isBounce && bounce.direction === "down") votes.push({ name: "BOUNCE", signal: "PUT", value: "BB↓", weight: 12 })
    else votes.push({ name: "BOUNCE", signal: "NEUTRAL", value: "—", weight: 0 })

    // 12. Momentum + ATR filter (weight 8) — only signal if ATR is low enough (no runaway move)
    const atrOk = atr < atr28 * 1.5
    if (momentum > 0 && atrOk) votes.push({ name: "MOM", signal: "CALL", value: `+${momentum.toFixed(4)}`, weight: 8 })
    else if (momentum < 0 && atrOk) votes.push({ name: "MOM", signal: "PUT", value: momentum.toFixed(4), weight: 8 })
    else votes.push({ name: "MOM", signal: "NEUTRAL", value: "ATR↑", weight: 0 })

    // 13. Keltner Channel (weight 12) — breakout/reversal from channel bands
    if (price < keltner.lower) votes.push({ name: "KC", signal: "CALL", value: `${keltner.percentK.toFixed(0)}%`, weight: 12 })
    else if (price > keltner.upper) votes.push({ name: "KC", signal: "PUT", value: `${keltner.percentK.toFixed(0)}%`, weight: 12 })
    else votes.push({ name: "KC", signal: "NEUTRAL", value: `${keltner.percentK.toFixed(0)}%`, weight: 0 })

    // 14. Engulfing candle pattern (weight 14 — high-conviction reversal)
    if (engulfing === "bullish") votes.push({ name: "ENG", signal: "CALL", value: "Bull", weight: 14 })
    else if (engulfing === "bearish") votes.push({ name: "ENG", signal: "PUT", value: "Bear", weight: 14 })
    else votes.push({ name: "ENG", signal: "NEUTRAL", value: "—", weight: 0 })

    // 15. Calm-market filter: penalise signals during sudden volatility spikes
    if (!calmed) votes.push({ name: "CALM", signal: "NEUTRAL", value: "SPIKE", weight: 0 })

    // 16. VWAP (weight 12) — price relative to session value area
    if (price < vwap * 0.9998) votes.push({ name: "VWAP", signal: "CALL", value: `<${vwap.toFixed(4)}`, weight: 12 })
    else if (price > vwap * 1.0002) votes.push({ name: "VWAP", signal: "PUT", value: `>${vwap.toFixed(4)}`, weight: 12 })
    else votes.push({ name: "VWAP", signal: "NEUTRAL", value: vwap.toFixed(4), weight: 0 })

    // 17. Double top / double bottom reversal (weight 16 — high confidence pattern)
    if (doubleForm === "double_bottom") votes.push({ name: "DBL", signal: "CALL", value: "2Bot", weight: 16 })
    else if (doubleForm === "double_top")  votes.push({ name: "DBL", signal: "PUT",  value: "2Top", weight: 16 })
    else votes.push({ name: "DBL", signal: "NEUTRAL", value: "—", weight: 0 })

    // 18. Supertrend (weight 15 — reliable trend filter)
    // Weight increases if price is far from the line (strong signal)
    const stWeight = Math.round(10 + (supertrend.strength / 100) * 8)
    votes.push({ name: "ST", signal: supertrend.direction, value: `${supertrend.direction === "CALL" ? "▲" : "▼"}${supertrend.strength}`, weight: stWeight })

    // 19. Heikin-Ashi consecutive bars (weight 12 — smoothed trend confirmation)
    // More consecutive same-direction HA bars = stronger signal
    if (heikinAshi.direction !== "NEUTRAL") {
      const haWeight = Math.min(8 + heikinAshi.consecutive * 2, 18)
      votes.push({ name: "HA", signal: heikinAshi.direction, value: `${heikinAshi.consecutive}x`, weight: haWeight })
    } else {
      votes.push({ name: "HA", signal: "NEUTRAL", value: "—", weight: 0 })
    }

    // 20. Rate of Change (weight 8 — momentum confirmation)
    if (roc > 0.015) votes.push({ name: "ROC", signal: "CALL", value: `+${roc.toFixed(3)}%`, weight: 8 })
    else if (roc < -0.015) votes.push({ name: "ROC", signal: "PUT", value: `${roc.toFixed(3)}%`, weight: 8 })
    else votes.push({ name: "ROC", signal: "NEUTRAL", value: roc.toFixed(3), weight: 0 })

  } else if (tradeType === "DIGITEVEN_ODD") {
    // ── Even/Odd: predict whether next digit's last digit is even or odd ─────────
    // CALL = predict EVEN digit next  |  PUT = predict ODD digit next
    // Strategy: if ODD digits are over-represented recently, the sequence is
    // statistically due for EVEN (reversion to ~50/50 distribution).
    const a30 = analyzeDigitPattern(digits.slice(-30))
    const a20 = analyzeDigitPattern(digits.slice(-20))
    const a10 = analyzeDigitPattern(digits.slice(-10))
    const total30 = a30.evenCount + a30.oddCount
    const total20 = a20.evenCount + a20.oddCount
    const total10 = a10.evenCount + a10.oddCount
    if (total30 < 15) return EMPTY
    const evenRatio30 = total30 > 0 ? a30.evenCount / total30 : 0.5
    const evenRatio20 = total20 > 0 ? a20.evenCount / total20 : 0.5
    const evenRatio10 = total10 > 0 ? a10.evenCount / total10 : 0.5

    // 30-tick window ratio: heavy weight — needs strong imbalance (weight 35)
    // CALL (predict EVEN) when ODD has dominated: evenRatio < 0.37 means 63%+ ODD
    // PUT  (predict ODD)  when EVEN has dominated: evenRatio > 0.63 means 63%+ EVEN
    votes.push({ name: "Ratio30", signal: evenRatio30 < 0.37 ? "CALL" : evenRatio30 > 0.63 ? "PUT" : "NEUTRAL", value: `E${a30.evenCount}/O${a30.oddCount}`, weight: 35 })
    // 20-tick recency (weight 28) — same direction confirms the pattern is recent
    votes.push({ name: "Ratio20", signal: evenRatio20 < 0.35 ? "CALL" : evenRatio20 > 0.65 ? "PUT" : "NEUTRAL", value: `E${a20.evenCount}/O${a20.oddCount}`, weight: 28 })
    // Last 10 ticks (weight 22) — immediate near-term bias
    votes.push({ name: "Ratio10", signal: evenRatio10 < 0.30 ? "CALL" : evenRatio10 > 0.70 ? "PUT" : "NEUTRAL", value: `E${a10.evenCount}/O${a10.oddCount}`, weight: 22 })
    // Consecutive streak of SAME type = buy the OPPOSITE (weight 15)
    // 4+ consecutive ODD → buy EVEN. 4+ consecutive EVEN → buy ODD.
    votes.push({ name: "Streak", signal: a30.consecutiveOdd >= 4 ? "CALL" : a30.consecutiveEven >= 4 ? "PUT" : "NEUTRAL", value: `${a30.consecutiveEven}E/${a30.consecutiveOdd}O streak`, weight: 15 })

  } else if (tradeType === "DIGITMATCH_DIFF") {
    // ── Match/Differ: predict whether last digit differs from a target digit ──────
    // CALL = predict DIFFER  |  PUT = predict MATCH
    // Since DIFFER is far more common (~90% statistically), the signal is about
    // detecting the rare MATCH run and fading it (PUT = MATCH when pattern is due).
    const a30 = analyzeDigitPattern(digits.slice(-30))
    const a20 = analyzeDigitPattern(digits.slice(-20))
    const a15 = analyzeDigitPattern(digits.slice(-15))
    const total30 = a30.matchCount + a30.differCount
    if (total30 < 15) return EMPTY
    const differRatio30 = a30.differCount / total30
    const differRatio20 = (a20.matchCount + a20.differCount) > 0 ? a20.differCount / (a20.matchCount + a20.differCount) : 0.9
    const differRatio15 = (a15.matchCount + a15.differCount) > 0 ? a15.differCount / (a15.matchCount + a15.differCount) : 0.9

    // Strong DIFFER dominance → strong DIFFER signal (weight 40)
    votes.push({ name: "Ratio30", signal: differRatio30 > 0.75 ? "CALL" : differRatio30 < 0.25 ? "PUT" : "NEUTRAL", value: `D${a30.differCount}/M${a30.matchCount}`, weight: 40 })
    votes.push({ name: "Ratio20", signal: differRatio20 > 0.72 ? "CALL" : differRatio20 < 0.28 ? "PUT" : "NEUTRAL", value: `D${a20.differCount}/M${a20.matchCount}`, weight: 30 })
    votes.push({ name: "Ratio15", signal: differRatio15 > 0.70 ? "CALL" : differRatio15 < 0.30 ? "PUT" : "NEUTRAL", value: differRatio15.toFixed(2), weight: 20 })
    // Streak: 5+ consecutive DIFFER → DIFFER is dominant (CALL), 3+ MATCH → anomalous MATCH (PUT)
    votes.push({ name: "Streak", signal: a30.consecutiveOdd >= 5 ? "CALL" : a30.consecutiveEven >= 3 ? "PUT" : "NEUTRAL", value: `${a30.consecutiveOdd}d/${a30.consecutiveEven}m`, weight: 10 })

  } else if (tradeType === "DIGITOVER_UNDER") {
    // ── Over/Under 5: predict whether last digit is > 5 (OVER: 6,7,8,9) or ≤ 5 (UNDER: 0,1,2,3,4) ─
    // CALL = predict OVER 5 (digits 6–9)  |  PUT = predict UNDER 5 (digits 0–4)
    // Strategy: if UNDER digits are over-represented recently, reversion favours OVER.
    const a20 = analyzeDigitPattern(digits.slice(-20))
    const a30 = analyzeDigitPattern(digits.slice(-30))
    const a10 = analyzeDigitPattern(digits.slice(-10))
    const total20 = a20.overFiveCount + a20.underFiveCount
    const total30 = a30.overFiveCount + a30.underFiveCount
    const total10 = a10.overFiveCount + a10.underFiveCount
    if (total20 < 12) return EMPTY
    const overRatio20 = a20.overFiveCount / total20
    const overRatio30 = total30 > 0 ? a30.overFiveCount / total30 : 0.5
    const overRatio10 = total10 > 0 ? a10.overFiveCount / total10 : 0.5

    // 20-tick window (weight 38): UNDER dominating → OVER is due (CALL)
    votes.push({ name: "Ratio20", signal: overRatio20 < 0.33 ? "CALL" : overRatio20 > 0.67 ? "PUT" : "NEUTRAL", value: `O${a20.overFiveCount}/U${a20.underFiveCount}`, weight: 38 })
    // 30-tick window (weight 27)
    votes.push({ name: "Ratio30", signal: overRatio30 < 0.36 ? "CALL" : overRatio30 > 0.64 ? "PUT" : "NEUTRAL", value: overRatio30.toFixed(2), weight: 27 })
    // Last 10 ticks (weight 20)
    votes.push({ name: "Ratio10", signal: overRatio10 < 0.25 ? "CALL" : overRatio10 > 0.75 ? "PUT" : "NEUTRAL", value: `O${a10.overFiveCount}/U${a10.underFiveCount}`, weight: 20 })
    // Consecutive streak: 4+ UNDER → OVER is due, 4+ OVER → UNDER is due (weight 15)
    votes.push({ name: "Streak", signal: a20.consecutiveUnder >= 4 ? "CALL" : a20.consecutiveOver >= 4 ? "PUT" : "NEUTRAL", value: `${a20.consecutiveOver}ov/${a20.consecutiveUnder}un streak`, weight: 15 })
  }

  // Tally weighted scores
  let callScore = 0, putScore = 0, totalWeight = 0
  for (const v of votes) {
    if (v.signal === "CALL") callScore += v.weight
    else if (v.signal === "PUT") putScore += v.weight
    if (v.signal !== "NEUTRAL") totalWeight += v.weight
  }

  const maxScore = totalWeight || 100
  const callPct = (callScore / maxScore) * 100
  const putPct = (putScore / maxScore) * 100
  const margin = Math.abs(callPct - putPct)

  // Base confidence: the winning side's percentage of active weight
  let rawConf = Math.round(Math.max(callPct, putPct))
  rawConf = adaptConfidenceForRegime(rawConf, regime, tradeType)
  const confidence = Math.min(rawConf, 95)

  // ── Family consensus gate ─────────────────────────────────────────────────
  const familyResult = calcFamilyScore(votes)

  // Ultimate win-optimised gate — ALL must pass:
  // 1. ≥30% directional margin (strong conviction)
  // 2. ≥63% confidence
  // 3. >55% of active votes agree (majority)
  // 4. At least 2 of 4 indicator families agree (cross-family confirmation)
  // 5. Market is calmed (no immediate volatility spike for CALL_PUT)
  const activeVoteCountTotal = votes.filter(v => v.signal !== "NEUTRAL").length
  const tentativeDir: "CALL" | "PUT" = callScore >= putScore ? "CALL" : "PUT"
  const winningSideVotes = votes.filter(v => v.signal === tentativeDir).length
  const majorityConfirmed = activeVoteCountTotal > 0 && (winningSideVotes / activeVoteCountTotal) >= 0.60
  const familyOk = familyResult.agreedFamilies >= 3   // raised: 3 of 4 families must agree

  // ── Price-action confirmation ───────────────────────────────────────────────
  // Require 2+ consecutive closes in the signal direction — filters noise spikes
  // (3 was too strict and killed valid signals during tight consolidation)
  let paCount = 0
  for (let i = prices.length - 1; i >= 1 && paCount < 5; i--) {
    if (tentativeDir === "CALL" && prices[i] > prices[i - 1]) paCount++
    else if (tentativeDir === "PUT" && prices[i] < prices[i - 1]) paCount++
    else break
  }
  const priceActionOk = paCount >= 2

  // ── Confluence score: RSI + MACD + EMA + Supertrend all pointing same way ───
  const rsiConf  = tentativeDir === "CALL" ? rsi < rsiThresh.low  : rsi > rsiThresh.high
  const macdConf = tentativeDir === "CALL" ? macd.histogram > 0   : macd.histogram < 0
  const emaConf  = tentativeDir === "CALL" ? ema8v > ema21v       : ema8v < ema21v
  const stConf   = supertrend.direction === tentativeDir
  const confluenceScore = [rsiConf, macdConf, emaConf, stConf].filter(Boolean).length

  // ── Confluence bonus: all 4 agree → boost confidence by 8 ──────────────────
  const confBonus = confluenceScore === 4 ? 8 : confluenceScore === 3 ? 4 : 0
  const finalConf = Math.min(confidence + confBonus, 95)

  // ── Master shouldTrade gate — split by trade type for accuracy ──────────────
  const isDigitTrade = tradeType === "DIGITEVEN_ODD" || tradeType === "DIGITMATCH_DIFF" || tradeType === "DIGITOVER_UNDER"

  let shouldTrade = false
  const missing: string[] = []

  if (isDigitTrade) {
    // ── Digit trade gate: based purely on digit pattern strength ───────────────
    // Requires: strong directional margin from digit ratios, high confidence,
    // majority of digit votes agree — does NOT check price-action closes.
    const digitMajorityOk = activeVoteCountTotal > 0 && (winningSideVotes / activeVoteCountTotal) >= 0.65
    if (margin < 35)          missing.push(`margin ${margin.toFixed(0)}% < 35%`)
    if (finalConf < 62)       missing.push(`confidence ${finalConf}% < 62%`)
    if (!digitMajorityOk)     missing.push(`vote majority (${winningSideVotes}/${activeVoteCountTotal})`)
    shouldTrade = margin >= 35 && finalConf >= 62 && totalWeight > 0 && digitMajorityOk
  } else {
    // ── Price trade gate (CALL_PUT / ONETOUCH): full multi-family confirmation ──
    // Requires: 28% margin, 63% confidence, 60% majority, 3/4 families, price action (2 closes)
    if (margin < 28)          missing.push(`margin ${margin.toFixed(0)}% < 28%`)
    if (finalConf < 63)       missing.push(`confidence ${finalConf}% < 63%`)
    if (!familyOk)            missing.push(`only ${familyResult.agreedFamilies}/4 families`)
    if (!priceActionOk)       missing.push(`price action (${paCount}/2 closes)`)
    if (confluenceScore < 3)  missing.push(`confluence ${confluenceScore}/4`)
    shouldTrade =
      margin >= 28 &&
      finalConf >= 63 &&
      totalWeight > 0 &&
      majorityConfirmed &&
      familyOk &&
      priceActionOk &&
      confluenceScore >= 3
  }

  let direction: "CALL" | "PUT" | "WAIT" = "WAIT"
  if (shouldTrade) direction = tentativeDir

  // ── signalStrength 0-100 composite ─────────────────────────────────────────
  const familyPct    = isDigitTrade ? (winningSideVotes / Math.max(activeVoteCountTotal, 1)) * 100 : (familyResult.agreedFamilies / 4) * 100
  const majorityPct  = activeVoteCountTotal > 0 ? (winningSideVotes / activeVoteCountTotal) * 100 : 0
  const stAlignBonus = !isDigitTrade && supertrend.direction === tentativeDir ? 8 : 0
  const haAlignBonus = !isDigitTrade && heikinAshi.direction === tentativeDir ? 4 : 0
  const paBonus      = !isDigitTrade && priceActionOk ? 5 : 0
  const rawStrength  = finalConf * 0.40 + familyPct * 0.28 + majorityPct * 0.18 + stAlignBonus + haAlignBonus + paBonus
  const signalStrength = Math.min(Math.round(rawStrength), 100)

  // ── Human-readable readiness string ────────────────────────────────────────
  const signalReadiness = shouldTrade
    ? isDigitTrade
      ? `Ready — ${finalConf}% conf · ${winningSideVotes}/${activeVoteCountTotal} votes · ${margin.toFixed(0)}% margin`
      : `Ready — ${finalConf}% conf · ${familyResult.agreedFamilies}/4 families · ${paCount} PA closes · ${confluenceScore}/4 conf`
    : missing.length > 0
    ? `Waiting: ${missing.join(", ")}`
    : "Analysing..."

  const reason = `${activeVoteCountTotal}/${votes.length} indicators · ${finalConf}% conf · ${familyResult.agreedFamilies}/4 families · ${regime}`

  return {
    direction, confidence: finalConf, reason, votes, callScore, putScore, totalWeight, shouldTrade,
    rsi, macd, bb, stoch, cci, williamsR: wR, atr, streak, momentum, regime,
    familyScore: familyResult,
    signalStrength,
    supertrend,
    heikinAshi,
    roc,
    signalReadiness,
    priceActionOk,
    confluenceScore,
  }
}

// ─── Strategy-specific signal functions (kept for compatibility) ────────────

export function digitAISignal(digits: number[], contractType: "DIGITEVEN" | "DIGITODD"): Signal {
  const analysis = analyzeDigitPattern(digits.slice(-30))
  const total = analysis.evenCount + analysis.oddCount
  if (total < 10) return { direction: "WAIT", confidence: 0, reason: "Collecting data..." }
  const evenRatio = analysis.evenCount / total
  if (contractType === "DIGITEVEN") {
    if (analysis.consecutiveOdd >= 4) return { direction: "CALL", confidence: Math.min(60 + analysis.consecutiveOdd * 5, 88), reason: `${analysis.consecutiveOdd} consecutive odds — Even due` }
    if (evenRatio < 0.38) return { direction: "CALL", confidence: Math.round((1 - evenRatio) * 90), reason: `Even due: ${analysis.oddCount} odds vs ${analysis.evenCount} evens` }
  } else {
    if (analysis.consecutiveEven >= 4) return { direction: "CALL", confidence: Math.min(60 + analysis.consecutiveEven * 5, 88), reason: `${analysis.consecutiveEven} consecutive evens — Odd due` }
    if (evenRatio > 0.62) return { direction: "CALL", confidence: Math.round(evenRatio * 90), reason: `Odd due: ${analysis.evenCount} evens vs ${analysis.oddCount} odds` }
  }
  return { direction: "WAIT", confidence: 50, reason: "No clear signal" }
}

export function riseFallSignal(prices: number[]): Signal {
  if (prices.length < 60) return { direction: "WAIT", confidence: 0, reason: "Collecting data..." }
  const full = getFullSignal(prices, "CALL_PUT", [])
  return { direction: full.direction, confidence: full.confidence, reason: full.reason }
}

export function matchDifferSignal(digits: number[]): Signal {
  const analysis = analyzeDigitPattern(digits.slice(-30))
  const total = analysis.matchCount + analysis.differCount
  if (total < 10) return { direction: "WAIT", confidence: 0, reason: "Collecting data..." }
  const differRatio = analysis.differCount / total
  if (analysis.consecutiveOdd >= 5) return { direction: "CALL", confidence: 82, reason: `${analysis.consecutiveOdd} consecutive differs — Match due` }
  if (differRatio > 0.78) return { direction: "CALL", confidence: Math.round(differRatio * 95), reason: `Differ favored: ${analysis.differCount}/${total}` }
  if (differRatio < 0.22) return { direction: "PUT", confidence: Math.round((1 - differRatio) * 95), reason: `Match favored: ${analysis.matchCount}/${total}` }
  return { direction: "WAIT", confidence: 50, reason: "No clear pattern" }
}

export function overUnderSignal(digits: number[], target = 5): Signal {
  const analysis = analyzeDigitPattern(digits.slice(-20))
  const total = analysis.overFiveCount + analysis.underFiveCount
  if (total < 10) return { direction: "WAIT", confidence: 0, reason: "Collecting data..." }
  const overRatio = analysis.overFiveCount / total
  if (analysis.consecutiveOver >= 4) return { direction: "PUT", confidence: Math.min(65 + analysis.consecutiveOver * 5, 88), reason: `${analysis.consecutiveOver} consecutive overs — Under due` }
  if (analysis.consecutiveUnder >= 4) return { direction: "CALL", confidence: Math.min(65 + analysis.consecutiveUnder * 5, 88), reason: `${analysis.consecutiveUnder} consecutive unders — Over due` }
  if (overRatio > 0.65) return { direction: "PUT", confidence: Math.round(overRatio * 95), reason: `Under ${target} due: ${analysis.overFiveCount} overs` }
  if (overRatio < 0.35) return { direction: "CALL", confidence: Math.round((1 - overRatio) * 95), reason: `Over ${target} due: ${total - analysis.overFiveCount} unders` }
  return { direction: "WAIT", confidence: 50, reason: "Balanced" }
}
