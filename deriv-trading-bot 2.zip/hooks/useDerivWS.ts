"use client"
import { useRef, useCallback, useEffect } from "react"

const APP_ID = 1089
const WS_URL = `wss://ws.binaryws.com/websockets/v3?app_id=${APP_ID}`

type MessageHandler = (data: Record<string, unknown>) => void

export function useDerivWS() {
  const wsRef = useRef<WebSocket | null>(null)
  const handlersRef = useRef<Map<string, MessageHandler>>(new Map())
  const pendingRef = useRef<string[]>([])
  const reconnectTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  const send = useCallback((payload: object) => {
    const msg = JSON.stringify(payload)
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(msg)
    } else {
      pendingRef.current.push(msg)
    }
  }, [])

  const on = useCallback((msgType: string, handler: MessageHandler) => {
    handlersRef.current.set(msgType, handler)
    return () => handlersRef.current.delete(msgType)
  }, [])

  const connect = useCallback((token: string, onOpen: () => void, onError: (e: string) => void, onClose: () => void) => {
    if (wsRef.current) {
      wsRef.current.close()
    }

    const ws = new WebSocket(WS_URL)
    wsRef.current = ws

    ws.onopen = () => {
      // Flush pending messages
      while (pendingRef.current.length > 0) {
        const msg = pendingRef.current.shift()
        if (msg) ws.send(msg)
      }
      // Authorize
      ws.send(JSON.stringify({ authorize: token }))
    }

    ws.onmessage = (evt) => {
      try {
        const data = JSON.parse(evt.data) as Record<string, unknown>
        const msgType = data.msg_type as string

        if (msgType === "authorize") {
          if ((data as Record<string, unknown>).error) {
            onError(((data as Record<string, Record<string, string>>).error).message || "Authorization failed")
            ws.close()
          } else {
            onOpen()
          }
        }

        const handler = handlersRef.current.get(msgType)
        if (handler) handler(data)

        // Wildcard handler
        const wildcard = handlersRef.current.get("*")
        if (wildcard) wildcard(data)
      } catch {
        // ignore parse errors
      }
    }

    ws.onerror = () => {
      onError("WebSocket connection error")
    }

    ws.onclose = () => {
      onClose()
    }

    return ws
  }, [])

  const disconnect = useCallback(() => {
    if (reconnectTimerRef.current) clearTimeout(reconnectTimerRef.current)
    if (wsRef.current) {
      wsRef.current.onclose = null
      wsRef.current.close()
      wsRef.current = null
    }
  }, [])

  const subscribeTicks = useCallback((symbol: string) => {
    send({ ticks: symbol, subscribe: 1 })
  }, [send])

  const unsubscribeAll = useCallback(() => {
    send({ forget_all: "ticks" })
  }, [send])

  const buyContract = useCallback((params: {
    symbol: string
    contractType: string
    amount: number
    duration: number
    durationUnit: string
    currency?: string
  }) => {
    send({
      buy: 1,
      subscribe: 1,
      price: params.amount * 1000,
      parameters: {
        amount: params.amount,
        basis: "stake",
        contract_type: params.contractType,
        currency: params.currency || "USD",
        duration: params.duration,
        duration_unit: params.durationUnit,
        symbol: params.symbol,
      }
    })
  }, [send])

  const getBalance = useCallback(() => {
    send({ balance: 1, subscribe: 1 })
  }, [send])

  useEffect(() => {
    return () => {
      disconnect()
    }
  }, [disconnect])

  return { connect, disconnect, send, on, subscribeTicks, unsubscribeAll, buyContract, getBalance, wsRef }
}
